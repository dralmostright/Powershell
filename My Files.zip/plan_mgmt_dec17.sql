select output from table(sys.dbms_workload_repository.awr_sql_report_text(3195236880,
                                                            2,
                                                            17585, 18312,
                                                            '9xnz2sv24zf5f',
                                                            NULL ));
select * from table( DBMS_XPLAN.DISPLAY_AWR('9xnz2sv24zf5f',NULL,NULL, 'ADVANCED ALLSTATS'));
select DBID,INSTANCE_NUMBER,SNAP_ID,END_INTERVAL_TIME, BEGIN_INTERVAL_TIME from dba_hist_snapshot order by BEGIN_INTERVAL_TIME;

1. DROP SPM Plans AND Baselines
--select distinct sqlset_name from dba_sqlset_plans where sql_id like '9xnz2sv24zf5f';
--select sql_handle, plan_name, enabled, accepted, fixed  from dba_sql_plan_baselines WHERE signature IN (SELECT force_matching_signature FROM  DBA_SQLSET_PLANS WHERE  sqlset_name='CSPRD8_HIST_9xnz2sv24zf5f_BB') order by created desc;
DECLARE
  l_plans_dropped  PLS_INTEGER;
BEGIN
  l_plans_dropped := DBMS_SPM.drop_sql_plan_baseline (
    sql_handle => '<sql_handle>',
    plan_name  => '<plan_name>');

  DBMS_OUTPUT.put_line(l_plans_dropped);
END;
/
exec dbms_sqltune.drop_sqlset ( '<sqlset_name>' );
--EXEC dbms_sqltune.drop_sqlset('CSPRD8_HIST_9xnz2sv24zf5f_BB');


2. Create a sql tuning set set manually:
========================================
BEGIN
  DBMS_SQLTUNE.CREATE_SQLSET(
    sqlset_name => 'CSPRD8_HIST_9xnz2sv24zf5f_BB',
    description => 'SQL Tuning Set for loading plan into SQL Plan Baseline');
END;
/

3. Load the sql set with the hash from the AWR snap:
====================================================
DECLARE
  cur sys_refcursor;
BEGIN
  OPEN cur FOR
    SELECT VALUE(P)
    FROM TABLE(
       dbms_sqltune.select_workload_repository(begin_snap=>17585, end_snap=>18312,basic_filter=>'sql_id = ''9xnz2sv24zf5f''',attribute_list=>'ALL')
              ) p;
     DBMS_SQLTUNE.LOAD_SQLSET( sqlset_name=> 'CSPRD8_HIST_9xnz2sv24zf5f_BB', populate_cursor=>cur);
  CLOSE cur;
END;
/


4. To confirm the hash exists:
==============================
SELECT
  first_load_time,
  executions as execs,
  parsing_schema_name,
  elapsed_time  / 1000000 as elapsed_time_secs,
  cpu_time / 1000000 as cpu_time_secs,
  buffer_gets,
  disk_reads,
  direct_writes,
  rows_processed,
  fetches,
  optimizer_cost,
  sql_plan,
  plan_hash_value,
  sql_id,
  sql_text
   FROM TABLE(DBMS_SQLTUNE.SELECT_SQLSET(sqlset_name => 'CSPRD8_HIST_9xnz2sv24zf5f_BB'));

5. Finaly create the baseline:
==============================
BEGIN
  DBMS_SQLTUNE.CREATE_SQLSET(
    sqlset_name => 'CSPRD8_HIST_9xnz2sv24zf5f_BB',
    description => 'SQL Tuning Set for loading plan into SQL Plan Baseline');
END;
/

DECLARE
  cur sys_refcursor;
BEGIN
  OPEN cur FOR
    SELECT VALUE(P)
    FROM TABLE(
       dbms_sqltune.select_workload_repository(begin_snap=>17585, end_snap=>18312,basic_filter=>'sql_id = ''9xnz2sv24zf5f''',attribute_list=>'ALL')
              ) p;
     DBMS_SQLTUNE.LOAD_SQLSET( sqlset_name=> 'CSPRD8_HIST_9xnz2sv24zf5f_BB', populate_cursor=>cur);
  CLOSE cur;
END;
/


4. To confirm the hash exists:
==============================
SELECT
  first_load_time,
  executions as execs,
  parsing_schema_name,
  elapsed_time  / 1000000 as elapsed_time_secs,
  cpu_time / 1000000 as cpu_time_secs,
  buffer_gets,
  disk_reads,
  direct_writes,
  rows_processed,
  fetches,
  optimizer_cost,
  sql_plan,
  plan_hash_value,
  sql_id,
  sql_text
   FROM TABLE(DBMS_SQLTUNE.SELECT_SQLSET(sqlset_name => 'CSPRD8_HIST_9xnz2sv24zf5f_BB'));

5. Finaly create the baseline:
==============================
DECLARE
my_plans pls_integer;
BEGIN
  my_plans := DBMS_SPM.LOAD_PLANS_FROM_SQLSET(
    sqlset_name => 'CSPRD8_HIST_9xnz2sv24zf5f_BB',
    basic_filter=>'plan_hash_value = ''611794382'''
    );
END;
/

6. Verify it got created:
=========================
select sql_handle, plan_name, enabled, accepted, fixed  from dba_sql_plan_baselines WHERE signature IN (SELECT force_matching_signature FROM  DBA_SQLSET_PLANS WHERE  sqlset_name='CSPRD8_HIST_9xnz2sv24zf5f_BB') order by created desc;


7. Make it fixed, regardless so that it is given priority:
==========================================================
var v_num number;
exec :v_num:=dbms_spm.ALTER_SQL_PLAN_BASELINE (sql_handle =>'SQL_e220bbb1a7f317e5',plan_name => 'SQL_PLAN_f485vq6mz65z569d39fe0', attribute_name=> 'FIXED',  attribute_value  => 'YES');



DECLARE
  l_plans_altered  PLS_INTEGER;
BEGIN
  l_plans_altered := DBMS_SPM.alter_sql_plan_baseline(
    sql_handle      => 'SQL_66365a5ce64907a1',
    plan_name       => 'SQL_PLAN_6cdkubmm4k1x1802be989',
    attribute_name  => 'FIXED',
    attribute_value => 'YES');
END;
/


6. Verify it fixed attribute is changed:
========================================
select sql_handle, plan_name, enabled, accepted, fixed  from dba_sql_plan_baselines WHERE signature IN (SELECT force_matching_signature FROM  DBA_SQLSET_PLANS WHERE  sqlset_name='CSPRD8_HIST_9xnz2sv24zf5f_BB') order by created desc;


7. Flush the shared_pool on each node if its RAC:
=================================================
alter system flush shared_pool;

DECLARE
my_plans pls_integer;
BEGIN
  my_plans := DBMS_SPM.LOAD_PLANS_FROM_SQLSET(
    sqlset_name => 'CSPRD8_HIST_9xnz2sv24zf5f_BB',
    basic_filter=>'plan_hash_value = ''611794382'''
    );
END;
/

6. Verify it got created:
=========================
select sql_handle, plan_name, enabled, accepted, fixed  from dba_sql_plan_baselines WHERE signature IN (SELECT force_matching_signature FROM  DBA_SQLSET_PLANS WHERE  sqlset_name='CSPRD8_HIST_9xnz2sv24zf5f_BB') order by created desc;


7. Make it fixed, regardless so that it is given priority:
==========================================================
var v_num number;
exec :v_num:=dbms_spm.ALTER_SQL_PLAN_BASELINE (sql_handle =>'SQL_e220bbb1a7f317e5',plan_name => 'SQL_PLAN_f485vq6mz65z569d39fe0', attribute_name=> 'FIXED',  attribute_value  => 'YES');



DECLARE
  l_plans_altered  PLS_INTEGER;
BEGIN
  l_plans_altered := DBMS_SPM.alter_sql_plan_baseline(
    sql_handle      => 'SQL_66365a5ce64907a1',
    plan_name       => 'SQL_PLAN_6cdkubmm4k1x1802be989',
    attribute_name  => 'FIXED',
    attribute_value => 'YES');
END;
/

---
--- drop profile.
---
declare
drop_result pls_integer;
begin
drop_result := DBMS_SPM.DROP_SQL_PLAN_BASELINE(
sql_handle => 'SQL_5392f0158da2bc37',
plan_name => 'SQL_PLAN_574rh2q6u5g1r58d50089');
dbms_output.put_line(drop_result);
end;
/




6. Verify it fixed attribute is changed:
========================================
select sql_handle, plan_name, enabled, accepted, fixed  from dba_sql_plan_baselines WHERE signature IN (SELECT force_matching_signature FROM  DBA_SQLSET_PLANS WHERE  sqlset_name='CSPRD8_HIST_9xnz2sv24zf5f_BB') order by created desc;


7. Flush the shared_pool on each node if its RAC:
=================================================
alter system flush shared_pool;

or

select inst_id, ADDRESS, HASH_VALUE from GV$SQLAREA where SQL_ID='9xnz2sv24zf5f';
exec DBMS_SHARED_POOL.PURGE ('000000101E130F08,3293558958', 'C');
=> C implies cursor


DECLARE
  l_plans_loaded  PLS_INTEGER;
BEGIN
  l_plans_loaded := DBMS_SPM.load_plans_from_cursor_cache(
    sql_id => 'bfn5skt0gpp46',
    plan_hash_value => '1152339953');
  DBMS_OUTPUT.put_line('Plans Loaded: ' || l_plans_loaded);
END;
/


execute :cnt := DBMS_SPM.LOAD_PLANS_FROM_CURSOR_CACHE(
     sql_id => '1152339953', -
     plan_hash_value =>'3153495478');




8. Loading plan form cursor cache
=================================
DECLARE
  l_plans_pinned  PLS_INTEGER;
BEGIN
    l_plans_pinned := DBMS_SPM.LOAD_PLANS_FROM_CURSOR_CACHE(
    sql_id => 'c52suf1bxhkr0', 
    plan_hash_value =>'1573525552', 
    fixed => 'YES', 
    enabled => 'YES');
END;
/


declare
my_int pls_integer;
begin
  my_int := DBMS_SPM.load_plans_from_cursor_cache(
  sql_id => 'dy4wj821qq29z', 
  plan_hash_value => 3363027142, 
  fixed => 'YES', 
  enabled => 'YES');
  DBMS_OUTPUT.PUT_line(my_int);
end;
/


8. Loading plan form AWR
========================
declare
my_int NUMBER;
BEGIN
    my_int := dbms_spm.load_plans_from_awr(
             begin_snap   => 21391,
             end_snap     => 21407,
             basic_filter => q'# sql_id='gggp49bmkwrvj' and plan_hash_value='2502019956' #',
			 fixed        => 'YES');
      DBMS_OUTPUT.PUT_line(my_int);
END;
/

declare
my_int NUMBER;
BEGIN
    my_int := dbms_spm.load_plans_from_awr(
             begin_snap   => 134937,
             end_snap     => 135248,
             basic_filter => q'# sql_id='1jn2xuzwvv6nr' and plan_hash_value='654145207' #',
			 fixed        => 'YES');
      DBMS_OUTPUT.PUT_line(my_int);
END;
/

