﻿[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null

$serverlist = @(
"NVEIDBBACKUPP1"
)

#$servername = 'nveidbbackupp1'
$Accountlist = @()
$csvfile = "C:\temp\MailAccount.csv"

foreach($servername in $serverlist){
    echo "$servername"
    $sqlserver = new-object "Microsoft.SqlServer.Management.Smo.Server" $servername

    #$sqlserver.Mail.Accounts
    #$sqlserver.Mail.Accounts.MailServers
    foreach($mailAcc in $sqlserver.Mail.Accounts){
        $Account_info = New-Object PSObject -Property @{
            "ServerName" = $servername;
            "AccountName" = $mailAcc.Name;
            "Email" = $mailAcc.EmailAddress;
            "DisplayName" = $mailAcc.DisplayName
            "MailServer" = $mailAcc.Mailservers.Name
            "ReplyEmail" = $mailAcc.ReplyToAddress
        } 
        $Accountlist += $Account_info
    } 

}

$Accountlist #| select ServerName, Accountname, Email, DisplayName, MailServer | Export-Csv -Path $csvfile -NoTypeInformation 