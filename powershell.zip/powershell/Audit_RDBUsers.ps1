﻿param($servername)

$csvfile = "C:\temp\$($servername)_AuditReport.csv"

function query_email{
    param($user_name)
    $email = ""
    $sql_query = "select email from VHIP.dbo.Adusers where username = '$user_name';"
    $dbname = "REPORT"
    $connectionstring = "Server=NVEIADBP02; Database=VHIP; Integrated Security=True;"
    $connection = new-object System.Data.SqlClient.SqlConnection
    $connection.ConnectionString = $connectionstring
    $connection.open()
    $command = new-object System.Data.Sqlclient.Sqlcommand
    $command.connection = $connection
    $command.CommandText = $sql_query
    $result = $command.ExecuteReader()
    $table = new-object System.Data.DataTable
    $table.Load($result)
    if($table.rows.count -eq 1){
        $email = $table.email
    }
    $result.close()
    $connection.close()

    return $email
}

function ListADGroupMember{
    param($group_name)
    $member_list = @()
        $members_string = $(net group "$group_name" /domain) 
        if($members_string.length -lt 11){
            return $member_list
        }
        $member_array = $members_string[8..$($members_string.length -3)]
        foreach($member_line in $member_array){
            $member_line = $member_line -replace '\s+',' '
            $members = $member_line.Trim().Split(' ')
            $member_list += $members
        }
    #Write-Host $member_list
    return $member_list
}

function GetMemberDetails{
    param($username)

    $keys = @("User name", "Full Name", "Account active", "Account expires", "Last logon")
    $userDetails=@()
    [array]$userinfo = New-object PSObject
    $netuser = $(net user $username /domain)
    foreach($key in $keys){
        $userval = $($($netuser | select-string "$key") -replace "$key", '').Trim()
        $userinfo | Add-Member -NotePropertyName $($key -replace ' ','_') -NotePropertyValue $userval
        }
        #$userDetails += $userinfo
    

    return $userinfo

}

[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null
$server = New-Object Microsoft.SqlServer.Management.Smo.Server $servername
$AuditArray = @()
$userArray =@()
$serverlogins = $server.logins
$dbs = $server.Databases
$systemDbs = @('master', 'model', 'msdb', 'tempdb')
$systemUsers = ('dbo', 'guest', 'information_schema', 'sys')
foreach($db in $dbs){
    if($systemDbs -icontains $($db.Name)) { continue }
    if ($db.status -ieq 'Offline'){ continue }
    foreach($user in $db.Users){
        if ($systemUsers -icontains $($user.Name)) { continue }
        $userResult = New-Object PSObject -Property @{
            "Database" = $db.Name;
            "Username" = $user.Name;
            "LoginType" = $user.LoginType;
            "SqlUserCreated" = $user.CreateDate;
        } 
        $userArray += $userResult
    }
}



foreach($usr in $userArray){
    if($($usr.LoginType) -ieq 'WindowsGroup' -and $($($usr.Username).ToUpper() -ieq "PROD\RDB-DATAREADERS" -or $($usr.Username).ToUpper() -ieq "D2HAWKEYE\EIMNSTEAM")){
        $data_readers = @(('i80490', 'Asim Shrestha   '),
        ('		', 'Brizika Rai     '),
        ('i80278', 'Kamana Basukala '),
        ('i81087', 'Kripa Shrestha  '),
        ('i81249', 'Krishna Acharya '),
        ('i20784', 'Prabin Kayastha '),
        ('i82616', 'Rashmi Maharjan '),
        ('i10042', 'Sharad Ojha     '),
        ('i80685', 'Sristi Musyaju  '),
        ('i20348', 'Suresh Shilpakar')
        )

        foreach($datareader in $data_readers){
            $audit = New-Object PSObject -property @{
                    "Database" = $usr.Database;
                    "Username" = $datareader[0];
                    "Full_Name" = $datareader[1];
                    "Email" ="";
                    "Account_Type" = "";
                    "Account_Active" = "Yes";
                    "Expiry_Date" = "Never";
                    "Account_Group" = $usr.Username;
                    "Create_Date" = $usr.SqlUserCreated;
                }
            $AuditArray += $audit
        }
    }
    elseif($($usr.LoginType) -ieq 'WindowsGroup' -and $($usr.Username).ToUpper() -ieq "PROD\RDB-DATAWRITERS"){
            $audit = New-Object PSObject -property @{
                    "Database" = $usr.Database;
                    "Username" = 'i81087';
                    "Full_Name" = 'Kripa Shrestha  ';
                    "Email" ="";
                    "Account_Type" = "";
                    "Account_Active" = "Yes";
                    "Expiry_Date" = "Never";
                    "Account_Group" = $usr.Username;
                    "Create_Date" = $usr.SqlUserCreated;
                }
            $AuditArray += $audit
    }
    elseif($($usr.LoginType) -ieq 'WindowsGroup' -and $($($usr.Username).ToUpper().StartsWith('PROD') -or $($usr.Username).ToUpper().StartsWith('D2HAWKEYE'))){
        $DomainlessUsername = $($usr.Username).ToUpper().replace('PROD\','').replace('D2HAWKEYE\','')
        echo "$($usr.Database) <======> $DomainlessUsername "
        try{
        $mem_list = ListADGroupMember $($DomainlessUsername) -ErrorAction Stop
        if($mem_list.length -eq 0) { throw "Empty array"}
        foreach($mem in $mem_list){
            try{
                $userinfo = GetMemberDetails $mem
                $audit = New-Object PSObject -property @{
                    "Database" = $usr.Database;
                    "Username" = $userinfo.User_name;
                    "Full_Name" = $userinfo.Full_Name;
                    "Email" = query_email $($userinfo.User_name);
                    "Account_Type" = "";
                    "Account_Active" = $userinfo.Account_active;
                    "Expiry_Date" = $userinfo.Account_expires;
                    "Account_Group" = $usr.Username;
                    "Create_Date" = $usr.SqlUserCreated;
                }
            }catch{
                $audit = New-Object PSObject -property @{
                    "Database" = $usr.Database;
                    "Username" = $mem;
                    "Full_Name" = "";
                    "Email" = "";
                    "Account_Type" = "";
                    "Account_Active" = "";
                    "Expiry_Date" = "";
                    "Account_Group" = "";
                    "Create_Date" = "";
                }
            }
             $AuditArray += $audit
            
        }
        }catch{
            echo "Error $($_.Exception.Message)"
            $audit = New-Object PSObject -property @{
                "Database" = $usr.Database;
                "Username" = "";
                "Full_Name" = "";
                "Email" = "";
                "Account_Type" = "";
                "Account_Active" ="";
                "Expiry_Date" = "";
                "Account_Group" =  $usr.username;
                "Create_Date" = "";
            }
             $AuditArray += $audit
        }
        
    }

    elseif($($usr.LoginType) -ieq 'WindowsUser' -and $($($usr.Username).ToUpper().StartsWith('PROD') -or $($usr.Username).ToUpper().StartsWith('D2HAWKEYE'))){
        $DomainlessUsername = $($usr.Username).ToUpper().replace('PROD\','').replace('D2HAWKEYE\','')
        try{
        
            $userinfo = GetMemberDetails $DomainlessUsername
            $audit = New-Object PSObject -property @{
                "Database" = $usr.Database;
                "Username" = $userinfo.User_name;
                "Full_Name" = $userinfo.Full_Name;
                "Email" =  query_email $($userinfo.User_name);
                "Account_Type" = "";
                "Account_Active" = $userinfo.Account_active;
                "Expiry_Date" = $userinfo.Account_expires;
                "Account_Group" = "";
                "Create_Date" = $usr.SqlUserCreated;
            }

            $AuditArray += $audit
       
        }catch{
            echo "Error $($_.Exception.Message)"
        }
        
    }
    else{
        $userlogin = $serverlogins | where-object {$_.name -ieq $($usr.Username)}
        if($userlogin -eq $null) {$accountActive = "Orphan User"}
        else{
            $accountActive = switch ($userlogin.IsDisabled){
                "True" {"No"}
                "False" {"Yes"}
            }
        } 
        $audit = New-Object PSObject -property @{
            "Database" = $usr.Database;
            "Username" = $usr.Username;
            "Full_Name" = $usr.Username;
            "Email" = "";
            "Account_Type" = "";
            "Account_Active" = $accountActive;
            "Expiry_Date" = "";
            "Account_Group" = "";
            "Create_Date" = $userlogin.CreateDate;
        }

        $AuditArray += $audit
    
    }
}

$AuditArray | select Database, Username, FUll_Name, Email, Account_Type, Account_Active, Expiry_Date, Account_Group, Create_Date | Export-Csv -Path $csvfile -NoTypeInformation 