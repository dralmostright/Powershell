﻿$servername = "NVEI2ADBU01"
$output = "E:\Adhoc_Backup\Reports\$($servername)_rdmsize.txt"
$loadinfo = [Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")
$sqlserver = New-Object("Microsoft.SqlServer.Management.Smo.Server") $servername
out-file $output
foreach($d in $sqlserver.databases){
    echo $d.Name
    echo "$($d.name.PadRight(50)) $($([math]::Round($($d.size/1024),2)).ToString().PadRight(15)) $($($d.size).ToString().PadRight(15))" | out-file -Append $output
}