﻿$path = "E:\Adhoc_Backup\Upgrade\20170918\2017-09-18\SSAS\NVEIPROCODB04"
$output = "E:\Adhoc_backup\Reports\NVEIPROCODB04backupsize.txt"
Out-File $output
$files = Get-childitem $path
foreach($file in $files){
    echo "$($file.Name.PadRight(50)) $([Math]::round($file.Length/1024/1024,2))" | Out-file -Append $output
}

