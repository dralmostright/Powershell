﻿clear-host
[Reflection.Assembly]::LoadWithPartialName("Microsoft.AnalysisServices") | Out-Null


### Parameters to configure as per requirement
$AssemblyName = "CubeOps"
$outputDIR="C:\Temp"
$AssemblyFilePath = "C:\temp\assembly_test\VH.VHIP.CubeOps.Embedded.dll"
#$servers=@("NVEIODBP1","NVEIODBP2","NVEIODBP8","NPEIODBP2","NPEIODBP3","NPEIODBP5","NPEIODBP6","NPEIODBP8")
$serverse=@('NVEIHOSTODBP3')
$job = 3 ## 1 for getting Assemblies prerecord, 2 for getting Assemblies droprecord, 3 for getting Assmeblies postrecord, 4 for setting Assemblies, 5 for dropping Assemblies


$FormatEnumerationLimit = -1
$debug=1
$global:msgCollection=""
function logMessage{
    if($debug -eq 1){
        write-host $args
    }
    $curVal=$msgCollection + "`n" + $args
    #Set-Variable -Name "msgCollection" -Value $curVal -Scope Global
    $global:msgCollection = $global:msgCollection + "`r`n" + $args
}

 Function CsvToArray{
    $prerecordcsv = "$outputDIR\AssemblyRecord_pre.csv"
    $prerecord = Import-Csv $prerecordcsv
    $recArray = @{}
    foreach($myprerecord in $prerecord){
        $newkey = $myprerecord.Server + $myprerecord.Database
        $recArray.set_item($newkey, $myprerecord.Assembly)
    }
    return $recArray
 }

Function DropDBAssembly($db, $assemName){
    
    #$assembly_to_drop = $db.Assemblies | Where-object {$_.Name -ieq $assemName}
    $existingassemblies = @()
    $existingassemblies = $db.Assemblies.Name
    foreach($assem_to_drop in $existingassemblies){ #foreach($assembly_to_drop in $db.Assemblies){
        $assembly_to_drop = $db.Assemblies | Where-object {$_.Name -ieq $assem_to_drop}
        LogMessage "Info |" (Get-Date) "| Dropping $($assembly_to_drop.Name) in $($db.Name)"
        try{
            $assembly_to_drop.Drop();
            LogMessage "Info |" (Get-Date) "| Dropped Assembly $($assembly_to_drop.Name)"
        }catch{
            LogMessage "Error|" (Get-Date) "| Drop Failed : $($_.Exception.Message)"
        }
    }
}

Function DropAssembly{
    $global:msgCollection = "";
    $outputfile="$outputDIR\DropAssemblyLogs_$(get-date -format "dd_MM_yyyy").txt"
    foreach($SSASServerName in $servers){
        # Try to connect to the SSAS server
        $SSASServer = New-Object Microsoft.AnalysisServices.Server
        $SSASServer.Connect($SSASServerName)
        LogMessage "Info |" (Get-Date) "| ---------------------------------------------------------------- " 
        LogMessage "Info |" (Get-Date) "| Dropping Assembly in server $($SSASServerName)"
        LogMessage "Info |" (Get-Date) "| ---------------------------------------------------------------- "        
        foreach ($DB in $SSASServer.Databases)
        {
            DropDBAssembly $DB $assemblyName
        }
        LogMessage "Info |" (Get-Date) "| ---------------------------------------------------------------- "        
        LogMessage "Info |" (Get-Date) "| Competed Dropping Assembly in server $($SSASServerName)"
        LogMessage "Info |" (Get-Date) "| ---------------------------------------------------------------- "        
        $global:msgCollection | Out-File $outputfile 
        $SSASServer.disconnect()
        
    }     
}

Function AddDBAssembly($db, $assemName, $dllPath){
    $newAssembly = New-Object Microsoft.AnalysisServices.ClrAssembly($assemName, $assemName)
    $newAssembly.LoadFiles($dllPath, $true)
    $newAssembly.PermissionSet="Unrestricted";  
    $myImpersonationInfo=New-Object Microsoft.AnalysisServices.ImpersonationInfo;
    $myImpersonationInfo.ImpersonationMode="ImpersonateServiceAccount";           
    $newAssembly.ImpersonationInfo=$myImpersonationInfo;
    LogMessage "Info |" (Get-Date) "| Adding Assembly $assemName in $($db.Name)"
    try{
        $x=$DB.Assemblies.add($newAssembly)
        $DB.Assemblies.Update()
        LogMessage "Info |" (Get-Date) "| Added Assembly $assemName in $($db.Name)"
    }catch{
        LogMessage "Error|" (Get-Date) "| Failed Adding Assembly : $($_.Exception.Message)"    
    }
}


Function AddAssembly{
    $global:msgCollection = "";
    $outputfile="$outputDIR\SetAssemblyLogs_$(get-date -format "dd_MM_yyyy").txt"
    $oldAssembly = CsvToArray
    foreach($SSASServerName in $servers){
        # Try to connect to the SSAS server
        $SSASServer = New-Object Microsoft.AnalysisServices.Server
        $SSASServer.Connect($SSASServerName)
        LogMessage "Info |" (Get-Date) "| ---------------------------------------------------------------- " 
        LogMessage "Info |" (Get-Date) "| Adding Assembly in server $($SSASServerName)"
        LogMessage "Info |" (Get-Date) "| ---------------------------------------------------------------- "        
        foreach ($DB in $SSASServer.Databases)
        {
            $ArrayKey = $SSASServerName + $DB.Name
            $preassem = $oldAssembly.Get_Item($ArrayKey)
            if($preassem -ne ""){
                AddDBAssembly $DB $assemblyName $AssemblyFilePath
            }
        }
        LogMessage "Info |" (Get-Date) "| ---------------------------------------------------------------- " 
        LogMessage "Info |" (get-Date) "| Competed Adding Assembly in server $($SSASServerName)"
        LogMessage "Info |" (Get-Date) "| ---------------------------------------------------------------- "  
        $SSASServer.disconnect()
        
    } 
    $global:msgCollection | Out-File $outputfile 
}

Function AssemblyRecord($type){
     $msgCollection = "";
     $assemblyList = @()
     $RecordCSV="$outputDIR\AssemblyRecord_$($type).csv"
     
     if($type -eq 'post'){
        $oldAssembly = CsvToArray
        foreach($SSASServerName in $servers){
            # Try to connect to the SSAS server
            $SSASServer = New-Object Microsoft.AnalysisServices.Server
            $SSASServer.Connect($SSASServerName)
            Write-Host "Server:" $SSASServerName
            foreach ($DB in $SSASServer.Databases)
            {
                Write-host "Found" $DB.Assemblies.count "assembly for" $DB.Name
                #$assem = $DB.Assemblies | Where-Object {$_.Name -ieq $AssemblyName}
                $Arraykey = $SSASServerName+$DB.Name
                $myassem = $DB.Assemblies #| Where-Object {$_.Name -ieq $AssemblyName}
                if($myassem.count -eq 0){
                    [array]$myassembly = New-Object PSObject -Property @{
                        "Server" = $SSASServerName
                        "Database"= $DB.Name	
                        "Assembly" =""
                        "OldAssembly" = $oldAssembly.Get_item($Arraykey)
                        "AssemblyFile" = ""
                        "Permission" =""
                        "ImpersonationInfo" = ""
                     }
                     $assemblyList += $myassembly
                }
                else{
                    foreach($assem in $myassem){
                        $afilelist = ''
                        foreach($assemfile in $assem.Files){
                            $afilelist +="[ $($assemfile.Name) ] "
                        }
                        [array]$myassembly = New-Object PSObject -Property @{
                            "Server" = $SSASServerName
                            "Database"= $DB.Name	
                            "Assembly" =$assem.Name
                            "OldAssembly" = $oldAssembly.Get_item($Arraykey)
                            "AssemblyFile" = $afilelist
                            "Permission" =$assem.PermissionSet
                            "ImpersonationInfo" =$assem.ImpersonationInfo.ImpersonationMode
                         }
                         $assemblyList += $myassembly
                     }
                }
    
            }
        }
        $assemblyList | Select Server, Database, Assembly, OldAssembly, AssemblyFile, Permission, ImpersonationInfo | Export-CSV -Path $RecordCSV -NoTypeInformation
    }
    else{ #if($type -eq 'pre'){
        foreach($SSASServerName in $servers){
            # Try to connect to the SSAS server
            $SSASServer = New-Object Microsoft.AnalysisServices.Server
            $SSASServer.Connect($SSASServerName)
            Write-Host "Server:" $SSASServerName
            foreach ($DB in $SSASServer.Databases)
            {
                Write-host "Found" $DB.Assemblies.count "assembly for" $DB.Name
                $myassem = $DB.Assemblies #| Where-Object {$_.Name -ieq $AssemblyName}
                if($myassem.count -eq 0){
                    [array]$myassembly = New-Object PSObject -Property @{
                        "Server" = $SSASServerName
                        "Database"= $DB.Name	
                        "Assembly" =""
                        "AssemblyFile" = ""
                        "Permission" =""
                        "ImpersonationInfo" = ""
                     }
                     $assemblyList += $myassembly
                }
                else{
                    foreach($assem in $myassem){
                        $afilelist = ''
                        foreach($assemfile in $assem.Files){
                            $afilelist +="[ $($assemfile.Name) ] "
                        }
                        [array]$myassembly = New-Object PSObject -Property @{
                            "Server" = $SSASServerName
                            "Database"= $DB.Name	
                            "Assembly" =$assem.Name
                            "AssemblyFile" = $afilelist
                            "Permission" =$assem.PermissionSet
                            "ImpersonationInfo" =$assem.ImpersonationInfo.ImpersonationMode
                         }
                         $assemblyList += $myassembly
                     }
                }
            }
        
            $SSASServer.disconnect()
        }
        $assemblyList | Select Server, Database, Assembly, AssemblyFile, Permission, ImpersonationInfo | Export-CSV -Path $RecordCSV -NoTypeInformation
    }     
}


#main execution
if($job -eq 1){
    AssemblyRecord "pre"
}
elseif($job -eq 2){
    AssemblyRecord "drop"
}
elseif($job -eq 3)
{
    AssemblyRecord "post"
}
elseif($job -eq 4){
    AddAssembly
}
elseif($job -eq 5){
    DropAssembly
}