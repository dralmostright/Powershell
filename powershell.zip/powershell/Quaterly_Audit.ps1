﻿# UAT2uction list IP - 10.48.2.176
#$serverlist = @('NVEIADBP02', 'NVEIHOSTRDBP1', 'NVEIHOSTRDBP2', 'NVEIRDBP1', 'NVEIRDBP2', 'NVEIPROCRDB01', 'NVEIPROCRDB02','NVEIPROCRDB03', 'NVEIPROCRDB04')
# UAT2 list IP - 10.48.2.97
#$serverlist = @('NVEI1ADBU10', 'NVEI1ADBU11', 'NVEI1RDBU1', 'NVEI1RDBU3')
# uat2 list IP - 10.48.2.152
$serverlist = @('NVEI2ADBU01', 'NVEI2ADBU02', 'NVEI2HOSTRDBU01')





Function DH_getGroupMember($fValue){
    $ServerName = '10.48.27.50'
    $DomainEntry = New-Object -TypeName System.DirectoryServices.DirectoryEntry "LDAP://$ServerName" #,$($Credential.UserName),$($Credential.GetNetworkCredential().password)
    $DomainName = $DomainEntry.name
    $Searcher = New-Object -TypeName System.DirectoryServices.DirectorySearcher
    $Searcher.Filter="(&(objectCategory=group)(name=$fValue*))"
    $Searcher.SearchRoot = $DomainEntry
    $me = $Searcher.FindAll()
    $alluser = @()
    foreach($mem in $me.Properties.member){
        $disp = $mem.substring(3,$mem.IndexOf(',')-3)
        $inuser = DH_getUser "$disp" 1
        $alluser += $inuser
    }
    return $alluser
}
function DH_getUser($fValue, $checkbit){
  $ServerName = '10.48.27.50'
  $DomainEntry = New-Object -TypeName System.DirectoryServices.DirectoryEntry "LDAP://$ServerName" #,$($Credential.UserName),$($Credential.GetNetworkCredential().password)
  $DomainName = $DomainEntry.name
  $Searcher = New-Object -TypeName System.DirectoryServices.DirectorySearcher
  if($checkbit -eq 0){
    $Searcher.Filter="(sAMAccountName=$fValue)"
  }
  else{
    $Searcher.Filter="(&(objectCategory=person)(objectClass=User)(name=$fValue*))"
  }
  $Searcher.SearchRoot = $DomainEntry
  $me = $Searcher.FindAll()
  $me.Properties
}

Function UAT2_getGroupMember($fValue){
    $ServerName = '10.48.2.152'
    $DomainEntry = New-Object -TypeName System.DirectoryServices.DirectoryEntry "LDAP://$ServerName" #,$($Credential.UserName),$($Credential.GetNetworkCredential().password)
    $DomainName = $DomainEntry.name
    $Searcher = New-Object -TypeName System.DirectoryServices.DirectorySearcher
    $Searcher.Filter="(&(objectCategory=group)(name=$fValue*))"
    $Searcher.SearchRoot = $DomainEntry
    $me = $Searcher.FindAll()
    $alluser = @()
    foreach($mem in $me.Properties.member){
        $disp = $mem.substring(3,$mem.IndexOf(',')-3)
        $inuser = UAT2_getUser "$disp" 1
        if($inuser -eq $null){ continue }
        $alluser += $inuser
    }
    $alluser
}
function UAT2_getUser($fValue, $checkbit){
  $ServerName = '10.48.2.152'
  $DomainEntry = New-Object -TypeName System.DirectoryServices.DirectoryEntry "LDAP://$ServerName" #,$($Credential.UserName),$($Credential.GetNetworkCredential().password)
  $DomainName = $DomainEntry.name
  $Searcher = New-Object -TypeName System.DirectoryServices.DirectorySearcher
  if($checkbit -eq 0){
    $Searcher.Filter="(sAMAccountName=$fValue)"
  }
  else{
    $Searcher.Filter="(&(objectCategory=person)(objectClass=User)(name=$fValue*))"
  }
  $Searcher.SearchRoot = $DomainEntry
  $me = $Searcher.FindAll()
  $me.Properties
}

Function get_values($arr){
    if($arr -ne $null){
        $arr[0]
    }
    else{
        $null
    }
}

function accountActive($usr){
        $acc = switch ($usr.IsDisabled){
            "True" {"No"}
            "False" {"Yes"}
        }
        $acc
    }


foreach($servername in $serverlist){

$csvfile = "C:\temp\$($servername)_AuditReport.csv"

[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null
$server = New-Object Microsoft.SqlServer.Management.Smo.Server $servername
$AuditArray = @()
$userArray =@()
$serverlogins = $server.logins


foreach($usr in $server.logins){
    if($($usr.LoginType) -ieq 'WindowsGroup' -and $($usr.name).ToUpper().StartsWith('UAT2') ){
        $DomainlessUsername = $($usr.name).ToUpper().replace('UAT2\','').replace('D2HAWKEYE\','')
       try{
        
            $mem = UAT2_getUser $DomainlessUsername 0
            $audit = New-Object PSObject -property @{
                "Server" = $servername;
                "Username" = $usr.name
                "Full_Name" = get_values($mem.name);
                "Email" =  get_values($mem.mail);
                "Account_Type" = $usr.LoginType;
                "Account_Active" = accountActive $usr
                "Expiry_Date" = get_values($mem.accountexpires);
                "Create_Date" = get_values($mem.whencreated);
            }

            $AuditArray += $audit
       
        }catch{
            echo "Error $($_.Exception.Message)"
        }
    }
    elseif($($usr.LoginType) -ieq 'WindowsGroup' -and $($usr.name).ToUpper().StartsWith('D2HAWKEYE') ){
        $DomainlessUsername = $($usr.name).ToUpper().replace('UAT2\','').replace('D2HAWKEYE\','')
        try{
        
            $mem = DH_getUser $DomainlessUsername 0
            $audit = New-Object PSObject -property @{
                "Server" = $servername;
                "Username" = $usr.name
                "Full_Name" = get_values($mem.name);
                "Email" =  get_values($mem.mail);
                "Account_Type" = $usr.LoginType;
                "Account_Active" = accountActive $usr
                "Expiry_Date" = get_values($mem.accountexpires);
                "Create_Date" = get_values($mem.whencreated);
            }

            $AuditArray += $audit
       
        }catch{
            echo "Error $($_.Exception.Message)"
        }
    }    

    elseif($($usr.LoginType) -ieq 'WindowsUser' -and $($usr.name).ToUpper().StartsWith('UAT2')){
        $DomainlessUsername = $($usr.name).ToUpper().replace('UAT2\','').replace('D2HAWKEYE\','')
        try{
        
            $mem = UAT2_getUser $DomainlessUsername 0
            $audit = New-Object PSObject -property @{
                "Server" = $servername;
                "Username" = $usr.name
                "Full_Name" = get_values($mem.name);
                "Email" =  get_values($mem.mail);
                "Account_Type" = $usr.LoginType;
                "Account_Active" = accountActive $usr
                "Expiry_Date" = get_values($mem.accountexpires);
                "Create_Date" = get_values($mem.whencreated);
            }

            $AuditArray += $audit
       
        }catch{
            echo "Error $($_.Exception.Message)"
        }
        
    }
    elseif($($usr.LoginType) -ieq 'WindowsUser' -and $($usr.name).ToUpper().StartsWith('D2HAWKEYE')){
        $DomainlessUsername = $($usr.name).ToUpper().replace('UAT2\','').replace('D2HAWKEYE\','')
        try{
        
            $mem = DH_getUser $DomainlessUsername 0
            $audit = New-Object PSObject -property @{
                "Server" = $servername;
                "Username" = $usr.name
                "Full_Name" = get_values($mem.name);
                "Email" =  get_values($mem.mail);
                "Account_Type" = $usr.LoginType
                "Account_Active" = accountActive $usr
                "Expiry_Date" = get_values($mem.accountexpires);
                "Create_Date" = get_values($mem.whencreated);
            }

            $AuditArray += $audit
       
        }catch{
            echo "Error $($_.Exception.Message)"
        }
        
    }
    else{
       $audit = New-Object PSObject -property @{
            "Server" = $servername;
            "Username" = $usr.name;
            "Full_Name" = $usr.name;
            "Email" = "";
            "Account_Type" = $usr.LoginType;
            "Account_Active" = accountActive $usr
            "Expiry_Date" = "";
            "Create_Date" = $usr.CreateDate;
        }

        $AuditArray += $audit
    
    }
}


$AuditArray | select Server, Username, FUll_Name, Email, Account_Type, Account_Active, Create_Date | Export-Csv -Path $csvfile -NoTypeInformation 
}