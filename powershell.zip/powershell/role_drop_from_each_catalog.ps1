﻿$servername = 'nveihostodbp3'
$outfile = "C:\Temp\($servername)_olaproledrop.txt"
[System.Reflection.Assembly]::LoadWithPartialName('Microsoft.AnalysisServices') | out-null
Function LogMessage{
    param($msg, $outfile)
    $now = get-date -format "yyyy-MM-dd HH:mm:ss"
    Write-Verbose "$now :: $msg" -Verbose
    echo "$now :: $msg" | Out-File -Append $outfile
}

$SSASServer = New-Object Microsoft.AnalysisServices.Server
$SSASServer.connect($servername)
$SSASServer.Name
<#
foreach($db in $SSASServer.Databases){
    LogMessage ">>>>>>>>>>> Dropping roles in $($db.Name)" $outfile
    $roles = @()
    foreach($r in $db.Roles){
        $roles += $r.Name
    }
    foreach($r in $roles){
        LogMessage "Dropping Role $($r)" $outfile
        try{
        $cur_role = $db.Roles | where-object {$_.Name -ieq $r}
        $cur_role.Drop([Microsoft.AnalysisServices.DropOptions]::AlterOrDeleteDependents)
        }catch{
            LogMessage "Drop Failed for Role $($r) :: $($_.Exception.Message)" $outfile
        }
    }
 

}

#>