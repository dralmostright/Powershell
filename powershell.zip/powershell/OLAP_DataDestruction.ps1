﻿### Parameters to be set ####

$LOGNAME='nveiodbp1_Aon_NextEra_After'
$servername='nveiodbp1.prod.ops.global.ad'
$DropDatabases=@(

'AON NextEra - Production'



#'PHPNI Proofing'


)
$scriptpath = 'C:\MSSQL\scripts\powershell\OLAP_RemoteDataD.ps1'


$logfile = "C:\temp\$($LOGNAME).txt"
Invoke-Command -Computername $servername -Filepath $scriptpath -ArgumentList($LOGNAME, $DropDatabases) | Tee-Object $logfile