﻿$serverlist =@('NVEI2HOSTRDBU01', 'NVEI2ADBU01','NVEI2ADBU02', 'NVEI1RDBU1', 'NVEI1RDBU3', 'NVEI1ADBU10', 'NVEI1ADBU11')



function query_email{
    param($user_name)
    $email = ""
    $sql_query = "select email from VHIP.dbo.Adusers where username = '$user_name';"
    $dbname = "REPORT"
    $connectionstring = "Server=NVEIADBP02; Database=VHIP; Integrated Security=True;"
    $connection = new-object System.Data.SqlClient.SqlConnection
    $connection.ConnectionString = $connectionstring
    $connection.open()
    $command = new-object System.Data.Sqlclient.Sqlcommand
    $command.connection = $connection
    $command.CommandText = $sql_query
    $result = $command.ExecuteReader()
    $table = new-object System.Data.DataTable
    $table.Load($result)
    if($table.rows.count -eq 1){
        $email = $table.email
    }
    $result.close()
    $connection.close()

    return $email
}

function ListADGroupMember{
    param($group_name)
    $member_list = @()
        $members_string = $(net group "$group_name" /domain) 
        if($members_string.length -lt 11){
            return $member_list
        }
        $member_array = $members_string[8..$($members_string.length -3)]
        foreach($member_line in $member_array){
            $member_line = $member_line -replace '\s+',' '
            $members = $member_line.Trim().Split(' ')
            $member_list += $members
        }
    #Write-Host $member_list
    return $member_list
}

function GetMemberDetails{
    param($username)

    $keys = @("User name", "Full Name", "Account active", "Account expires", "Last logon")
    $userDetails=@()
    [array]$userinfo = New-object PSObject
    $netuser = $(net user $username /domain)
    foreach($key in $keys){
        $userval = $($($netuser | select-string "$key") -replace "$key", '').Trim()
        $userinfo | Add-Member -NotePropertyName $($key -replace ' ','_') -NotePropertyValue $userval
        }
        #$userDetails += $userinfo
    

    return $userinfo

}

[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null
foreach($servername in $serverlist){
    $csvfile = "C:\temp\$($servername)_AuditReport.csv"
    $server = New-Object Microsoft.SqlServer.Management.Smo.Server $servername
    $AuditArray = @()
    $userArray =@()
    $serverlogins = $server.logins
    $dbs = $server.Databases
    $systemDbs = @('master', 'model', 'msdb', 'tempdb')
    $systemUsers = ('dbo', 'guest', 'information_schema', 'sys')
    foreach($db in $dbs){
        if($systemDbs -icontains $($db.Name)) { continue }
        if ($db.status -ieq 'Offline'){ continue }
        foreach($user in $db.Users){
            if ($systemUsers -icontains $($user.Name)) { continue }
            if ($user.Name.ToUpper().StartsWith('NT AUTHORITY')) { continue;}
            if($user.LoginType -ieq 'WindowsUser'){
                $userResult = New-Object PSObject -Property @{
                    "Database" = $db.Name;
                    "Username" = $user.Name;
                    "LoginType" = $user.LoginType;
                    "SqlUserCreated" = $user.CreateDate;
                } 
                $userArray += $userResult
            }
        }
    }



    foreach($usr in $userArray){
    
        if( $($usr.Username).ToUpper().StartsWith('PROD') -or $($usr.Username).ToUpper().StartsWith('D2HAWKEYE')){
            $DomainlessUsername = $($usr.Username).ToUpper().replace('PROD\','').replace('D2HAWKEYE\','')
            try{
                $DomainlessUsername
                $userinfo = GetMemberDetails $DomainlessUsername -ErrorAction Stop
                $audit = New-Object PSObject -property @{
                    "Database" = $usr.Database;
                    "Username" = $usr.Username;
                    "Full_Name" = $userinfo.Full_Name;
                    "Email" =  query_email $($userinfo.User_name);
                    "Account_Type" = "";
                    "Account_Active" = $userinfo.Account_active;
                    "Expiry_Date" = $userinfo.Account_expires;
                    "Account_Group" = "";
                    "Create_Date" = $usr.SqlUserCreated;
                }

                $AuditArray += $audit
       
            }catch{
                echo "Error $($_.Exception.Message)"
                $userlogin = $serverlogins | where-object {$_.name -ieq $($usr.Username)}
                if($userlogin -eq $null) {$accountActive = "Orphan User"}
                else{
                    $accountActive = switch ($userlogin.IsDisabled){
                        "True" {"No"}
                        "False" {"Yes"}
                    }
                } 
                $audit = New-Object PSObject -property @{
                    "Database" = $usr.Database;
                    "Username" = $usr.Username;
                    "Full_Name" = "";
                    "Email" =  ""
                    "Account_Type" = "";
                    "Account_Active" = "$accountActive"
                    "Expiry_Date" = ""
                    "Account_Group" = "";
                    "Create_Date" = $usr.SqlUserCreated;
                }

                $AuditArray += $audit
            }
        
        }
        else{
            $userlogin = $serverlogins | where-object {$_.name -ieq $($usr.Username)}
            if($userlogin -eq $null) {$accountActive = "Orphan User"}
            else{
                $accountActive = switch ($userlogin.IsDisabled){
                    "True" {"No"}
                    "False" {"Yes"}
                }
            } 
            $audit = New-Object PSObject -property @{
                "Database" = $usr.Database;
                "Username" = $usr.Username;
                "Full_Name" = $usr.Username;
                "Email" = "";
                "Account_Type" = "";
                "Account_Active" = $accountActive;
                "Expiry_Date" = "";
                "Account_Group" = "";
                "Create_Date" = $userlogin.CreateDate;
            }

            $AuditArray += $audit
    
        }
    }

    $AuditArray | select Database, Username, FUll_Name, Email, Account_Type, Account_Active, Expiry_Date, Account_Group, Create_Date | Export-Csv -Path $csvfile -NoTypeInformation 
}