﻿$servername  = 'NVEIHOSTRDBP4'
# NVEIHOSTRDBP1, NVEIHOSTRDBP2, NVEIHOSTRDBP3, NVEIHOSTRDBP4

$exclude_list  = @(
"prod\Administrator","WindowsUser"
"prod\DBA",
"prod\Deployment Admins - Client DB",
"prod\Operations Admins",
"prod\ServiceRunnerProd","WindowsUser"
"prod\VH EI CubeDev"
)

[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null
$sqlserver = New-Object 'Microsoft.SqlServer.Management.Smo.Server' $servername

$droplogin =@()


foreach($login in $sqlserver.logins){
    if($login.Name.ToUpper().StartsWith('PROD') -or $login.Name.ToUpper().StartsWith('D2HAWKEYE')){
        if($exclude_list -icontains $login.Name) { continue; }
        $droplogin += $login.Name
    }
}

$droplogin

<#
foreach($username in $droplogin){
    $todrop = $sqlserver.logins | Where-Object {$_.Name -eq $username}
    echo "Dropping $($todrop.Name)"
    $todrop.Drop()
}

#>