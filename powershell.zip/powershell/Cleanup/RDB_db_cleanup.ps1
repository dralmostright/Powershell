﻿$servername  = 'NVEIHOSTRDBP4'
# NVEIHOSTRDBP1, NVEIHOSTRDBP2, NVEIHOSTRDBP3, NVEIHOSTRDBP4

$exclude_list  = @('master', 'model', 'msdb', 'tempdb', 'distribution')

[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null

$sqlserver = New-Object 'Microsoft.SqlServer.Management.Smo.Server' $servername

$dropDB =@()

foreach($db in $sqlserver.Databases){
    if($exclude_list -icontains $db.Name){ continue; }
    $dropDB += $db.Name
}

$dropDB
<#
foreach($dbname in $dropDB){
    $database = $sqlserver.Databases.Item($dbname)
    echo "Dropping $($database.Name)"
    $database.Drop()
}

#>

