﻿$servername  = 'nveihostodbp5-n.prod.ops.global.ad'


$exclude_list  = @()

[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.AnalysisServices") | Out-Null

$olapserver = New-Object 'Microsoft.AnalysisServices.Server'
$olapserver.connect($servername)
$olapserver.Name

$dropDB =@()

foreach($db in $olapserver.Databases){
    if($exclude_list -icontains $db.Name){ continue; }
    $dropDB += $db.Name
}

$dropDB

<#
foreach($dbname in $dropDB){
    $database = $olapserver.Databases.FindByName($dbname)
    echo "Dropping $($database.Name)"
    $database.Drop()
}

#>

