﻿$servername  = 'NVEIHOSTODBP5'
# NVEIHOSTODBP1, NVEIHOSTODBP3, NVEIHOSTODBP4, NVEIHOSTODBP5

$exclude_list  = @(
"prod\Administrator",
"prod\DBA",
"prod\Deployment Admins - Client DB",
"prod\VH EI CubeDev",
"prod\OLAP Admins",
"prod\ClientCustomizationDevTeam"
)

[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.AnalysisServices") | Out-Null

$olapserver = New-Object 'Microsoft.AnalysisServices.Server'
$olapserver.connect($servername)

$droplogin =@()

$administrators = $olapserver.Roles["Administrators"]

foreach($member in $administrators.Members){
    if($member.Name.ToUpper().StartsWith('PROD') -or $member.Name.ToUpper().StartsWith('D2HAWKEYE')){
        if($exclude_list -icontains $member.Name) { continue; }
        $droplogin += $member.Name
    }
}

$droplogin
<#
foreach($username in $droplogin){
    $administrators = $olapserver.Roles["Administrators"]

    $todrop = $administrators.Members | Where-Object {$_.Name -eq $username}
    echo "Dropping $($todrop.Name)"
    $administrators.Members.Remove($todrop) | Out-Null
    $administrators.Update() 
    
}
#>