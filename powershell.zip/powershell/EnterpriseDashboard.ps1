﻿ $serverlist = @(
"NPEIBACKUPP1",
"NVEIHOSTRDBP1",
"NVEIHOSTRDBP2",
"NVEIHOSTRDBP3",
"NVEIHOSTRDBP4",
"NVEIRDBP1",
"NVEIRDBP2",
"NVEIRDBP8",
"NPEIODBP2",
"NVEIADBP02",
"NVEIRDBPC2",
"NVEIRDBPC3",
"NVEIRDBPC6",
"NVEIPROCRDB01",
"NVEIPROCRDB02",
"NVEIPROCRDB03",
"NVEIPROCRDB04",
"NVEISVCQCP2",
"NVSOAMDBP2.d2hawkeye.net",
"NVEI2HOSTRDBU01",
"NVEI2ADBU01",
"NVEI2ADBU02",
"NVEI1RDBU1",
"NVEI1RDBU3",
"NVEI1ADBU10",
"NVEI1ADBU11"
)


$data=Invoke-WebRequest "http://10.128.158.240:80/ords/edb_dashboard/mssql/list" -UseBasicParsing  | convertFrom-Json | Select  -expand items
#$data

foreach ($servername in $serverlist) {
    foreach ($i in $data){
        $params=Invoke-Sqlcmd -ServerInstance $servername -query $i.sqlquery | Select-Object * -ExcludeProperty ItemArray, Table, RowError, RowState, HasErrors | ConvertTo-Json
        #$params
        Invoke-WebRequest -UseBasicParsing -Uri $i.url -ContentType application/json -Method POST -Body $params 
    }
}