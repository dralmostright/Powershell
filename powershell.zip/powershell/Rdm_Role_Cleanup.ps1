﻿#param($servername, $path, $type, $olddomain)

$servername = 'NVEIRDBPC6'
$path = '\\npeibackupp1\Adhoc_Backup\Projects\MSSQL_Audit\Cleanup'
$type = 'pre'
$olddomain = 'VERISKHEALTH'
$logfile = "$path\$($servername)_Log.txt"

function LogMessage{
    param($msg)
    echo $msg
    echo $msg | out-file -Append $logfile
}
Function ListUser{
    param($servername, $olddomain, $csvfile)
    $userArray = @()
    [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null
    $server = New-Object Microsoft.SqlServer.Management.Smo.Server $servername
    $dbs = $server.Databases

    foreach($db in $dbs){
        if($db.Status -ieq 'OFFline') {continue}
        foreach($user in $db.Users){
            if($user.Name.ToUpper().StartsWith($olddomain.ToUpper())){
                $userResult = New-Object PSObject -Property @{
                    "USerType" = "DBUser";
                    "Database" = $db.Name;
                    "Username" = $user.Name;
                    "LoginType" = $user.LoginType;
                } 
                $userArray += $userResult
            }
        }
    }

    $logins = $server.Logins
    foreach($login in $logins){
        if($login.Name.ToUpper().StartsWith($olddomain.ToUpper())){
            $userResult = New-Object PSObject -Property @{
                "USerType" = "Login";
                "Database" = "None";
                "Username" = $login.Name;
                "LoginType" = $login.LoginType;
            } 
            $userArray += $userResult
        }
    }

    $userArray | Export-Csv -path $csvfile -NoTypeInformation
}

Function CleanUser{
    param($server, $userType, $database, $username, [ref]$Errorlist)
    
    if($userType -eq "DBUser"){
        LogMessage "Dropping User $username in $database"
        $db = $server.Databases | Where-object {$_.Name -eq $database}
        $u = $db.Users | Where-object {$_.Name -eq $username}
        try{
            $u.Drop()
        }catch{
            $ErrorList.value += "Drop Failed for User $username in $database"
        }
        LogMessage "Dropped user $username in $database"
    }
    elseif($userType -eq "Login"){
        LogMessage "Dropping Login $username"
        $login = $server.Logins | Where-Object {$_.Name -eq $username}
        try{
            $login.Drop()
        }
        catch{
            $ErrorList.Value += "Drop Failed for Login $username"
        }
        LogMessage "Dropped Login $username"
    }
}

$csvfile = $path + '\'+$servername+'_RdmcleanUplist.csv'
$Errorlist = @()
if($type -eq "pre"){
    ListUser $servername $olddomain $csvfile
}
elseif($type -eq "post"){
    $userArray = Import-Csv -path $csvfile
    [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null
    $server = New-Object Microsoft.SqlServer.Management.Smo.Server $servername

    foreach($user in $userArray){
        CleanUser $server $user.UserType $user.Database $user.Username ([Ref]$Errorlist)
    }
    if($Errorlist.Count -gt 0){
        LogMessage "Error Summary:"
        foreach($err in $Errorlist){
            LogMessage "`t`t $err"
        }
    }
}