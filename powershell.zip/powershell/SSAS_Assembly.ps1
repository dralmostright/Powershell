﻿clear-host
[Reflection.Assembly]::LoadWithPartialName("Microsoft.AnalysisServices") | Out-Null


### Parameters to configure as per requirement
$AssemblyName = "CubeOps"
$outputDIR="C:\Temp"
$AssemblyFilePath = "C:\temp\assembly_test\VH.VHIP.CubeOps.Embedded.dll"
$servers=@("NVEIODBP1","NVEIODBP2","NVEIODBP8","NPEIODBP2","NPEIODBP3","NPEIODBP5","NPEIODBP6","NPEIODBP8")
$job = 2 ## 1 for setting Assemblies, 2 for verifying Assemblies, 3 for dropping Assmeblies


$FormatEnumerationLimit = -1
$debug=1
$global:msgCollection=""
function logMessage{
    if($debug -eq 1){
        write-host $args
    }
    $curVal=$msgCollection + "`n" + $args
    #Set-Variable -Name "msgCollection" -Value $curVal -Scope Global
    $global:msgCollection = $global:msgCollection + "`r`n" + $args
}

Function DropDBAssembly($db, $assemName){
    LogMessage "Info |" (Get-Date) "| Dropping $assemName in $($db.Name)"
    $assembly_to_drop = $db.Assemblies | Where-object {$_.Name -ieq $assemName}
    try{
        $assembly_to_drop.Drop();
        LogMessage "Info |" (Get-Date) "| Dropped Assembly $assemName"
    }catch{
        LogMessage "Error|" (Get-Date) "| Drop Failed : $($_.Exception.Message)"
    }
}

Function DropAssembly{
    $global:msgCollection = "";
    $outputfile="$outputDIR\DropAssemblyLogs_$(get-date -format "dd_MM_yyyy").txt"
    foreach($SSASServerName in $servers){
        # Try to connect to the SSAS server
        $SSASServer = New-Object Microsoft.AnalysisServices.Server
        $SSASServer.Connect($SSASServerName)
        LogMessage "Info |" (Get-Date) "| ---------------------------------------------------------------- " 
        LogMessage "Info |" (Get-Date) "| Dropping Assembly in server $($SSASServerName)"
        LogMessage "Info |" (Get-Date) "| ---------------------------------------------------------------- "        
        foreach ($DB in $SSASServer.Databases)
        {
            DropDBAssembly $DB $assemblyName
        }
        LogMessage "Info |" (Get-Date) "| ---------------------------------------------------------------- "        
        LogMessage "Info |" (Get-Date) "| Competed Dropping Assembly in server $($SSASServerName)"
        LogMessage "Info |" (Get-Date) "| ---------------------------------------------------------------- "        
        $global:msgCollection | Out-File $outputfile 
        $SSASServer.disconnect()
        
    }     
}

Function AddDBAssembly($db, $assemName, $dllPath){
    $newAssembly = New-Object Microsoft.AnalysisServices.ClrAssembly($assemName, $assemName)
    $newAssembly.LoadFiles($dllPath, $true)
    $newAssembly.PermissionSet="Unrestricted";  
    $myImpersonationInfo=New-Object Microsoft.AnalysisServices.ImpersonationInfo;
    $myImpersonationInfo.ImpersonationMode="ImpersonateServiceAccount";           
    $newAssembly.ImpersonationInfo=$myImpersonationInfo;
    LogMessage "Info |" (Get-Date) "| Adding Assembly $assemName in $($db.Name)"
    try{
        $x=$DB.Assemblies.add($newAssembly)
        $DB.Assemblies.Update()
        LogMessage "Info |" (Get-Date) "| Added Assembly $assemName in $($db.Name)"
    }catch{
        LogMessage "Error|" (Get-Date) "| Failed Adding Assembly : $($_.Exception.Message)"    
    }
}


Function AddAssembly{
    $global:msgCollection = "";
    $outputfile="$outputDIR\SetAssemblyLogs_$(get-date -format "dd_MM_yyyy").txt"
    foreach($SSASServerName in $servers){
        # Try to connect to the SSAS server
        $SSASServer = New-Object Microsoft.AnalysisServices.Server
        $SSASServer.Connect($SSASServerName)
        LogMessage "Info |" (Get-Date) "| ---------------------------------------------------------------- " 
        LogMessage "Info |" (Get-Date) "| Adding Assembly in server $($SSASServerName)"
        LogMessage "Info |" (Get-Date) "| ---------------------------------------------------------------- "        
        foreach ($DB in $SSASServer.Databases)
        {
            AddDBAssembly $DB $assemblyName $AssemblyFilePath
        }
        LogMessage "Info |" (Get-Date) "| ---------------------------------------------------------------- " 
        LogMessage "Info |" (get-Date) "| Competed Adding Assembly in server $($SSASServerName)"
        LogMessage "Info |" (Get-Date) "| ---------------------------------------------------------------- "  
        $SSASServer.disconnect()
        
    } 
    $global:msgCollection | Out-File $outputfile 
}

Function VerifyAssembly{
     $msgCollection = "";
     $assemblyList = @()
     $VerificationCSV="$outputDIR\AssemblyVerification_$(get-date -format "dd_MM_yyyy").csv"
     foreach($SSASServerName in $servers){
        # Try to connect to the SSAS server
        $SSASServer = New-Object Microsoft.AnalysisServices.Server
        $SSASServer.Connect($SSASServerName)
        Write-Host "Server:" $SSASServerName
        foreach ($DB in $SSASServer.Databases)
        {
            Write-host "Found" $DB.Assemblies.count "assembly for" $DB.Name
            $assem = $DB.Assemblies | Where-Object {$_.Name -ieq $AssemblyName}
            if($assem -eq $Null){
                [array]$myassembly = New-Object PSObject -Property @{
                    "Server" = $SSASServerName
                    "Database"= $DB.Name	
                    "Assembly" =""
                    "AssemblyFile" = ""
                    "Permission" =""
                    "ImpersonationInfo" = ""
                 }
                 $assemblyList += $myassembly
            }
            else{
                $afilelist = ''
                foreach($assemfile in $assem.Files){
                    $afilelist +="[ $($assemfile.Name) ] "
                }
                [array]$myassembly = New-Object PSObject -Property @{
                    "Server" = $SSASServerName
                    "Database"= $DB.Name	
                    "Assembly" =$assem.Name
                    "AssemblyFile" = $afilelist
                    "Permission" =$assem.PermissionSet
                    "ImpersonationInfo" =$assem.ImpersonationInfo.ImpersonationMode
                 }
                 $assemblyList += $myassembly
            }
        }
        
        $SSASServer.disconnect()
    }
    $assemblyList | Select Server, Database, Assembly, AssemblyFile, Permission, ImpersonationInfo | Export-CSV -Path $VerificationCSV -NoTypeInformation     
}


#main execution
if($job -eq 1){
    AddAssembly
}
elseif($job -eq 2){
    VerifyAssembly
}
elseif($job -eq 3){
    DropAssembly
}