﻿### Parameters to be set ####

$servername='NVEIHOSTODBP5'
$serverFQDN="$($servername).PROD.OPS.GLOBAL.AD"
$scriptpath = 'C:\MSSQL\scripts\powershell\OLAP_RemoteSize.ps1'


$logfile = "C:\temp\$($servername)_size.txt"
Invoke-Command -Computername $serverFQDN -Filepath $scriptpath | Tee-Object $logfile