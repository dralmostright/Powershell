﻿[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null

$serverlist = @(

)

#$servername = 'nveidbbackupp1'

foreach($servername in $serverlist){
    echo "Updating operrators in $servername"
    $sqlserver = new-object "Microsoft.SqlServer.Management.Smo.Server" $servername
    $dbaOp = $sqlserver.JobServer.Operators | where-object {$_.Name -eq 'SQLDBA'}

    $vemail = $dbaOp.EmailAddress
    $cemail = $vemail.replace('verscend', 'cotiviti')
    $dbaOp.EmailAddress = $cemail
    $dbaOp.Alter()
}





