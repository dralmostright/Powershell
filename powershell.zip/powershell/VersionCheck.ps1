﻿
$serverlist = @(
'npeirdbp1',
'npeirdbp2',
'npeirdbp3',
'Npeirdbp8',
'npeirdbpc4',
'npeirdbpc5',
'npeirdbpc7',
'Npeirdbpc8',
'nveiadbp1',
'nveiadbp2',
'nveirdbp1',
'nveirdbp2',
'Nveirdbp8',
'nveirdbpc2',
'nveirdbpc3',
'nveirdbpc6',
'nveisvcqcp1',
'nveisvcqcp2',
'nveiadbp3',
'nveiadbp8',
'nveiadbp6',
'nveiadbp7'   
)
$servertype = 'sql'

Function SQLVersion{
    param($sqlserver)
    [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.Smo') | Out-Null
    $server = New-Object 'Microsoft.SqlServer.Management.Smo.Server' $sqlserver
    echo "$($server.Name.PadRight(20)) $($server.VersionString.PadRight(20))"
}

Function OLAPVersion{
    param($olapserver)
    [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.AnalysisServices') | Out-Null
    $server = New-Object 'Microsoft.AnalysisServices.Server'
    $server.connect($olapserver)
    echo "$($server.Name.PadRight(20)) $($server.Version.PadRight(20))"
}

foreach($ser in $serverlist){
    if($servertype -ieq "OLAP"){
        OLAPVersion $ser
    }
    elseif($servertype -ieq "SQL"){
        SQLVersion $ser
    }
}
