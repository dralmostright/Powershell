﻿[System.Reflection.Assembly]::LoadwithPartialName('Microsoft.Sqlserver.Smo') | out-null



$serverlist = @(
"10.48.2.85",
"10.48.2.185",
"10.48.2.184",
"NVEIHOSTRDBP4",
"NVEIHOSTODBP1",
"NVEIHOSTODBP3",
"NVEIHOSTODBP4",
"NVEIHOSTODBP5"
)

$csvfile = "C:\Temp\Server_details.csv"
$server_array = @()
foreach($servername in $serverlist){
    $cores = 0
    $srv = new-Object Microsoft.SqlServer.Management.Smo.Server($servername)  
    $db = New-Object Microsoft.SqlServer.Management.Smo.Database  
    $db = $srv.Databases.Item("MASTER")  
    $ds =@()
    $ds = $db.ExecuteWithResults("select cpu_count from sys.dm_os_sys_info")  
    Foreach ($t in $ds.Tables)  
    {  
       Foreach ($r in $t.Rows)  
       {  
            $c = $t.Columns | Where-Object {$_.ColumnName -ieq "cpu_count"}
            $cores = $r.Item($c)
       }  
    }
    
    $server_details = New-Object PSObject -Property @{
        "Server" = $servername
        "LogicalCore" = $cores
    }
    $server_array += $server_details  
}

$server_array | select Server, LogicalCore | export-csv $csvfile -NoTypeInformation