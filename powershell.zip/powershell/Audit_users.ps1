﻿$servername='npeiodbp2'

$csvfile = "C:\temp\$($servername)_AuditReport.csv"

Function DH_getGroupMember($fValue){
    $ServerName = '10.48.27.50'
    $DomainEntry = New-Object -TypeName System.DirectoryServices.DirectoryEntry "LDAP://$ServerName" #,$($Credential.UserName),$($Credential.GetNetworkCredential().password)
    $DomainName = $DomainEntry.name
    $Searcher = New-Object -TypeName System.DirectoryServices.DirectorySearcher
    $Searcher.Filter="(&(objectCategory=group)(name=$fValue*))"
    $Searcher.SearchRoot = $DomainEntry
    $me = $Searcher.FindAll()
    $alluser = @()
    foreach($mem in $me.Properties.member){
        $disp = $mem.substring(3,$mem.IndexOf(',')-3)
        $inuser = DH_getUser "$disp" 1
        $alluser += $inuser
    }
    return $alluser
}
function DH_getUser($fValue, $checkbit){
  $ServerName = '10.48.27.50'
  $DomainEntry = New-Object -TypeName System.DirectoryServices.DirectoryEntry "LDAP://$ServerName" #,$($Credential.UserName),$($Credential.GetNetworkCredential().password)
  $DomainName = $DomainEntry.name
  $Searcher = New-Object -TypeName System.DirectoryServices.DirectorySearcher
  if($checkbit -eq 0){
    $Searcher.Filter="(sAMAccountName=$fValue)"
  }
  else{
    $Searcher.Filter="(&(objectCategory=person)(objectClass=User)(name=$fValue*))"
  }
  $Searcher.SearchRoot = $DomainEntry
  $me = $Searcher.FindAll()
  $me.Properties
}

Function PROD_getGroupMember($fValue){
    $ServerName = '10.48.2.176'
    $DomainEntry = New-Object -TypeName System.DirectoryServices.DirectoryEntry "LDAP://$ServerName" #,$($Credential.UserName),$($Credential.GetNetworkCredential().password)
    $DomainName = $DomainEntry.name
    $Searcher = New-Object -TypeName System.DirectoryServices.DirectorySearcher
    $Searcher.Filter="(&(objectCategory=group)(name=$fValue*))"
    $Searcher.SearchRoot = $DomainEntry
    $me = $Searcher.FindAll()
    $alluser = @()
    foreach($mem in $me.Properties.member){
        $disp = $mem.substring(3,$mem.IndexOf(',')-3)
        $inuser = PROD_getUser "$disp" 1
        if($inuser -eq $null){ continue }
        $alluser += $inuser
    }
    $alluser
}
function PROD_getUser($fValue, $checkbit){
  $ServerName = '10.48.2.176'
  $DomainEntry = New-Object -TypeName System.DirectoryServices.DirectoryEntry "LDAP://$ServerName" #,$($Credential.UserName),$($Credential.GetNetworkCredential().password)
  $DomainName = $DomainEntry.name
  $Searcher = New-Object -TypeName System.DirectoryServices.DirectorySearcher
  if($checkbit -eq 0){
    $Searcher.Filter="(sAMAccountName=$fValue)"
  }
  else{
    $Searcher.Filter="(&(objectCategory=person)(objectClass=User)(name=$fValue*))"
  }
  $Searcher.SearchRoot = $DomainEntry
  $me = $Searcher.FindAll()
  $me.Properties
}

Function get_values($arr){
    if($arr -ne $null){
        $arr[0]
    }
    else{
        $null
    }
}


[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null
$server = New-Object Microsoft.SqlServer.Management.Smo.Server $servername
$AuditArray = @()
$userArray =@()
$serverlogins = $server.logins
$dbs = $server.Databases
$systemDbs = @('master', 'model', 'msdb', 'tempdb')
$systemUsers = ('dbo', 'guest', 'information_schema', 'sys')
foreach($db in $dbs){
    if($systemDbs -icontains $($db.Name)) { continue }
    if ($db.status -ieq 'Offline'){ continue }
    foreach($user in $db.Users){
        if ($systemUsers -icontains $($user.Name)) { continue }
        $userResult = New-Object PSObject -Property @{
            "Database" = $db.Name;
            "Username" = $user.Name;
            "LoginType" = $user.LoginType;
            "SqlUserCreated" = $user.CreateDate;
        } 
        $userArray += $userResult
    }
}

foreach($usr in $userArray){
    if($($usr.LoginType) -ieq 'WindowsGroup' -and $($usr.Username).ToUpper().StartsWith('PROD') ){
        $DomainlessUsername = $($usr.Username).ToUpper().replace('PROD\','').replace('D2HAWKEYE\','')
        echo "$($usr.Database) <======> $DomainlessUsername "
        try{
            $mem_list = PROD_getGroupMember "$($DomainlessUsername)" #-ErrorAction Stop
            #if($mem_list.length -eq 0) { throw "Empty array"}
            #else{
                foreach($mem in $mem_list){
                    $audit = New-Object PSObject -property @{
                        "Database" = $usr.Database;
                        "Username" = get_values($mem.samaccountname);
                        "Full_Name" = get_values($mem.name);
                        "Email" = get_values($mem.mail);
                        "Account_Type" = "";
                        "Account_Active" =get_values($mem.useraccountcontrol);
                        "Expiry_Date" = get_values($mem.accountexpires);
                        "Account_Group" =  $usr.username;
                        "Create_Date" = get_values($mem.whencreated);
                    }
                    $AuditArray += $audit
            
                }
            #}
        }catch{
            echo "Error $($_.Exception.Message)"
            $audit = New-Object PSObject -property @{
                "Database" = $usr.Database;
                "Username" = "";
                "Full_Name" = "";
                "Email" = "";
                "Account_Type" = "";
                "Account_Active" ="";
                "Expiry_Date" = "";
                "Account_Group" =  $usr.username;
                "Create_Date" = "";
            }
                $AuditArray += $audit
        }
    }
    elseif($($usr.LoginType) -ieq 'WindowsGroup' -and $($usr.Username).ToUpper().StartsWith('D2HAWKEYE') ){
        $DomainlessUsername = $($usr.Username).ToUpper().replace('PROD\','').replace('D2HAWKEYE\','')
        echo "$($usr.Database) <======> $DomainlessUsername "
        try{
            $mem_list = DH_getGroupMember "$($DomainlessUsername)" #-ErrorAction Stop
            if($mem_list.length -eq 0) { throw "Empty array"}
            else{
                foreach($mem in $mem_list){
                    $audit = New-Object PSObject -property @{
                        "Database" = $usr.Database;
                        "Username" = get_values($mem.samaccountname);
                        "Full_Name" = get_values($mem.name);
                        "Email" = get_values($mem.mail);
                        "Account_Type" = "";
                        "Account_Active" =get_values($mem.useraccountcontrol);
                        "Expiry_Date" = get_values($mem.accountexpires);
                        "Account_Group" =  $usr.username;
                        "Create_Date" = get_values($mem.whencreated);
                    }
                    $AuditArray += $audit
            
                }
            }
        }catch{
            echo "Error $($_.Exception.Message)"
            $audit = New-Object PSObject -property @{
                "Database" = $usr.Database;
                "Username" = "";
                "Full_Name" = "";
                "Email" = "";
                "Account_Type" = "";
                "Account_Active" ="";
                "Expiry_Date" = "";
                "Account_Group" =  $usr.username;
                "Create_Date" = "";
            }
                $AuditArray += $audit
        }
    }    

    elseif($($usr.LoginType) -ieq 'WindowsUser' -and $($usr.Username).ToUpper().StartsWith('PROD')){
        $DomainlessUsername = $($usr.Username).ToUpper().replace('PROD\','').replace('D2HAWKEYE\','')
        try{
        
            $mem = PROD_getUser $DomainlessUsername 0
            $audit = New-Object PSObject -property @{
                "Database" = $usr.Database;
                "Username" = get_values($mem.samaccountname);
                "Full_Name" = get_values($mem.name);
                "Email" =  get_values($mem.mail);
                "Account_Type" = "";
                "Account_Active" = get_values($mem.useraccountcontrol);
                "Expiry_Date" = get_values($mem.accountexpires);
                "Account_Group" = "";
                "Create_Date" = get_values($mem.whencreated);
            }

            $AuditArray += $audit
       
        }catch{
            echo "Error $($_.Exception.Message)"
        }
        
    }
    elseif($($usr.LoginType) -ieq 'WindowsUser' -and $($usr.Username).ToUpper().StartsWith('D2HAWKEYE')){
        $DomainlessUsername = $($usr.Username).ToUpper().replace('PROD\','').replace('D2HAWKEYE\','')
        try{
        
            $mem = DH_getUser $DomainlessUsername 0
            $audit = New-Object PSObject -property @{
                "Database" = $usr.Database;
                "Username" = get_values($mem.samaccountname);
                "Full_Name" = get_values($mem.name);
                "Email" =  get_values($mem.mail);
                "Account_Type" = "";
                "Account_Active" = get_values($mem.useraccountcontrol);
                "Expiry_Date" = get_values($mem.accountexpires);
                "Account_Group" = "";
                "Create_Date" = get_values($mem.whencreated);
            }

            $AuditArray += $audit
       
        }catch{
            echo "Error $($_.Exception.Message)"
        }
        
    }
    else{
        $userlogin = $serverlogins | where-object {$_.name -ieq $($usr.Username)}
        if($userlogin -eq $null) {$accountActive = "Orphan User"}
        else{
            $accountActive = switch ($userlogin.IsDisabled){
                "True" {"No"}
                "False" {"Yes"}
            }
        } 
        $audit = New-Object PSObject -property @{
            "Database" = $usr.Database;
            "Username" = $usr.Username;
            "Full_Name" = $usr.Username;
            "Email" = "";
            "Account_Type" = "";
            "Account_Active" = $accountActive;
            "Expiry_Date" = "";
            "Account_Group" = "";
            "Create_Date" = $userlogin.CreateDate;
        }

        $AuditArray += $audit
    
    }
}

$AuditArray | select Database, Username, FUll_Name, Email, Account_Type, Account_Active, Expiry_Date, Account_Group, Create_Date | Export-Csv -Path $csvfile -NoTypeInformation 