﻿[System.Reflection.Assembly]::LoadwithpartialName('Microsoft.SqlServer.Smo') #| Out-Null
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoExtended") #| Out-Null

$serverlist = @(
'hrpcndev4dbs101',
'hrpdev-wh01',
'hrpdevapp401',
'hrpdevcn01',
'HRPDEVCN02',
'HRPDEVCN03',
'hrpdevcn04',
'hrpdevdb01',
'hrpdevdbs111a',
'HRPDEVEDS01',
'hrpdevetl01',
'hrpdevetl02',
'hrpdevetl111a',
'HRPDEVHIM01',
'HRPDEVHIM02',
'HRPDEVRE01',
'HRPDEVRE02',
'HRPDEVRE03',
'HRPDEVRE04',
'hrpdevsn01',
'HRPDEVSN02',
'HRPTSTCN01',
'HRPTSTCN02',
'hrptstdbs001',
'hrptstdbs002',
'hrptstdbs101',
'hrptstdbs201',
'HRPTSTDBS301',
'hrptstdbs601',
'hrptstdbs900',
'hrptstdbs901',
'hrptstetl001',
'hrptstetl002',
'HRPTSTHIM01',
'HRPTSTRE02',
'HRPTSTSN01',
'HRPTSTSN02',
'RICCNDEVETL01',
'ricedsdev1dbs01'
)

$Joblist = @()
$csvfile = "C:\temp\Jobs.csv"

foreach($servername in $serverlist){
    $sqlserver = New-Object 'Microsoft.SqlServer.Management.Smo.Server' $servername
    $sqlserver.ConnectionContext.StatementTimeout = 0
    #$centralDB = $sqlserver.Databases.Item('DBA')
    $sqlserver.name
    #$sqlserver.JobServer.Jobs | select Name, OperatorToEmail 
    foreach($ijob in $sqlserver.JobServer.Jobs){
        $Job_info = New-Object PSObject -Property @{
            "ServerName" = $servername;
            "Job" = $ijob.Name;
            "Operator" = $ijob.OperatorToEmail;
        } 
        $Joblist += $Job_info
    }
}

$Joblist | select ServerName, Job, Operator | Export-Csv -Path $csvfile -NoTypeInformation 