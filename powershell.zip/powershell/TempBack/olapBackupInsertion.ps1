﻿$serverlist = @('NPEIODBP3','NPEIODBP5', 'NPEIODBP6', 'NPEIODBP8')
$dict = @{}


$dict.set_item('NPEIODBP3', 'NVEIHOSTODBP3')
$dict.set_item('NPEIODBP5', 'NVEIHOSTODBP5')
$dict.set_item('NPEIODBP6', 'NVEIHOSTODBP1')
$dict.set_item('NPEIODBP8', 'NVEIHOSTODBP4')


[System.Reflection.Assembly]::LoadwithpartialName('Microsoft.SqlServer.Smo') | Out-Null
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.AnalysisServices") | Out-Null

$centralserver = New-Object 'Microsoft.SqlServer.Management.Smo.Server' 'NPEIBACKUPP1'
$centralDB = $centralserver.Databases.Item('REPORT')
foreach($servername in $serverlist){
    $SSASServer = New-Object Microsoft.AnalysisServices.Server
    $SSASServer.connect($servername)
    $i=0
    foreach($db in $SSASServer.Databases){
        $query = "insert into dbo.OLAPBackupRestore(Servername, RestoreServerName, DatabaseName, Status) values('$servername','$($dict.get_item($servername))','$($db.Name)', 0)"
        echo $query
        $centralDB.ExecuteNonQuery($query)
    }
}