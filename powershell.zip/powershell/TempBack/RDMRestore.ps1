﻿Import-Module "$($PSScriptRoot)\Writer.psm1"
Import-Module "$($PSScriptRoot)\rdmrestore.psm1"
Import-Module "$($PSScriptRoot)\ThreadHelper.psm1"



$centralservername = 'NPEIBACKUPP1'
$centralDBName = 'REPORT'
$BackupDir = '\\nveiprocrdb01\Virtualization_backup'
$serverlist = @('NVEIHOSTRDBP1','NVEIHOSTRDBP2','NVEIHOSTRDBP3','NVEIHOSTRDBP4')

[System.Reflection.Assembly]::LoadwithpartialName('Microsoft.SqlServer.Smo') | Out-Null

$MaxThreads = $serverlist.Count
$ISS = [system.management.automation.runspaces.initialsessionstate]::CreateDefault()
$ISS.ImportPSModule("$($PSScriptRoot)\rdmrestore.psm1")
$ISS.ImportPSModule("$($PSScriptRoot)\Writer.psm1")
$RunspacePool = [runspacefactory]::CreateRunspacePool(1, $MaxThreads, $ISS, $Host)
$RunspacePool.Open() | Out-Null

$jobs=@()

### Execute PreRecord in threads
$jobs = ThreadInitiate $RunspacePool $CentralServerName $serverlist $BackupDir
ThreadStatus $jobs
$Errorlist = ThreadCleanup $jobs

$RunspacePool.Close()