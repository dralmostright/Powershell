﻿Function ThreadInitiate{
    param($RunspacePool, $centralServerName, $serverlist, $backupDir)
    $jobs=@()
    foreach($servername in $serverlist){
        $Powershell = [powershell]::Create()
        $Powershell.AddScript({
            param($centralServerName, $servername, $backupDir)
            $serverlog = "$backupDir\SecondLog\$($servername).txt"
            ExecBackupRestore $centralServerName $servername $serverlog $backupDir
        }).AddArgument($CentralServerName).AddArgument($servername).AddArgument($backupDir) | Out-Null
        
        $Powershell.RunspacePool = $RunspacePool 

        $Handle = $Powershell.BeginInvoke()
        $job = "" | Select-Object Handle, Thread, Object
        $job.Handle = $Handle
        $job.Thread = $Powershell
        $job.Object = $servername.ToString()

        $jobs += $job
    }
    return $jobs
}

Function ThreadStatus{
    param($jobs)
    while(1){
        if($($jobs | where-object {$_.Handle.IsCompleted -eq $False}).count -eq 0){
            break
        }
        #Wait for 1 minute
        Start-Sleep -Seconds 60
    }
}

Function ThreadCleanup{
    param($Jobs)
    $Errorlist =@()
    ForEach($Job in $($Jobs | Where-Object {$_.Handle.IsCompleted -eq $True})){
        #$threadOutput = $job.Handle 
        $Errorlist += $Job.Thread.EndInvoke($Job.Handle) 
        $Job.Thread.Dispose()
        $Job.Thread = $Null
        $Job.Handle = $Null
    }
    return $Errorlist
}