﻿function ExecBackupRestore{
    param($centralServerName, $servername, $serverlog, $backupDir)

    [System.Reflection.Assembly]::LoadwithpartialName('Microsoft.SqlServer.Smo') | Out-Null
    [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.AnalysisServices") | Out-Null

    $centralserver = New-Object 'Microsoft.SqlServer.Management.Smo.Server' $centralServerName
    $centralserver.ConnectionContext.StatementTimeout = 0
    $centralDB = $centralserver.Databases.Item('REPORT')
    
    while(1){
        $loopQuery = "Select * from dbo.OLAPBackupRestore where RestoreServerName = '$servername' and status = 6"
        $loopResult = $centralDB.ExecuteWithResults($loopQuery)
        if($loopResult.Tables[0].Rows.Count -eq 0){
            LogMessage "$servername :: Restore Completed" $serverlog
            break
        }
        $jobQuery = "Select Top 1 * from dbo.OLAPBackupRestore where RestoreServerName = '$servername' and Status = 6"
        $QueryResult = $centralDB.ExecuteWithResults($jobQuery)
        if($QueryResult.Tables[0].Rows.Count -eq 0){
            DisplayMessage "$servername :: No Jobs in Queue" $serverlog
            sleep 30
            continue
        }

        $restoreJob = $QueryResult.Tables[0].Rows[0]
        $jobID = $restoreJob.JobID
        $BackupServerName = $restoreJob.ServerName
        $DatabaseName = $restoreJob.DatabaseName
        $DataDir = $restoreJob.DataDir
        $BackupDir = $restoreJob.BackupDir
        $partDir = $restoreJob.PartDir

        # Update the table indicating backup started
        $centralDB.ExecuteNonQuery("Update dbo.OLAPBackupRestore set Status = 3 where JobID = $jobID")
        LogMessage "$servername :: Restore Started for db $DatabaseName" $serverlog
        try{
            #Server Connection
            $SSASServer = New-Object Microsoft.AnalysisServices.Server
            $SSASServer.connect($servername)

            #Getting Domain name
            $comp_domain = $(Get-WmiObject Win32_ComputerSystem).Domain
            $fqdn = "$($servername).$($comp_domain)"

            #Creating Data and Log Directory if doesnot exists
            Invoke-Command -ComputerName $fqdn -ScriptBlock { param($DataDir) New-Item -ItemType directory -Path $DataDir -Force } -ArgumentList $DataDir | out-Null
            if([System.DBNull]::Value.Equals($partDir)) {
                #do nothing
            }else{
                Invoke-Command -ComputerName $fqdn -ScriptBlock { param($partDir) New-Item -ItemType directory -Path $partDir -Force } -ArgumentList $partDir | out-Null
            }

            #Configure Restore Parameters
            $RestoreInfo = New-Object Microsoft.AnalysisServices.RestoreInfo
            $RestoreInfo.DatabaseName = $DatabaseName
            $RestoreInfo.AllowOverwrite = $false
            $REstoreInfo.File="$($backupDir)\$($DatabaseName).abf"
            $RestoreInfo.DBStorageLocation = $DataDir

            # Execute restore
            $SSASServer.restore($RestoreInfo)

            #Update Table on completion of restore
            $centralDB.ExecuteNonQuery("Update dbo.OLAPBackupRestore set Status = 4 where JobID = $jobID")
            LogMessage "$servername :: Restore Completed for db $DatabaseName" $serverlog


        }catch{
            $ErrMsg = "$($_.Exception.Message.Replace("'", " "))"
            #Update Table on Failure of restore
            $centralDB.ExecuteNonQuery("Update dbo.OLAPBackupRestore set Status = 200, Remarks ='$ErrMsg' where JobID = $jobID")
            LogMessage "$servername :: Restore Failed for db $DatabaseName" $serverlog
        }

    }
    
    #Close central server
    $centralserver.ConnectionContext.Disconnect() 

}