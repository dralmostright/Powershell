﻿Import-Module "$($PSScriptRoot)\Writer.psm1"
Import-Module "$($PSScriptRoot)\olapbackup.psm1"
Import-Module "$($PSScriptRoot)\ThreadHelper.psm1"

$centralservername = 'NPEIBACKUPP1'
$centralDBName = 'REPORT'
$BackupDir = '\\npeibackupp1\Adhoc_Backup\Virtualization'
$serverlist = @('NPEIODBP3','NPEIODBP5', 'NPEIODBP6', 'NPEIODBP8')


[System.Reflection.Assembly]::LoadwithpartialName('Microsoft.SqlServer.Smo') | Out-Null

$MaxThreads = $serverlist.Count
$ISS = [system.management.automation.runspaces.initialsessionstate]::CreateDefault()
$ISS.ImportPSModule("$($PSScriptRoot)\olapbackup.psm1")
$ISS.ImportPSModule("$($PSScriptRoot)\Writer.psm1")
$RunspacePool = [runspacefactory]::CreateRunspacePool(1, $MaxThreads, $ISS, $Host)
$RunspacePool.Open() | Out-Null

$jobs=@()

### Execute PreRecord in threads
$jobs = ThreadInitiate $RunspacePool $CentralServerName $serverlist $BackupDir
ThreadStatus $jobs
$Errorlist = ThreadCleanup $jobs

$RunspacePool.Close()