﻿$serverlist = @('NPEIRDBP1','NPEIRDBP2', 'NPEIRDBP3', 'NPEIRDBP8')
$dict = @{}


$dict.set_item('NPEIRDBP1', 'NVEIHOSTRDBP1')
$dict.set_item('NPEIRDBP2', 'NVEIHOSTRDBP2')
$dict.set_item('NPEIRDBP3', 'NVEIHOSTRDBP3')
$dict.set_item('NPEIRDBP8', 'NVEIHOSTRDBP4')


$sysDB = @('master', 'msdb', 'model', 'tempdb', 'distribution')

[System.Reflection.Assembly]::LoadwithpartialName('Microsoft.SqlServer.Smo') | Out-Null

$centralserver = New-Object 'Microsoft.SqlServer.Management.Smo.Server' 'NPEIBACKUPP1'
$centralDB = $centralserver.Databases.Item('REPORT')

foreach($servername in $serverlist){
    $sqlserver = New-Object 'Microsoft.SqlServer.Management.Smo.Server' $servername
    $i = 0
    echo $sqlserver.Name
    foreach($db in $sqlserver.Databases){
        
        if($sysDB -icontains $db.Name){ continue }
        if($db.Status -ieq 'Offline'){ continue }
        $query = "insert into dbo.BackupRestore(Servername, RestoreServerName, DatabaseName, Status, DOP) values('$servername','$($dict.get_item($servername))','$($db.Name)', 0, 8)"
        echo $query
        $centralDB.ExecuteNonQuery($query)
    }
}