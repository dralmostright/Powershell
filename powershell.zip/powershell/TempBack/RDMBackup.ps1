﻿Import-Module "$($PSScriptRoot)\Writer.psm1"
Import-Module "$($PSScriptRoot)\rdmbackup.psm1"
Import-Module "$($PSScriptRoot)\ThreadHelper.psm1"

$centralservername = 'NPEIBACKUPP1'
$centralDBName = 'REPORT'
#$BackupDir = '\\npeibackupp1\Adhoc_Backup\Virtualization'
$BackupDir = '\\nveiprocrdb01\Virtualization_backup'
$serverlist = @('NPEIRDBP1','NPEIRDBP2', 'NPEIRDBP3', 'NPEIRDBP8')



[System.Reflection.Assembly]::LoadwithpartialName('Microsoft.SqlServer.Smo') | Out-Null

$MaxThreads = $serverlist.Count
$ISS = [system.management.automation.runspaces.initialsessionstate]::CreateDefault()
$ISS.ImportPSModule("$($PSScriptRoot)\rdmbackup.psm1")
$ISS.ImportPSModule("$($PSScriptRoot)\Writer.psm1")
$RunspacePool = [runspacefactory]::CreateRunspacePool(1, $MaxThreads, $ISS, $Host)
$RunspacePool.Open() | Out-Null

$jobs=@()

### Execute PreRecord in threads
$jobs = ThreadInitiate $RunspacePool $CentralServerName $serverlist $BackupDir
ThreadStatus $jobs
$Errorlist = ThreadCleanup $jobs
echo $Errorlist

$RunspacePool.Close()

