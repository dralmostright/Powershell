﻿
$clientPattern = "HP"
$RDMServers = @("NVEIHOSTRDBP1", "NVEIHOSTRDBP2", "NVEIHOSTRDBP3", "NVEIHOSTRDBP4", "NVEIRDBP1", "NVEIRDBP2", "NVEIRDBP8", "NVEIPROCRDB01", "NVEIPROCRDB02", "NVEIPROCRDB03", "NVEIPROCRDB04")
$OlapServers = @("NVEIHOSTODBP1", "NVEIHOSTODBP3", "NVEIHOSTODBP4", "NVEIHOSTODBP5", "NVEIODBP1", "NVEIODBP2", "NVEIODBP8", "NVEIPROCODB01", "NVEIPROCODB02", "NVEIPROCODB03", "NVDWODBP01")


[System.Reflection.Assembly]::LoadwithpartialName('Microsoft.SqlServer.Smo') | Out-Null
[System.Reflection.Assembly]::LoadwithpartialName('Microsoft.AnalysisServices') | Out-Null
foreach($servername in $RDMServers){
    $sqlserver = New-Object 'Microsoft.sqlserver.Management.Smo.Server' $servername
    foreach($db in $sqlserver.Databases){
        if($db.name.StartsWith($clientPattern)){
            echo "$($sqlserver.name) $($db.Name)"
        }
    }
}

foreach($servername in $OlapServers){
    $olapserver = New-Object 'Microsoft.AnalysisServices.Server'
    $olapserver.connect($servername)

    foreach($db in $olapserver.Databases){
        if($db.name.StartswITH($clientPattern)){
            echo "$($olapserver.name) $($db.Name)"
        }
    }
}