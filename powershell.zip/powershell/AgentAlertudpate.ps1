﻿[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null

$serverlist = @(
"NVEIDBBACKUPP1"
)

#$servername = 'nveidbbackupp1'
$AgentAlertList = @()
$csvfile = "C:\temp\AgentAlert.csv"

foreach($servername in $serverlist){
    $servername
    $sqlserver = new-object "Microsoft.SqlServer.Management.Smo.Server" $servername
          
     foreach($ialert in $sqlserver.JObserver.Alerts){
        if($($ialert.EnumNotifications()).OperatorName -icontains 'SYSDBA'){
            echo "Removing RIC-Dveops from $($ialert.Name)"
            $ialert.RemoveNotification('SYSDBA')
            echo "Adding SQLDBA to $($ialert.Name)"
            $ialert.AddNotification('SQLDBA', [Microsoft.SqlServer.Management.Smo.Agent.NotifyMethods]::NotifyEmail)
            $ialert.alter()
        }      
               

    }
    
}



