﻿[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null

$serverlist = @(
'NVEIDBBACKUPP1'
)

#$servername = 'nveidbbackupp1'
$AgentMailProfileList = @()
$csvfile = "C:\temp\MailAgent.csv"

foreach($servername in $serverlist){
    $servername
    $sqlserver = new-object "Microsoft.SqlServer.Management.Smo.Server" $servername

 
    $AgentMailProfileInfo = New-Object PSObject -Property @{
        "ServerName" = $servername;
        "MailProfile" = $sqlserver.JobServer.DatabaseMailProfile
    } 
    $AgentMailProfileList += $AgentMailProfileInfo
   
}

$AgentMailProfileList | select ServerName, MailProfile | Export-Csv -Path $csvfile -NoTypeInformation 





