﻿$path = "E:\Adhoc_Backup\Virtualization\NPEIRDBP8"
#$output = "E:\Adhoc_backup\Reports\Nveirdbpc6rdmbackupsize.txt"
#Out-File $output
$files = Get-childitem $path
foreach($file in $files){
    $dbpath = $path+"\"+$file.name
    $backupfiles = Get-ChildItem $dbpath
    $backupsize = 0
    foreach($backupfile in $backupfiles){
    $backupsize += $backupfile.Length
    }
    echo "$($file.Name.PadRight(50)) $($([Math]::round($backupsize/1024/1024,2)).ToString().PadRight(15))" ## | Out-file -Append $output
}