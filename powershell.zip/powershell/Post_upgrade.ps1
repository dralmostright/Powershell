﻿Param(
  [string]$central_server,
  [string]$Path,
  [string]$username,
  [string]$Password
)


$Path=$Path+'\'

$date=get-date -Format u
$date= ($date.replace('-','')).substring(0,8)
$logfile=$Path+'PostTimelog_'+$date+'.txt'

$start_time = get-date
$start=get-date -Format G


echo "================================================================================================" | Out-file -Encoding default -Append $logfile

echo "STARTED   : $start => POST UPGRADE TASK " | Out-file -Append -Encoding default $logfile

$database="master"
$connectionString="Server=$central_server;uid=$usernamename;pwd=$pwd;Database=$database;Integrated Security=True;"
$connection=New-Object System.Data.SqlClient.SqlConnection
$connection.ConnectionString=$connectionString
$connection.Open()
$command=New-Object System.Data.SqlClient.SqlCommand
$command.Connection=$connection
$command.CommandTimeout = 0 
$ERR=''

$string="
SET NOCOUNT ON

EXEC sp_configure 'show advanced options', 1;  
RECONFIGURE;  
EXEC sp_configure 'xp_cmdshell', 1;  
RECONFIGURE;  

DECLARE @LOCATION VARCHAR(100), @StartTime DATETIME,@EndTime datetime  ,@start varchar(30),@end varchar(30),@SQL VARCHAR(1000)
SET @LOCATION = '"+$Path+"'


SET @SQL='echo ------------------------------------------------------>>"+$logfile+"'
EXEC ('EXEC XP_CMDSHELL '''+@SQL+'''');


SET @StartTime = GETDATE()
SET @START= CONVERT(VARCHAR(10), getdate(), 101) + ' '+ LTRIM(RIGHT(CONVERT(CHAR(20), getdate(), 22), 11))
SET @SQL='echo STARTED   : '+@START+'=^>  SELECTING SERVER '+@@SERVERNAME+'>>"+$logfile+"'
EXEC ('EXEC XP_CMDSHELL '''+@SQL+'''');

SELECT '===================// '+@@SERVERNAME+' //==================='
SELECT 'Version: ['+@@VERSION+']'

SELECT @EndTime=GETDATE()  
SET @END=CONVERT(VARCHAR(10), getdate(), 101) + ' '+ LTRIM(RIGHT(CONVERT(CHAR(20), getdate(), 22), 11)) 
SET @SQL='echo COMPLETED : '+@START+' ^| '+@end+' ^| '+CONVERT(VARCHAR,DATEDIFF(s,@StartTime,@EndTime))+' sec =^> SERVER SELECTED '+@@SERVERNAME+'>>"+$logfile+"'
EXEC ('EXEC XP_CMDSHELL '''+@SQL+'''');


SET @SQL='echo ------------------------------------------------------>>"+$logfile+"'
EXEC ('EXEC XP_CMDSHELL '''+@SQL+'''');



SET @StartTime = GETDATE()
SET @START= CONVERT(VARCHAR(10), getdate(), 101) + ' '+ LTRIM(RIGHT(CONVERT(CHAR(20), getdate(), 22), 11))
SET @SQL='echo STARTED   : '+@START+'=^>  CHECKING COMPATILABILITY LEVEL FOR '+@@SERVERNAME+'>>"+$logfile+" '
EXEC ('EXEC XP_CMDSHELL '''+@SQL+'''');

IF EXISTS (SELECT COMPATIBILITY_LEVEL FROM SYS.DATABASES WHERE COMPATIBILITY_LEVEL<>120)
BEGIN
EXEC master.sys.sp_MSforeachdb  'BEGIN TRY
DECLARE @SQL VARCHAR(200)
SET @SQL=''ALTER DATABASE ''+ quotename(''?'') +''SET COMPATIBILITY_LEVEL = 120''
EXEC (@SQL)
END TRY
BEGIN CATCH
PRINT ''''
END CATCH'
END

SELECT 'Database Compatibility Level'
SELECT '- -------------------------------------------------------------------------------------------------------------------------------- - ------------------- -'
SELECT '|' as '|',NAME,'|' as '|',compatibility_level,'|' as '|' FROM  SYS.DATABASES
SELECT '- -------------------------------------------------------------------------------------------------------------------------------- - ------------------- -'

SELECT @EndTime=GETDATE()  
SET @END=CONVERT(VARCHAR(10), getdate(), 101) + ' '+ LTRIM(RIGHT(CONVERT(CHAR(20), getdate(), 22), 11)) 
SET @SQL='echo COMPLETED : '+@START+' ^| '+@end+' ^| '+CONVERT(VARCHAR,DATEDIFF(s,@StartTime,@EndTime))+' sec =^> COMPATILABILITY LEVEL CHECKED FOR '+@@SERVERNAME+'>>"+$logfile+"'
EXEC ('EXEC XP_CMDSHELL '''+@SQL+'''');

SET @SQL='echo ------------------------------------------------------>>"+$logfile+"'
EXEC ('EXEC XP_CMDSHELL '''+@SQL+'''');

SET @StartTime = GETDATE()
SET @START= CONVERT(VARCHAR(10), getdate(), 101) + ' '+ LTRIM(RIGHT(CONVERT(CHAR(20), getdate(), 22), 11))
SET @SQL='echo STARTED   : '+@START+'=^>  DBCC CHECKDB '+@@SERVERNAME+'>>"+$logfile+"'
EXEC ('EXEC XP_CMDSHELL '''+@SQL+'''');

SELECT ' DBCC CHECKDB '
BEGIN TRY
EXEC master.sys.sp_MSforeachdb 'use ?;
DECLARE @LOCATION VARCHAR(100), @StartTime DATETIME,@EndTime datetime  ,@start varchar(30),@end varchar(30),@sql varchar(500)
SET @StartTime = GETDATE()
SET @START= CONVERT(VARCHAR(10), getdate(), 101) + '' ''+ LTRIM(RIGHT(CONVERT(CHAR(20), getdate(), 22), 11))
SET @SQL=''echo STARTED   : ''+@START+''=^>  DBCC CHECKDB FOR ? >>"+$logfile+"''
EXEC (''EXEC XP_CMDSHELL ''''''+@SQL+'''''''');
SELECT ''----------------------------------'';SELECT ''?'';SELECT ''----------------------------------''; DBCC CHECKDB WITH DATA_PURITY
SELECT @EndTime=GETDATE()  
SET @END=CONVERT(VARCHAR(10), getdate(), 101) + '' ''+ LTRIM(RIGHT(CONVERT(CHAR(20), getdate(), 22), 11)) 
SET @SQL=''echo COMPLETED : ''+@START+'' ^| ''+@end+'' ^| ''+CONVERT(VARCHAR,DATEDIFF(s,@StartTime,@EndTime))+'' sec =^> DBCC CHECKDB FOR ? >>"+$logfile+"''
EXEC (''EXEC XP_CMDSHELL ''''''+@SQL+'''''''');';
END TRY
BEGIN CATCH
SELECT ERROR_MESSAGE()
END CATCH

SELECT @EndTime=GETDATE()  
SET @END=CONVERT(VARCHAR(10), getdate(), 101) + ' '+ LTRIM(RIGHT(CONVERT(CHAR(20), getdate(), 22), 11)) 
SET @SQL='echo COMPLETED : '+@START+' ^| '+@end+' ^| '+CONVERT(VARCHAR,DATEDIFF(s,@StartTime,@EndTime))+' sec =^> DBCC CHECKDB '+@@SERVERNAME+'>>"+$logfile+"'
EXEC ('EXEC XP_CMDSHELL '''+@SQL+'''');

SET @SQL='echo ------------------------------------------------------>>"+$logfile+"'
EXEC ('EXEC XP_CMDSHELL '''+@SQL+'''');

SET @StartTime = GETDATE()
SET @START= CONVERT(VARCHAR(10), getdate(), 101) + ' '+ LTRIM(RIGHT(CONVERT(CHAR(20), getdate(), 22), 11))
SET @SQL='echo STARTED   : '+@START+'=^>  UPDATE STATISTICS '+@@SERVERNAME+'>>"+$logfile+"'
EXEC ('EXEC XP_CMDSHELL '''+@SQL+'''');

SELECT ' UPDATE STATISTICS OF TABLES ' 
BEGIN TRY
EXEC master.sys.sp_MSforeachdb 'use ?;SELECT ''----------------------------------'';SELECT ''?'';SELECT ''----------------------------------'';  EXEC sp_updatestats;'
END TRY
BEGIN CATCH
SELECT ERROR_MESSAGE()
END CATCH

SELECT @EndTime=GETDATE()  
SET @END=CONVERT(VARCHAR(10), getdate(), 101) + ' '+ LTRIM(RIGHT(CONVERT(CHAR(20), getdate(), 22), 11)) 
SET @SQL='echo COMPLETED : '+@START+' ^| '+@end+' ^| '+CONVERT(VARCHAR,DATEDIFF(s,@StartTime,@EndTime))+' sec =^> UPDATE STATISTICS '+@@SERVERNAME+'>>"+$logfile+"'
EXEC ('EXEC XP_CMDSHELL '''+@SQL+'''');


SET @SQL='echo ------------------------------------------------------>>"+$logfile+"'
EXEC ('EXEC XP_CMDSHELL '''+@SQL+'''');

SELECT 'REFRESH ALL VIEWS'

SET @StartTime = GETDATE()
SET @START= CONVERT(VARCHAR(10), getdate(), 101) + ' '+ LTRIM(RIGHT(CONVERT(CHAR(20), getdate(), 22), 11))
SET @SQL='echo STARTED   : '+@START+'=^>  REFRESH VIEWS '+@@SERVERNAME+'>>"+$logfile+"'
EXEC ('EXEC XP_CMDSHELL '''+@SQL+'''');

EXEC sp_MSforeachdb 'PRINT ''------------------------- In ? ------------------------- ''
DECLARE C CURSOR FOR
SELECT NAME FROM SYSOBJECTS WHERE TYPE = ''V'' AND UID = 1
OPEN C
DECLARE @VIEWNAME VARCHAR(500)
FETCH NEXT FROM C INTO @VIEWNAME
WHILE @@FETCH_STATUS = 0
BEGIN
BEGIN TRY
EXEC SP_REFRESHVIEW @VIEWNAME
PRINT @VIEWNAME
END TRY
BEGIN CATCH
PRINT @VIEWNAME
END CATCH
FETCH NEXT FROM C INTO @VIEWNAME
END
CLOSE C
DEALLOCATE C'

SELECT @EndTime=GETDATE()  
SET @END=CONVERT(VARCHAR(10), getdate(), 101) + ' '+ LTRIM(RIGHT(CONVERT(CHAR(20), getdate(), 22), 11)) 
SET @SQL='echo COMPLETED : '+@START+' ^| '+@end+' ^| '+CONVERT(VARCHAR,DATEDIFF(s,@StartTime,@EndTime))+' sec =^> REFRESH VIEW '+@@SERVERNAME+'>>"+$logfile+"'
EXEC ('EXEC XP_CMDSHELL '''+@SQL+'''');

SET @SQL='echo ------------------------------------------------------>>"+$logfile+"'
EXEC ('EXEC XP_CMDSHELL '''+@SQL+'''');

"


$new_path=$Path+'postquery.sql'
echo $string |  Out-file  $new_path

$string='DECLARE @SQL VARCHAR(800),@SERVER VARCHAR(100),@LOCATION VARCHAR(100)
SET @LOCATION = '''+$path+'''
DECLARE C CURSOR FOR 
SELECT SERVER FROM Report.dbo.SERVERS
OPEN C
FETCH NEXT FROM C INTO @SERVER
WHILE @@FETCH_STATUS=0
BEGIN

SET @SQL=''''''SQLCMD -i "''+@LOCATION+''postquery.sql" -S ''+@SERVER+'' -U '+$username+' -P '+$Password+' -o "''+@LOCATION+UPPER(@SERVER)+''_Post.txt"''''''     
EXEC (''EXEC XP_CMDSHELL ''+@SQL+'''');

FETCH NEXT FROM C INTO @SERVER
END
CLOSE C
DEALLOCATE C'
#echo $string

$command.CommandText=$string 
$result=$command.ExecuteReader()
$result.close()

$end_time = Get-Date
$end = get-date -Format G
echo "COMPLETED : $end => POST UPGRADE TASK " | Out-file -Append -Encoding default $logfile



if ($ERR -ne ''){

echo "Error Summary:" | Out-file -Append -Encoding default $logfile
echo "$ERR" | Out-file -Append -Encoding default $logfile
}

echo "================================================================================================" | Out-file -Encoding default -Append $logfile
