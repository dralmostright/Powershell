﻿Param(
  [string]$server,
  [string]$ReportServerUri,
  [string]$Path  
)

$logfile = $path+"\Pre_SSRS.txt"
$start_time = get-date
$start = get-date -format G
echo "STARTED   : $start ==> Backup SSRS on $server" | Out-File $logfile
[void][System.Reflection.Assembly]::LoadWithPartialName("System.Xml.XmlDocument");
[void][System.Reflection.Assembly]::LoadWithPartialName("System.IO"); 
$ReportServerUri = $ReportServerUri+"/ReportService2005.asmx";	
$Proxy = New-WebServiceProxy -Uri $ReportServerUri -Namespace SSRS.ReportingService2005 -UseDefaultCredential ;
$items = $Proxy.ListChildren("/", $true) | `
         select Type, Path, ID, Name | `
         Where-Object {$_.type -eq "Report"};
$computername=$env:computername
$date=get-date -Format u
$date= ($date).substring(0,10)
$fullFolderName=$Path+'\'+$date+'\REPORTS\'+$computername
[System.IO.Directory]::CreateDirectory($fullFolderName) | out-null 
$log=0

foreach($item in $items)
{
$log=$log+1
    $subfolderName = split-path $item.Path;
    $reportName = split-path $item.Path -Leaf;
    $fullSubfolderName = $fullFolderName + $subfolderName;
    if(-not(Test-Path $fullSubfolderName))
    {
        [System.IO.Directory]::CreateDirectory($fullSubfolderName) | out-null
    } 
    $rdlFile = New-Object System.Xml.XmlDocument;
    [byte[]] $reportDefinition = $null;
    $reportDefinition = $Proxy.GetReportDefinition($item.Path);
    [System.IO.MemoryStream] $memStream = New-Object System.IO.MemoryStream(@(,$reportDefinition));
    $rdlFile.Load($memStream); 
    $fullReportFileName = $fullSubfolderName + "\" + $item.Name +  ".rdl";
    $rdlFile.Save( $fullReportFileName); 
} 

if( $log -ieq 0){

[Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")
$conn="Server=$server;Integrated Security=True;"
$sqlServer = New-Object("Microsoft.SqlServer.Management.Smo.Server") $server
$connect=New-Object System.Data.SqlClient.SqlConnection
$connect.ConnectionString=$conn
$connect.Open()
$command=New-Object System.Data.SqlClient.SqlCommand
$command.Connection=$connect
$command.CommandTimeout = 0 

$string="select name from master.sys.databases where name like 'ReportServer%' and name not like 'ReportServer%TempDB'"
$command.CommandText=$string 
$result=$command.ExecuteReader()
$table= New-Object System.Data.DataTable
$table.load($result)

foreach($db in $table.name)
{
$string="
SET NOCOUNT ON

EXEC sp_configure 'show advanced options', 1;  
RECONFIGURE;  
EXEC sp_configure 'xp_cmdshell', 1;  
RECONFIGURE;  
DECLARE @FilterReportPath AS VARCHAR(500) = NULL 
DECLARE @FilterReportName AS VARCHAR(500) = NULL 
DECLARE @OutputPath AS VARCHAR(500) ='"+$fullFolderName +"'+'\' 
         
DECLARE @TSQL AS NVARCHAR(max) 

SET @OutputPath = Replace(@OutputPath, '\', '/') 

IF Ltrim(Rtrim(Isnull(@OutputPath, ''))) = '' 
  BEGIN 
      SELECT 'Invalid Output Path' 
  END 
ELSE 
  BEGIN 
      SET @TSQL = Stuff((SELECT ';EXEC master..xp_cmdshell ''bcp `" ' 
                                + ' SELECT ' + ' CONVERT(VARCHAR(MAX), ' 
                                + '       CASE ' 
                                + 
'         WHEN LEFT(C.Content,3) = 0xEFBBBF THEN STUFF(C.Content,1,3,'''''''') ' 
+ '         ELSE C.Content ' + '       END) ' 
+ ' FROM ' 
+ ' ["+$db+"].[dbo].[Catalog] CL ' 
+ ' CROSS APPLY (SELECT CONVERT(VARBINARY(MAX),CL.Content) Content) C ' 
+ ' WHERE ' + ' CL.ItemID = ''''' 
+ CONVERT(VARCHAR(max), CL.itemid) 
+ ''''' `" queryout `"' + @OutputPath + '' + CL.NAME 
+ '.rdl`" ' + '-T -c -x''' 
 FROM   ["+$db+"].[dbo].[catalog] CL 
 WHERE  CL.[type] = 2 
        AND '/' + CL.[path] + '/' LIKE COALESCE( 
            '%/%' + @FilterReportPath + '%/%', '/' + 
                                       CL.[path] + '/') 
        AND CL.NAME LIKE COALESCE('%' + @FilterReportName + '%', CL.NAME) 
 FOR xml path('')), 1, 1, '') 

    EXEC Sp_executesql 
      @TSQL 
END "

$command.CommandText=$string 
$result=$command.ExecuteReader()

break

}
$connect.close()

$end_time = Get-Date
$end = Get-Date -format G
$tspan = New-TimeSpan -start $start_time -end $end_time
$seconds = ([TimeSpan]::Parse($tspan)).TotalSeconds
echo "COMPLETED : $start | $end | $seconds ==> Backup SSRS on $server" | Out-File $logfile


}
