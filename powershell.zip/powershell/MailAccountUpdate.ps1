﻿[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null

$serverlist = @(
"NVEIDBBACKUPP1"
)

foreach($servername in $serverlist){
    echo "Updateing mail account for $servername"
    $sqlserver = new-object "Microsoft.SqlServer.Management.Smo.Server" $servername

    #$sqlserver.Mail.Accounts
    #$sqlserver.Mail.Accounts.MailServers
    foreach($mailAcc in $sqlserver.Mail.Accounts){
        $vemail = $mailAcc.EmailAddress
        $vdisplay = $mailAcc.DisplayName
        $vreply = $mailAcc.ReplyToAddress
        $cemail = $vemail.replace('verscend', 'cotiviti')
        $cdisplay = $vdisplay.replace('verscend', 'cotiviti')
        $creply = $vreply.replace('verscend', 'cotiviti')
        echo "$($mailAcc.Name) :: Updating email from $vemail to $cemail"
        $mailAcc.EmailAddress = $cemail
        $mailAcc.DisplayName = $cdisplay
        $mailAcc.ReplyToAddress = $creply
        $mailAcc.Alter()
    } 

}

