﻿cd cd C:\MSSQL\scripts\Patch### Parameters to be set ####
#$LOGNAME='NVEIHOSTRDBP2'
$servername='nveiprocrdb01.prod.ops.global.ad'
$clientname = 'MMA'
$phase='before'
$DropDatabases=@( 


'MMA_DEVRAW',	
'MMA_DEVSTG',	
'MMA_EAST',	
'MMA_Eligs',	
'MMA_HISTORY'	



)

$logfile = "C:\temp\$($servername)_$($clientname)_$($phase).txt"
Function WriteTable{
    param($disObject)

    $disObject | Format-Table -AutoSize | out-file -Append $logfile
}
Function WriteLog{
    param($logtext)
    $logtext | Out-File -Append $logfile
}

[System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.Smo') | Out-Null
### Reset Log file
Out-File $logfile
#$servername=$env:COMPUTERNAME
$sqlserver=New-object('Microsoft.SqlServer.Management.Smo.Server') $servername

########## Server Details ###########
WriteLog ">>>> Server Details"
[array]$ServerDetails = New-Object PSObject -Property @{
    "NAME" = $sqlserver.Name;
    "INSTANCE" = $sqlserver.ServiceInstanceId;
    "SERVERTYPE" = $sqlserver.ServerType;
    "VERSION" = $sqlserver.Version; 
}
WriteTable $($ServerDetails | select NAME, INSTANCE, SERVERTYPE, VERSION)

########## Database Details ##########
WriteLog ">>>> Database Details"

$DatabaseDetails=@()
foreach($db in $sqlserver.Databases){
    if($DropDatabases -icontains $db.Name){
        [array]$Dbdetail = New-Object PSObject -Property @{
            "NAME" = $db.Name;
            "DATABASE_STATUS" = $db.status;
            "CREATE_DATE" = $db.CreateDate;
            "OWNER" = $db.Owner;
            "SIZE_MB" = $db.Size;
            "COMPATIBILITY_LEVEL" = $db.CompatibilityLevel   
        }
        $DatabaseDetails += $Dbdetail
    }
}

[array]$Dbdetail = New-Object PSObject -Property @{
    "NAME" = "";
    "DATABASE_STATUS" = "";
    "CREATE_DATE" = "";
    "OWNER" = "";
    "SIZE_MB" = "";
    "COMPATIBILITY_LEVEL" = ""
}
$DatabaseDetails += $Dbdetail
WriteTable $($DatabaseDetails | Select NAME, DATABASE_STATUS, CREATE_DATE, OWNER, SIZE_MB, COMPATIBILITY_LEVEL)

########## Object Details ###########
WriteLog ">>>> Object Details"
$dbcounter=0
foreach($db in $sqlserver.Databases){
    if($DropDatabases -icontains $db.name){
        $dbcounter = $dbcounter + 1
        $ObjectDetails = @()
        try{
            ### Table Details
            foreach($tbl in $db.tables){
                [array]$tblDetail = New-Object PSObject -Property @{
                    "DATABASE" = $db.Name;
                    "SCHEMA" = $tbl.Schema;
                    "OBJECT" = $tbl.name;
                    "TYPE" = "Table";
                    "PAGES" = $tbl.DataSpaceUsed + $tbl.IndexSpaceUsed
                    "KBYTES" = $($tbl.DataSpaceUsed + $tbl.IndexSpaceUsed)*8
                }
                $ObjectDetails += $tblDetail
            }
            ### View Details
            foreach($vw in $db.Views){
                if(@("sys", "INFORMATION_SCHEMA") -inotcontains $vw.Schema){
                    [array]$vwDetail = New-Object PSObject -Property @{
                        "DATABASE" = $db.Name;
                        "SCHEMA" = $vw.Schema;
                        "OBJECT" = $vw.name;
                        "TYPE" = "View";
                        "PAGES" = "*";
                        "KBYTES" = "*";
                    }
                    $ObjectDetails += $vwDetail
                }
            }
        }catch{
            WriteLog "Error : $($_.Exception.Message)"
        }
        
        WriteTable $($ObjectDetails | Select DATABASE, SCHEMA, OBJECT, TYPE, PAGES, KBYTES )
    }
        
} 
if($dbcounter -eq 0){
    $ObjectDetails = @()
    [array]$vwDetail = New-Object PSObject -Property @{
        "DATABASE" = "";
        "SCHEMA" = "";
        "OBJECT" = "";
        "TYPE" = "";
        "PAGES" = "";
        "KBYTES" = "";
    }
    $ObjectDetails += $vwDetail
    WriteTable $($ObjectDetails | Select DATABASE, SCHEMA, OBJECT, TYPE, PAGES, KBYTES )
}


