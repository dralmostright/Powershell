﻿ $serverlist = @(
'NVEI2HOSTRDBU01',
'NVEI1RDBU1',
'NVEI1RDBU3')

$data=Invoke-WebRequest "http://10.128.158.240:80/ords/edb_dashboard/mssql/list" | convertFrom-Json | Select  -expand items

foreach ($servername in $serverlist) {
    foreach ($i in $data){
        $params=Invoke-Sqlcmd -ServerInstance $servername -query $i.sqlquery | Select-Object * -ExcludeProperty ItemArray, Table, RowError, RowState, HasErrors | ConvertTo-Json
        Invoke-WebRequest -Uri $i.url -ContentType application/json -Method POST -Body $params
    }
}

