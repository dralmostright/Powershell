﻿param($central_servername, [string] $path, [string]$username, [string]$password, $serverid_list, [string] $type, [string]$uid, [string] $date)

function GenerateRecordIDnum{
    $query = "select max(convert(int,replace(recordid,'"+$recordid_pat+"',''))) as idnum from rdbmsrecord where recordid like '"+$recordid_pat1+"[_]"+"%'"
    $command.CommandText = $query
    $result = $command.ExecuteReader()
    $table = New-Object System.Data.DataTable
    $table.load($result)
    $result.close()
    if([System.DBNull]::Value.Equals($table.idnum[0])) {$num = 0} else{$num = $table.idnum[0]}
    return $num
} 

function GetServerList{
    param($serverid_list)
    $sqlquery = "Select * from Servers"
    $command.commandtext = $sqlquery
    $result = $command.ExecuteReader()
    $table = new-object System.Data.DataTable
    $table.Load($result)
    $result.close()
    $serverlist = @()
    $serverarray = @{}
    foreach($row in $table){
        $serverarray.add($row[0], $row[1])
    }
    if($serverid_list -eq 'all'){
        $serverlist = $serverarray.values
    }
    else{
        foreach($id in $serverid_list){
            if($id -le 12){
                continue;
            }
            if($serverarray.containskey($id)){
                $serverlist += $serverarray.get_item($id)
            }else{
                echo "The serverID $id doesnot exists."
                exit
            }
        }
    }
    return $serverlist
}

Function PreAnalysisRecord{
    param ( $servername_list, $username, $recordid)
    $errorlist = @()
    $start_time = get-date
    $start = get-date -format G
    echo "STARTED   : $start | PRE-RECORD"  | Tee-Object -FilePath $consoleoutput -append | Tee-Object -FilePath $errorlog -append
    $ExcludeDatabases = @('master', 'model', 'msdb', 'tempdb')
    $now = get-date
    $query=";"
    foreach($servername in $servername_list){
        $loadinfo = [Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")
        $servererrorlist = @()
        $start_time = get-date
        $start = get-date -format G
        echo "STARTED   : $start | PRE-RECORD on $servername"  | Tee-Object -FilePath $consoleoutput -append | Tee-Object -FilePath $errorlog -append
        try{
            try{
                $sqlserver = New-Object("Microsoft.SqlServer.Management.Smo.Server") $servername
                $sqlserver.databases | out-null
            }
            catch{
                $sqlserver = New-Object("Microsoft.SqlServer.Management.Smo.Server") $servername
                $sqlserver.ConnectionContext.LoginSecure=$false; 
                #This sets the login name 
                $sqlserver.ConnectionContext.set_Login($username); 
                #This sets the password 
                $sqlserver.ConnectionContext.set_Password($password)
            }
            
            
            
            foreach($d in $sqlserver.Databases){
                $db = $d.name
                if($ExcludeDatabases -contains $db) { continue; }
                $db_id = $d.ID
                try{
                    $cnxn = new-object System.Data.SqlClient.SqlConnection
                    $cnxn.ConnectionString = "Server=$servername; uid = $username; pwd =$password; Database=$db; Integrated Security=True;"
                    $cnxn.open()
                    echo "STARTED   : PRE_RECORD on database $db" | Tee-Object -FilePath $consoleoutput -append
                    $cmd = new-object System.Data.Sqlclient.Sqlcommand
                    $cmd.connection = $cnxn
                    $selectquery = "select p.*, schema_name(schema_id) as SchemaName from sys.objects as p where type not like 'S%' and type <> 'IT'"
                    $cmd.CommandText = $selectquery
                    $res = $cmd.ExecuteReader()
                    $obj_table = new-object System.Data.DataTable
                    $obj_table.Load($res)
                    $res.close()
                    foreach($row in $obj_table){
                        if($cnxn.state -ne "open")
                        { throw "server down"}
                        $query = "insert into RdbmsRecord values('"+$uid+"', '"+$recordid+"', '"+$servername+"', '"+$db+"', '"+$row.SchemaName +"', '"+
                                 $row.name+"', '"+$row.type_desc+"', '"+$row.create_date+"', '"+$row.modify_date +"', 1, 0, '"+$now+"', NULL);"
                        #echo $query
                        $command.CommandText=$query 
                        $result=$command.ExecuteReader()
                        $result.close()  
                         
                    }                  
                  
                    
                    $cnxn.close() 
                }
                catch{
                    $errortime = get-date
                    $err = "* Pre-Record: Couldnot connect to database $db in server $servername | Status:"+$d.Status
                    #echo $err  | Tee-Object -FilePath $consoleoutput -append
                    $servererrorlist += $err
                }    
            } 
            
             ####### SYS.CONFIGS
                    $query="INSERT INTO REPORT.DBO.SYSCONFIG (UNIQUEID, RECORDID, SERVERNAME, RECORDDATE, PRE_OR_POST, configuration_id,name,value,minimum,maximum,value_in_use,description,is_dynamic,is_advanced) "+
                                    " SELECT '"+ $uid+"', '"+$recordid+"', '" +$servername+"', GETDATE(),'PRE', configuration_id,name,value,minimum,maximum,value_in_use,description,is_dynamic,is_advanced FROM SYS.CONFIGURATIONS ORDER BY NAME"
                     
                     $command.CommandText=$query 
                     $result=$command.ExecuteReader()
                     $result.close()  
                     
                     ####### SERVERPROPERTIES
                     $query="INSERT INTO REPORT.DBO.SERVER_PROPERTIES (UNIQUEID, RECORDID, SERVERNAME, RECORDDATE, PRE_OR_POST,BuildClrVersion,Collation,CollationID,ComparisonStyle,ComputerNamePhysicalNetBIOS,Edition,EditionID, "+
                                                "EngineEdition,FilestreamConfiguredLevel,FilestreamEffectiveLevel,FilestreamShareName,HadrManagerStatus,InstanceDefaultDataPath,InstanceDefaultLogPath,InstanceName, "+
                                                "IsAdvancedAnalyticsInstalled,IsClustered,IsFullTextInstalled,IsHadrEnabled,IsIntegratedSecurityOnly,IsLocalDB,IsPolybaseInstalled,IsSingleUser,IsXTPSupported,LCID,LicenseType, "+
                                                "MachineName,NumLicenses,ProcessID,ProductBuild,ProductBuildType,ProductLevel,ProductMajorVersion,ProductMinorVersion,ProductUpdateLevel,ProductUpdateReference,ProductVersion, "+
                                                "ResourceLastUpdateDateTime,ResourceVersion,ServerName1,SqlCharSet,SqlCharSetName,SqlSortOrder,SqlSortOrderName) "+
                                                "SELECT '"+ $uid+"', '"+$recordid+"', '" +$servername+"', GETDATE(),'PRE',  SERVERPROPERTY('BuildClrVersion') ASBuildClrVersion, "+
                                                "SERVERPROPERTY('Collation') ASCollation, "+
                                                "SERVERPROPERTY('CollationID') ASCollationID, "+
                                                "SERVERPROPERTY('ComparisonStyle') ASComparisonStyle, "+
                                                "SERVERPROPERTY('ComputerNamePhysicalNetBIOS') ASComputerNamePhysicalNetBIOS, "+
                                                "SERVERPROPERTY('Edition') ASEdition, "+
                                                "SERVERPROPERTY('EditionID') ASEditionID, "+
                                                "SERVERPROPERTY('EngineEdition') ASEngineEdition, "+
                                                "SERVERPROPERTY('FilestreamConfiguredLevel') ASFilestreamConfiguredLevel, "+
                                                "SERVERPROPERTY('FilestreamEffectiveLevel') ASFilestreamEffectiveLevel, "+
                                                "SERVERPROPERTY('FilestreamShareName') ASFilestreamShareName, "+
                                                "SERVERPROPERTY('HadrManagerStatus') ASHadrManagerStatus, "+
                                                "SERVERPROPERTY('InstanceDefaultDataPath') ASInstanceDefaultDataPath, "+
                                                "SERVERPROPERTY('InstanceDefaultLogPath') ASInstanceDefaultLogPath, "+
                                                "SERVERPROPERTY('InstanceName') ASInstanceName, "+
                                                "SERVERPROPERTY('IsAdvancedAnalyticsInstalled') ASIsAdvancedAnalyticsInstalled, "+
                                                "SERVERPROPERTY('IsClustered') ASIsClustered, "+
                                                "SERVERPROPERTY('IsFullTextInstalled') ASIsFullTextInstalled, "+
                                                "SERVERPROPERTY('IsHadrEnabled') ASIsHadrEnabled, "+
                                                "SERVERPROPERTY('IsIntegratedSecurityOnly') ASIsIntegratedSecurityOnly, "+
                                                "SERVERPROPERTY('IsLocalDB') ASIsLocalDB, "+
                                                "SERVERPROPERTY('IsPolybaseInstalled') ASIsPolybaseInstalled, "+
                                                "SERVERPROPERTY('IsSingleUser') ASIsSingleUser, "+
                                                "SERVERPROPERTY('IsXTPSupported') ASIsXTPSupported, "+
                                                "SERVERPROPERTY('LCID') ASLCID, "+
                                                "SERVERPROPERTY('LicenseType') ASLicenseType, "+
                                                "SERVERPROPERTY('MachineName') ASMachineName, "+
                                                "SERVERPROPERTY('NumLicenses') ASNumLicenses, "+
                                                "SERVERPROPERTY('ProcessID') ASProcessID, "+
                                                "SERVERPROPERTY('ProductBuild') ASProductBuild, "+
                                                "SERVERPROPERTY('ProductBuildType') ASProductBuildType, "+
                                                "SERVERPROPERTY('ProductLevel') ASProductLevel, "+
                                                "SERVERPROPERTY('ProductMajorVersion') ASProductMajorVersion, "+
                                                "SERVERPROPERTY('ProductMinorVersion') ASProductMinorVersion, "+
                                                "SERVERPROPERTY('ProductUpdateLevel') ASProductUpdateLevel, "+
                                                "SERVERPROPERTY('ProductUpdateReference') ASProductUpdateReference, "+
                                                "SERVERPROPERTY('ProductVersion') ASProductVersion, "+
                                                "SERVERPROPERTY('ResourceLastUpdateDateTime') ASResourceLastUpdateDateTime, "+
                                                "SERVERPROPERTY('ResourceVersion') ASResourceVersion, "+
                                                "SERVERPROPERTY('ServerName') ASServerName, "+
                                                "SERVERPROPERTY('SqlCharSet') ASSqlCharSet, "+
                                                "SERVERPROPERTY('SqlCharSetName') ASSqlCharSetName, "+
                                                "SERVERPROPERTY('SqlSortOrder') ASSqlSortOrder, "+
                                                "SERVERPROPERTY('SqlSortOrderName') ASSqlSortOrderName"

                     $command.CommandText=$query 
                     $result=$command.ExecuteReader()
                     $result.close()  
                                            
            
        }
        catch{
            $errortime = get-date
            $err = "* Pre-Record: Could not connect to server $ServerName"
            #echo $err  | Tee-Object -FilePath $consoleoutput -append
            $servererrorlist += $err 
        }
        $end_time = Get-Date
        $end = Get-Date -format G
        $tspan = New-TimeSpan -start $start_time -end $end_time
        $seconds = ([TimeSpan]::Parse($tspan)).TotalSeconds
        if($servererrorlist.Count -eq 0){
            echo "COMPLETED : $start | $end | $seconds sec | PRE-RECORD on $servername" | Tee-Object -FilePath $consoleoutput -append | Tee-Object -FilePath $errorlog -append
        }
        else{
            echo "ERROR     : $start | $end | $seconds sec | PRE-RECORD on $servername" | Tee-Object -FilePath $consoleoutput -append | Tee-Object -FilePath $errorlog -append
            $errorlist += $servererrorlist
        }   
    }
    echo "COMPLETED : $end | PRE-RECORD" | Tee-Object -FilePath $consoleoutput -append | Tee-Object -FilePath $errorlog -append
    
    if($errorlist -ne 0){
        echo "ERROR SUMMARY :" | Tee-Object -FilePath $consoleoutput -append | Tee-Object -FilePath $errorlog -append
        foreach($err in $errorlist){
            echo "`t $err" | Tee-Object -FilePath $consoleoutput -append | Tee-Object -FilePath $errorlog -append
        }
    }
}

Function PostAnalysisRecord{
    param ( $serverlist, $username, $recordid)
    echo -------------------------------------------------------------------------------------- | Out-File -append $errorlog
    echo -------------------------------------------------------------------------------------- | Out-File -append $errorlog
    $errorlist = @()
    $start_time = get-date
    $start = get-date -format G
    echo "STARTED   : $start | POST-RECORD"  | Tee-Object -FilePath $consoleoutput -append | Tee-Object -FilePath $errorlog -append
    $ExcludeDatabases = @('master', 'model', 'msdb', 'tempdb')
    $now = get-date
    $query = ";"
    foreach($servername in $serverlist){
        $servererrorlist = @()
        $loadinfo = [Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")
        $start_time = get-date
        $start = get-date -format G
        echo "STARTED   : $start | POST-RECORD on $servername"  | Tee-Object -FilePath $consoleoutput -append | Tee-Object -FilePath $errorlog -append
        try{
            try{
                $sqlserver = New-Object("Microsoft.SqlServer.Management.Smo.Server") $servername
                $sqlserver.databases | out-null
            }
            catch{
                $sqlserver = New-Object("Microsoft.SqlServer.Management.Smo.Server") $servername
                $sqlserver.ConnectionContext.LoginSecure=$false; 
                #This sets the login name 
                $sqlserver.ConnectionContext.set_Login($username); 
                #This sets the password 
                $sqlserver.ConnectionContext.set_Password($password)
            }
            foreach($d in $sqlserver.Databases){
                $db = $d.name
                if($ExcludeDatabases -contains $db) { continue; }
                $db_id = $d.ID
                try{
                    $cnxn = new-object System.Data.SqlClient.SqlConnection
                    $cnxn.ConnectionString = "Server=$servername; uid = $username; pwd = $password; Database=$db; Integrated Security=True;"
                    $cnxn.open()
                    echo "STARTED   : POST-RECORD on database $db" | Tee-Object -FilePath $consoleoutput -append
                    $cmd = new-object System.Data.Sqlclient.Sqlcommand
                    $cmd.connection = $cnxn
                    $selectquery = "select p.*, schema_name(schema_id) as SchemaName from sys.objects as p where type not like 'S%' and type <> 'IT'"
                    $cmd.CommandText = $selectquery
                    $res = $cmd.ExecuteReader()
                    $obj_table = new-object System.Data.DataTable
                    $obj_table.Load($res)
                    $res.close()
                    foreach ($row in $obj_table){   
                        if($cnxn.state -ne "open")
                        { throw "server down"}        
                        $query="update RdbmsRecord set postrecord = 1, postrecord_date = '"+$now+"' where Recordid='"+$recordid+"' and ServerName = '"+$servername+"' and DatabaseName = '"+
                        $db+"' and SchemaName = '"+$row.SchemaName+"' and object = '"+$row.name+"' and object_type = '"+$row.type_desc+"';
                        if (@@rowcount = 0)
                        insert into RdbmsRecord values('"+$uid+"', '"+$recordid+"', '"+$servername+"', '"+$db+"', '"+$row.SchemaName+"', '"+$row.name+"', '"+
                            $row.type_desc+"', '"+$row.create_date+"', '"+$row.modify_date+"', 0, 1, NULL, '"+$now+"');"
                        $command.CommandText = $query
                        $result = $command.executereader()
                        $result.close()    
                    } 
                    $cnxn.Close() 
                }
                catch
                {
                    $errortime = get-date
                    $err = "* POST-RECORD: Couldnot connect to database $db in server $servername | Status: "+$d.Status
                    #echo $err | Tee-Object -FilePath $consoleoutput -append
                    $servererrorlist += $err
                }
            };
            
             ####### SYS.CONFIGS
                     $query="INSERT INTO REPORT.DBO.SYSCONFIG (UNIQUEID,RECORDID, SERVERNAME, RECORDDATE, PRE_OR_POST, configuration_id,name,value,minimum,maximum,value_in_use,description,is_dynamic,is_advanced) "+
                                    " SELECT '"+ $uid+"', '"+$recordid+"', '" +$servername+"', GETDATE(),'POST', configuration_id,name,value,minimum,maximum,value_in_use,description,is_dynamic,is_advanced FROM SYS.CONFIGURATIONS ORDER BY NAME"
                    
                     $command.CommandText=$query 
                     $result=$command.ExecuteReader()
                     $result.close()  
                                     
                                ####### SERVERPROPERTIES
                     $query="INSERT INTO REPORT.DBO.SERVER_PROPERTIES (UNIQUEID, RECORDID, SERVERNAME, RECORDDATE, PRE_OR_POST,BuildClrVersion,Collation,CollationID,ComparisonStyle,ComputerNamePhysicalNetBIOS,Edition,EditionID, "+
                                                "EngineEdition,FilestreamConfiguredLevel,FilestreamEffectiveLevel,FilestreamShareName,HadrManagerStatus,InstanceDefaultDataPath,InstanceDefaultLogPath,InstanceName, "+
                                                "IsAdvancedAnalyticsInstalled,IsClustered,IsFullTextInstalled,IsHadrEnabled,IsIntegratedSecurityOnly,IsLocalDB,IsPolybaseInstalled,IsSingleUser,IsXTPSupported,LCID,LicenseType, "+
                                                "MachineName,NumLicenses,ProcessID,ProductBuild,ProductBuildType,ProductLevel,ProductMajorVersion,ProductMinorVersion,ProductUpdateLevel,ProductUpdateReference,ProductVersion, "+
                                                "ResourceLastUpdateDateTime,ResourceVersion,ServerName1,SqlCharSet,SqlCharSetName,SqlSortOrder,SqlSortOrderName) "+
                                                "SELECT '"+ $uid+"', '"+$recordid+"', '" +$servername+"', GETDATE(),'POST',  SERVERPROPERTY('BuildClrVersion') ASBuildClrVersion, "+
                                                "SERVERPROPERTY('Collation') ASCollation, "+
                                                "SERVERPROPERTY('CollationID') ASCollationID, "+
                                                "SERVERPROPERTY('ComparisonStyle') ASComparisonStyle, "+
                                                "SERVERPROPERTY('ComputerNamePhysicalNetBIOS') ASComputerNamePhysicalNetBIOS, "+
                                                "SERVERPROPERTY('Edition') ASEdition, "+
                                                "SERVERPROPERTY('EditionID') ASEditionID, "+
                                                "SERVERPROPERTY('EngineEdition') ASEngineEdition, "+
                                                "SERVERPROPERTY('FilestreamConfiguredLevel') ASFilestreamConfiguredLevel, "+
                                                "SERVERPROPERTY('FilestreamEffectiveLevel') ASFilestreamEffectiveLevel, "+
                                                "SERVERPROPERTY('FilestreamShareName') ASFilestreamShareName, "+
                                                "SERVERPROPERTY('HadrManagerStatus') ASHadrManagerStatus, "+
                                                "SERVERPROPERTY('InstanceDefaultDataPath') ASInstanceDefaultDataPath, "+
                                                "SERVERPROPERTY('InstanceDefaultLogPath') ASInstanceDefaultLogPath, "+
                                                "SERVERPROPERTY('InstanceName') ASInstanceName, "+
                                                "SERVERPROPERTY('IsAdvancedAnalyticsInstalled') ASIsAdvancedAnalyticsInstalled, "+
                                                "SERVERPROPERTY('IsClustered') ASIsClustered, "+
                                                "SERVERPROPERTY('IsFullTextInstalled') ASIsFullTextInstalled, "+
                                                "SERVERPROPERTY('IsHadrEnabled') ASIsHadrEnabled, "+
                                                "SERVERPROPERTY('IsIntegratedSecurityOnly') ASIsIntegratedSecurityOnly, "+
                                                "SERVERPROPERTY('IsLocalDB') ASIsLocalDB, "+
                                                "SERVERPROPERTY('IsPolybaseInstalled') ASIsPolybaseInstalled, "+
                                                "SERVERPROPERTY('IsSingleUser') ASIsSingleUser, "+
                                                "SERVERPROPERTY('IsXTPSupported') ASIsXTPSupported, "+
                                                "SERVERPROPERTY('LCID') ASLCID, "+
                                                "SERVERPROPERTY('LicenseType') ASLicenseType, "+
                                                "SERVERPROPERTY('MachineName') ASMachineName, "+
                                                "SERVERPROPERTY('NumLicenses') ASNumLicenses, "+
                                                "SERVERPROPERTY('ProcessID') ASProcessID, "+
                                                "SERVERPROPERTY('ProductBuild') ASProductBuild, "+
                                                "SERVERPROPERTY('ProductBuildType') ASProductBuildType, "+
                                                "SERVERPROPERTY('ProductLevel') ASProductLevel, "+
                                                "SERVERPROPERTY('ProductMajorVersion') ASProductMajorVersion, "+
                                                "SERVERPROPERTY('ProductMinorVersion') ASProductMinorVersion, "+
                                                "SERVERPROPERTY('ProductUpdateLevel') ASProductUpdateLevel, "+
                                                "SERVERPROPERTY('ProductUpdateReference') ASProductUpdateReference, "+
                                                "SERVERPROPERTY('ProductVersion') ASProductVersion, "+
                                                "SERVERPROPERTY('ResourceLastUpdateDateTime') ASResourceLastUpdateDateTime, "+
                                                "SERVERPROPERTY('ResourceVersion') ASResourceVersion, "+
                                                "SERVERPROPERTY('ServerName') ASServerName, "+
                                                "SERVERPROPERTY('SqlCharSet') ASSqlCharSet, "+
                                                "SERVERPROPERTY('SqlCharSetName') ASSqlCharSetName, "+
                                                "SERVERPROPERTY('SqlSortOrder') ASSqlSortOrder, "+
                                                "SERVERPROPERTY('SqlSortOrderName') ASSqlSortOrderName"
                                                
                                     $command.CommandText=$query 
                                     $result=$command.ExecuteReader()
                                     $result.close()  
                                                 
                     
        }
        catch{
             $errortime = get-date
             $err = "* POST-RECORD: Could not connect to server $ServerName"
             #echo $err | Tee-Object -FilePath $consoleoutput -append
             $servererrorlist += $err      
        }
        $end_time = Get-Date
        $end = Get-Date -format G
        $tspan = New-TimeSpan -start $start_time -end $end_time
        $seconds = ([TimeSpan]::Parse($tspan)).TotalSeconds
        if($servererrorlist.Count -eq 0){
            echo "COMPLETED : $start | $end | $seconds sec | POST-RECORD on $servername" | Tee-Object -FilePath $consoleoutput -append | Tee-Object -FilePath $errorlog -append
        }
        else{
            echo "ERROR     : $start | $end | $seconds sec | POST-RECORD on $servername" | Tee-Object -FilePath $consoleoutput -append | Tee-Object -FilePath $errorlog -append
            $errorlist += $servererrorlist
        }   
    }
    echo "COMPLETED : $end | POST-RECORD" | Tee-Object -FilePath $consoleoutput -append | Tee-Object -FilePath $errorlog -append
    
    if($errorlist -ne 0){
        echo "ERROR SUMMARY :" | Tee-Object -FilePath $consoleoutput -append | Tee-Object -FilePath $errorlog -append
        foreach($err in $errorlist){
            echo "`t $err" | Tee-Object -FilePath $consoleoutput -append | Tee-Object -FilePath $errorlog -append
        }
    }
}

Function GenerateReport
{
    param($serverlist, $username, $recordid)
    echo -------------------------------------------------------------------------------------- | Out-File -append $errorlog
    echo -------------------------------------------------------------------------------------- | Out-File -append $errorlog
    $errorlist = @()
    $start_time = get-date
    $start = get-date -format G
    echo "STARTED   : $start | REPORT GENERATION"  | Tee-Object -FilePath $consoleoutput -append | Tee-Object -FilePath $errorlog -append
    #write the basic html code
    try{
    $htmlformat = Get-Content .\Preformat.txt -Raw -ErrorAction Stop
    }catch{
    $err = "CSS file for html report missing"
    $errorlist += $err
    }  
$index = @(("Undefined", "New"), ("Missing", "OK"))
$color = @(("#FFOOOO", "#FFOOOO"), ("#FF0000", "#008000"))
$sqlquery = "select t1.mobject, t2.prerecord_date, t3.postrecord_date, t4.issues, T5.srvr_props_diff, T6.sysconfig_missing,T7.sysconfig_new from " +
            " (select count(prerecord) as mobject from RdbmsRecord where recordid = '"+$recordid+"') as t1," +
            " (select top 1 prerecord_date from RdbmsRecord where recordid = '"+$recordid+"' order by prerecord_date desc) as t2," +
            " (select top 1 postrecord_date from RdbmsRecord where recordid = '"+$recordid+"' order by postrecord_date desc) as t3," +
            " (select count(prerecord) as issues from RdbmsRecord where recordid = '"+$recordid+"' and (prerecord = 0 or postrecord = 0)) as t4, " +                        
            " (SELECT COUNT(1) SRVR_PROPS_DIFF FROM " +
                    " (" +
                    " SELECT BuildClrVersion,Collation,CollationID,ComparisonStyle,ComputerNamePhysicalNetBIOS,Edition,EditionID,EngineEdition,FilestreamConfiguredLevel," +
                    " FilestreamEffectiveLevel,FilestreamShareName,HadrManagerStatus,InstanceDefaultDataPath,InstanceDefaultLogPath,InstanceName,IsAdvancedAnalyticsInstalled," +
                    " IsClustered,IsFullTextInstalled,IsHadrEnabled,IsIntegratedSecurityOnly,IsLocalDB,IsPolybaseInstalled,IsSingleUser,IsXTPSupported,LCID,LicenseType," +
                    " MachineName,NumLicenses,ProcessID,ProductBuild,ProductBuildType,ProductLevel,ProductMajorVersion,ProductMinorVersion,ProductUpdateLevel,ProductUpdateReference," +
                    " ProductVersion,ResourceLastUpdateDateTime,ResourceVersion,ServerName,SqlCharSet,SqlCharSetName,SqlSortOrder,SqlSortOrderName FROM REPORT.DBO.SERVER_PROPERTIES " +
                    " WHERE recordid = '"+$recordid+"' AND PRE_OR_POST='PRE' " +
                    " EXCEPT" +
                    " SELECT BuildClrVersion,Collation,CollationID,ComparisonStyle,ComputerNamePhysicalNetBIOS,Edition,EditionID,EngineEdition,FilestreamConfiguredLevel" +
                    " ,FilestreamEffectiveLevel,FilestreamShareName,HadrManagerStatus,InstanceDefaultDataPath,InstanceDefaultLogPath,InstanceName,IsAdvancedAnalyticsInstalled," +
                    " IsClustered,IsFullTextInstalled,IsHadrEnabled,IsIntegratedSecurityOnly,IsLocalDB,IsPolybaseInstalled,IsSingleUser,IsXTPSupported,LCID,LicenseType," +
                    " MachineName,NumLicenses,ProcessID,ProductBuild,ProductBuildType,ProductLevel,ProductMajorVersion,ProductMinorVersion,ProductUpdateLevel,ProductUpdateReference," +
                    " ProductVersion,ResourceLastUpdateDateTime,ResourceVersion,ServerName,SqlCharSet,SqlCharSetName,SqlSortOrder,SqlSortOrderName FROM REPORT.DBO.SERVER_PROPERTIES " +
                    " WHERE recordid = '"+$recordid+"' AND PRE_OR_POST='POST' " +
                    " )A) T5," +
                    " (SELECT COUNT(1) SYSCONFIG_MISSING FROM" +
                    " (" +
                    " SELECT configuration_id, name, value_in_use FROM REPORT.DBO.SYSCONFIG WHERE recordid = '"+$recordid+"'  AND PRE_OR_POST='PRE' " +
                    " EXCEPT" +
                    " SELECT configuration_id, name, value_in_use FROM REPORT.DBO.SYSCONFIG WHERE recordid = '"+$recordid+"'  AND PRE_OR_POST='POST'" + 
                    " )B) T6," +
                    " (SELECT COUNT(1) SYSCONFIG_NEW FROM" +
                    " (" +
                    " SELECT configuration_id, name, value_in_use FROM REPORT.DBO.SYSCONFIG WHERE recordid = '"+$recordid+"'  AND PRE_OR_POST='POST'" + 
                    " EXCEPT" +
                    " SELECT configuration_id, name, value_in_use FROM REPORT.DBO.SYSCONFIG WHERE recordid = '"+$recordid+"'  AND PRE_OR_POST='PRE' " +
                    " )C) T7"              
$command.commandtext = $sqlquery
$result = $command.ExecuteReader()
$table = new-object System.Data.DataTable
$table.Load($result)
$sers = $serverlist
$msers = $sers | measure
$mobject = $($table.mobject)[0]
$predate = $($table.prerecord_date)[0]
$postdate = $($table.postrecord_date)[0]
$missue = $($table.issues)[0]

$SRVR_PROPS_DIFF= $($table.srvr_props_diff)[0]
$SYSCONFIG_MISSING= $($table.sysconfig_missing)[0]
$SYSCONFIG_NEW = $($table.sysconfig_new)[0] 

$htmlformat = $htmlformat + '<button class="button" id="floatingBtn" onclick="go_to_top()">Top</button><body><div class="title">Server Report</div>'
$htmlformat = $htmlformat +'<table class="servers"><tr><th colspan ="6">Servers</th></tr>'
$loopcount  = [math]::ceiling($serverlist.count/6)
for($i=0;$i -lt $loopcount;$i=$i+1)
{
if($serverlist.count -eq 1)
{
$htmlformat = $htmlformat + '<tr><td><a onclick="go_to('''+$serverlist.replace("\","").replace(" ","")+''')" style="cursor:pointer">'+$serverlist+'</a></td></tr>'
break
}
$htmlformat = $htmlformat + '<tr>'
for($j=0;$j -lt 6;$j = $j+1){
if($i*6+$j -ge $serverlist.count){
continue
}
$htmlformat = $htmlformat + '<td><a onclick="go_to('+"'"+$serverlist[$i*6+$j].replace("\","").replace(" ","")+"'"+')" style="cursor:pointer">'+$serverlist[$i*6+$j]+'</a></td>'
}
$htmlformat = $htmlformat + '</tr>'
}

$htmlformat = $htmlformat + '</table><table class="summary" align="center">' + 
                                                                '<tr><th colspan="2">Summary</th></tr>' +
                                '<tr><td>RecordID</td><td>'+$recordid+'</td></tr>' +
                                '<tr><td>Pre-record Date</td><td>'+$predate+'</td></tr>' +
                                '<tr><td>Post-record Date</td><td>'+$postdate+'</td></tr>' +
                                '<tr><td>No. of Servers</td><td>'+$msers.count+'</td></tr>' +
                                '<tr><td>No. of Objects</td><td>'+$mobject+'</td></tr>' +
                                '<tr><td>No. of Issues</td><td>'+$missue+'</td></tr>'+
                                '<tr><td>No. of mismatch in server properties</td><td>'+$SRVR_PROPS_DIFF+'</td></tr>'+
                                '<tr><td>No. of missing configuration parameters</td><td>'+$SYSCONFIG_MISSING+'</td></tr>'+
                                '<tr><td>No. of new configuration parameters</td><td>'+$SYSCONFIG_MISSING+'</td></tr>'+
                            '</table>'
$suberrorlist = @()
try{
$errorfromfile = get-content $errorlog -ErrorAction Stop
}catch{}
foreach($row in $errorfromfile)
{
$row = $row.trimstart()
$space = $row.indexof(" ")
if($space -ne -1){
$idstring = $row.substring(0,$space)
if($idstring -eq "*")
{
$suberror = $($row.substring($space)).Trimstart(" ")
if($suberrorlist -notcontains $suberror){
$suberrorlist += $suberror
}
}
}
}

if($suberrorlist.length -gt 0)
{
$htmlformat += '<table class="Error" align="center"><tr><th>Errors</th></tr>'
foreach($suberr in $suberrorlist)
{
$htmlformat += '<tr><td>'+$suberr+'</td></tr>'
}
$htmlformat += '</table>'
}
$htmlformat = $htmlformat+'<ul style="list-style-type:none">'
echo $htmlformat|Out-File $reportfile #file write


foreach($ser in $sers)
{
    $start_time = get-date
    $start = get-date -format G
    echo "STARTED   : $start | REPORT GENERATION on $ser"  | Tee-Object -FilePath $consoleoutput -append | Tee-Object -FilePath $errorlog -append
    $databases = @()
    $htmlformat = '<li class="server" id="'+$ser.replace("\","").replace(" ","")+'"> SERVER NAME = '+ $ser+ '</li>'
    echo $htmlformat|Out-File -Append $reportfile #file write
    $sqlquery = "select distinct DatabaseName from RdbmsRecord where recordid = '"+$recordid+"' and ServerName = '"+$ser+"'"              
    $command.commandtext = $sqlquery
    $result = $command.ExecuteReader()
    $databases_temp = new-object System.Data.DataTable
    $databases_temp.Load($result)
    $result.close()
    #converting db_name list into array $databases
    foreach($row in $databases_temp)
    {
    if($databases -notcontains $row.DatabaseName)
    {
    $databases += $row.DatabaseName
    }
    }
    foreach($db_name in $databases)
    {
        #table of non-issue rows in db_name
        $sqlquery = "select schemaName, object, object_type, prerecord, postrecord from RdbmsRecord where recordid = '"+$recordid+"' and ServerName = '"+$ser+"' and DatabaseName = '"+$db_name+"' and (prerecord = 1 and postrecord = 1) order by SchemaName, object_type "              
        $command.commandtext = $sqlquery
        $result = $command.ExecuteReader()
        $okays = new-object System.Data.DataTable
        $okays.Load($result)
        $result.close()
        $okaycount = $okays | measure
        $okayid = $ser.replace("\","").replace(" ","")+$db_name.replace("\","").replace(" ","")+'okay'

        #table of issue rows in db_name
        $sqlquery = "select schemaName, object, object_type, prerecord, postrecord from RdbmsRecord where recordid = '"+$recordid+"' and ServerName = '"+$ser+"' and DatabaseName = '"+$db_name+"' and (prerecord = 0 or postrecord = 0) order by SchemaName, object_type "              
        $command.commandtext = $sqlquery
        $result = $command.ExecuteReader()
        $issues = new-object System.Data.DataTable
        $issues.Load($result)
        $result.close()
        $issuecount = $issues | measure
        $issueid = $ser.replace("\","").replace(" ","")+$db_name.replace("\","").replace(" ","")+'issue'
        if($issuecount.Count -gt 0){ 
        $htmlformat = '<table class="dberror">' } else{
        $htmlformat = '<table class="cathead">'}
        $htmlformat = $htmlformat + '<th width="60%">DATABASE = '+ $db_name+'</th><th width="20%"> Issues: '+$issuecount.count+'(<a id="1'+$issueid+'" onclick="show_hide(this.id,'+"'"+$issueid+"'"+')" style="cursor:pointer">show</a>) '+
         '</th><th width="20%"> Okay: '+$okaycount.count+'(<a id="1'+$okayid+'" onclick="show_hide(this.id,'+"'"+$okayid+"'"+')" style="cursor:pointer">show</a>) '+'</th></table>
         <div id="'+$issueid+'" style="display:none"><table class= "table-class">
        <tr><th>SCHEMA_NAME</th><th>OBJECT TYPE</th><th>OBJECT</th><th>STATUS</th></tr>'
        echo $htmlformat|Out-File -Append $reportfile #file write
        foreach($issue in $issues)
        {
            $htmlformat ="<tr><td>"+$issue.SchemaName +"</td><td>" +$issue.object_type + "</td><td>" + $issue.object + "</td><td><font color='"+$color[$issue.prerecord][$issue.postrecord]+
            "'>" + $index[$issue.prerecord][$issue.postrecord] +"</font></td></tr>" 
            echo $htmlformat|Out-File -Append $reportfile #file write
        }
        $htmlformat = '</table><br></div><div id="'+$okayid+'" style="display:none"><table class = "table-class">
        <tr><th>SCHEMA_NAME</th><th>OBJECT TYPE</th><th>OBJECT</th><th>STATUS</th></tr>'
        echo $htmlformat|Out-File -Append $reportfile #file write
        foreach($okay in $okays)
       {
            $htmlformat ="<tr><td>"+$okay.SchemaName +"</td><td>" +$okay.object_type + "</td><td>" + $okay.object + "</td><td><font color='"+$color[$okay.prerecord][$okay.postrecord]+
            "'>" + $index[$okay.prerecord][$okay.postrecord] +"</font></td></tr>" 
            echo $htmlformat|Out-File -Append $reportfile #file write
        }

        $htmlformat = '</table></div><br>'
        echo $htmlformat|Out-File -Append $reportfile #file write
    }
    $htmlformat = "<br><br>"
    echo $htmlformat|Out-File -Append $reportfile #file write
    $end_time = Get-Date
    $end = Get-Date -format G
    $tspan = New-TimeSpan -start $start_time -end $end_time
    $seconds = ([TimeSpan]::Parse($tspan)).TotalSeconds
    echo "COMPLETED : $start | $end | $seconds sec | REPORT GENERATION on $ser" | Tee-Object -FilePath $consoleoutput -append | Tee-Object -FilePath $errorlog -append
}
$htmlformat = $htmlformat + "</ul></body></html>"
echo $htmlformat|Out-File -Append $reportfile #file write
$end_time = Get-Date
$end = get-date -format G
$tspan = New-TimeSpan -start $start_time -end $end_time
$seconds = ([TimeSpan]::Parse($tspan)).TotalSeconds
if($errorlist.Count -eq 0){
   echo "COMPLETED : $end | REPORT GENERATION" | Tee-Object -FilePath $consoleoutput -append | Tee-Object -FilePath $errorlog -append
}
else{
   echo "ERROR : $end | REPORT GENERATION" | Tee-Object -FilePath $consoleoutput -append | Tee-Object -FilePath $errorlog -append
   echo "Error Summary:" | Tee-Object -FilePath $consoleoutput -append | Tee-Object -FilePath $errorlog -append
   echo "   $errorlist" | Tee-Object -FilePath $consoleoutput -append | Tee-Object -FilePath $errorlog -append
}
}

<#
Function SendReportMail{
    $From = "<SenderEmail>"
    $To = "<ReceiverEmail"
    $Attachment = $reportfile
    $Subject = "RDBMS Server Report"
    $Body = "An attachement of RDBMS Server Report has been included in this email."
    $SMTPServer = "<SMTP>"
    $SMTPPort = "<port number>"
    Send-MailMessage -From $From -to $To -Subject $Subject -Body $Body -SmtpServer $SMTPServer -port $SMTPPort -Attachments $Attachment
}
#>

#main Execution
$todaydate =  get-date -format "dd_MM_yyyy"
$consoleoutput = $path+'\Rdbms_Output_'+$todaydate+'.txt'
#generate the record id to differentiate the records from same userid
$serverid_list = $serverid_list | sort-object
$recordid_pat = $uid.replace("\","").replace("/","").replace("_","").replace("-","")
foreach($serverid in $serverid_list){
    $recordid_pat += $serverid.ToString()
}
$recordid_pat1 = $recordid_pat
$recordid_pat += '_'

#connection string parameters
$dbname = "REPORT"
$connectionstring = "Server=$central_servername; uid=$username; pwd=$password; Database=$dbname; Integrated Security=True;"
$connection = new-object System.Data.SqlClient.SqlConnection
$connection.ConnectionString = $connectionstring
$connection.open()
$command = new-object System.Data.Sqlclient.Sqlcommand
$command.connection = $connection
#insert and update may take several minutes and sqlcommand may get timedout so ->
$command.CommandTimeout = 0
$serverlist = GetServerList $serverid_list
#if date is null
if(!$date){
    if($type -eq 'pre'){
        $idnum = GenerateRecordIDnum
        $idnum += 1
        $recordid = $recordid_pat+$idnum 
        $errorlog = $path+'\Rdbms_Log_'+$recordid+'.txt'
        echo "--------------- $recordid Record Output ---------------" | out-file -append $consoleoutput
        Out-File $errorlog
        PreAnalysisRecord $serverlist $username $recordid
    }
    elseif($type -eq 'post'){
        #check whether the recordid exists or not
        $idnum = GenerateRecordIDnum
        if ($idnum -eq 0){
            echo "The Recordid doesnot exist. May be you are missing some server parameters."
            exit
        }
        $recordid = $recordid_pat+$idnum
        #report location
        $reportfile = $path+'\RdbmsReport_'+$recordid+'.html'
        $errorlog = $path+'\Rdbms_Log_'+$recordid+'.txt'
        echo "--------------- $recordid Record Output ---------------" | out-file -append $consoleoutput
        PostAnalysisRecord $serverlist $username $recordid 
        GenerateReport $serverlist $username $recordid
        #SendReportMai
    }
    else{
        echo "Invalid Analysis Type - $type"
        exit
    }
}
#if $date is not null
else{
    if($type -eq 'post'){
        $date = $date.replace("/","")
        $date = $date.replace("-","")
        $query = "select distinct * from (select convert(int,replace(recordid,'"+$recordid_pat+"','')) as idnum from rdbmsrecord where recordid like '"+$recordid_pat1+"[_]"+"%' and replace(convert(varchar, postrecord_date, 105),'-','') = '"+$date+"') as p order by idnum desc"
        $command.CommandText = $query
        $result = $command.executereader()
        $table = New-Object System.Data.DataTable
        $table.load($result)
        if($table[0].rows.count -eq 0){
            echo "The recordid matching the date is invalid. Make sure PostRecord on that date exists."
            exit
        }
        else{
            $num = $table[0].rows[0].idnum
            $recordid = $recordid_pat+$num
            $reportfile = $path+'\RdbmsReport_'+$date+'_'+$recordid+'.html'
            $errorlog = $path+'\Rdbms_Log_'+$recordid+'.txt'
            GenerateReport $serverlist $username $recordid
            #SendReportMail
        }
    }
    else{
        echo "Invalid Analysis Type - $type"
        exit
    }
}
$connection.close()
