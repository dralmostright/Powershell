﻿[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null

$serverlist = @(
"NVEIDBBACKUPP1"
)

#$servername = 'nveidbbackupp1'
$AgentAlertList = @()
$csvfile = "C:\temp\AgentAlert.csv"

foreach($servername in $serverlist){
    $sqlserver = new-object "Microsoft.SqlServer.Management.Smo.Server" $servername
          
     foreach($ialert in $sqlserver.JObserver.Alerts){
        foreach($inot in $ialert.EnumNotifications()){
            #echo $inot.OperatorName
            $AgentAlertInfo = New-Object PSObject -Property @{
                "ServerName" = $servername;
                "Alertname" = $ialert.name;
                "Operator" = $inot.OperatorName;
            } 
            $AgentAlertList += $AgentAlertInfo
        }
               

    }
    
}

$AgentAlertList | select ServerName, Alertname, Operator | Export-Csv -Path $csvfile -NoTypeInformation





