﻿$serverlist = @(
'NVEI2HOSTRDBU01',
'NVEI2ADBU01',		
'NVEI2ADBU02',		
'NVEI1RDBU1',		
'NVEI1RDBU3',		
'NVEI1ADBU10',		
'NVEI1ADBU11'			
		
)

[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null
foreach($servername in $serverlist){
    $server = New-Object Microsoft.SqlServer.Management.Smo.Server $servername
    echo $server.Name
    foreach($login in $server.logins){
        if ($login.Name -iMatch 'i82283'){
            echo "$servername  $($login.Name)"
        }
    }
}