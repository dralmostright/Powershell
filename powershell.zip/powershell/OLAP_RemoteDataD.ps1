﻿param($LOGNAME, $DropDatabases)
### Parameters to be set ####
#$LOGNAME='DATADESTRUCTION_TEST_OLAP_BEFORE'
#$servername='NPEIODBP5'
#$DropDatabases=@('HAP - Production', 'HAP - Proofing')


$logfile = "C:\temp\$($LOGNAME).txt"

Function WriteTable{
    param($disObject)

    $disObject | Format-Table -AutoSize #| out-file -Append $logfile
}
Function WriteLog{
    param($logtext)
    $logtext #| Out-File -Append $logfile
}
function GetFolderSize{
    param($foldername)
    try{
        $foldersize = Get-ChildItem -recurse $foldername -ErrorAction Stop | Measure-Object -Property Length -Sum 
        $sizeMB = $foldersize.Sum /1MB
    }catch{
        $sizeMB = -1
    }
    return $sizeMB
}

Function OLAPsize{
    param($db, $defaultdir)
    
    #Get base location of database
    $baselocation = $defaultdir
    if($db.DbStorageLocation -ne $null){
        if($db.DbStorageLocation.StartsWith("\\?\")){
            $baselocation = $db.DbStorageLocation.replace("\\?\","")
        }
        else{
            $baselocation = $db.DbStorageLocation
        }
    }

    try{
        #Get database folder
        $namecheck = $db.ID + "."
        $folder = $($(Get-ChildItem $baselocation | Where-Object {$_.PSIsContainer -eq $True}) | Where-Object {$_.Name.StartsWith($namecheck)}).Name
        if($folder -eq $null){
            throw "Folder not Found"
        }
        $Dblocation = $baselocation + "\"+$folder
    
        #Get database size
        $dbsize = GetFolderSize $Dblocation
        if($dbsize -lt 0){
            throw "Get-ChildItem Error"
        }

        #Check if partition data exists in different location
        $partFolders = @()
        foreach($cube in $db.Cubes){
            foreach($mg in $cube.MeasureGroups){
                foreach($part in $mg.Partitions){
                    if($part.StorageLocation -ne $null){
                        if($partFolders -notcontains $part.StorageLocation){
                            $partFolders += $part.StorageLocation
                        }
                    }
                }
            }
        }
        if($partFolders.Length -gt 0){
            foreach($partFolder in $partFolders){
                $partsize = GetFolderSize $partFolder
                if($partsize -lt 0){
                    throw "Get-ChildItem Error"
                }
                $dbsize += $partsize
            }
        }

    }catch{
        $dbsize = -1
    }
    return [math]::Round($dbsize,2)
}

[System.Reflection.Assembly]::LoadWithPartialName('Microsoft.AnalysisServices') | Out-Null
### Reset Log file
#Out-File $logfile
$servername=$env:COMPUTERNAME
$olapserver=New-object('Microsoft.AnalysisServices.Server') 
$olapserver.connect($servername)
$defaultdatadir = $($olapserver.ServerProperties | Where-object {$_.Name -eq "DataDir"}).Value


########## Server Details ###########
WriteLog ">>>> Server Details"
[array]$ServerDetails = New-Object PSObject -Property @{
    "NAME" = $olapserver.Name;
    "SERVERMODE" = $olapserver.ServerMode;
    "VERSION" = $olapserver.Version; 
}
WriteTable $($ServerDetails | select NAME, SERVERMODE, VERSION)

########## Database Details ##########
WriteLog ">>>> Database Details"
$DatabaseDetails=@()
foreach($db in $olapserver.Databases){
    if($DropDatabases -icontains $db.Name){
        $dbsize = OLAPsize $db $defaultdatadir
        [array]$Dbdetail = New-Object PSObject -Property @{
            "NAME" = $db.Name;
            "DATASOURCE" = $db.DataSources;
            "CREATE_DATE" = $db.CreatedTimeStamp;
            "LAST_UPDATE" = $db.LastUpdate;
            "STATE" = $db.state;
            "ESTIMATED_SIZE_MB" = [math]::round($db.EstimatedSize/1MB,2);
            "DATA_SIZE_MB" = $dbsize;
            "COMPATIBILITY_LEVEL" = $db.CompatibilityLevel   
        }
        $DatabaseDetails += $Dbdetail
    }
}
[array]$Dbdetail = New-Object PSObject -Property @{
    "NAME" = "";
    "DATASOURCE" = "";
    "CREATE_DATE" = "";
    "LAST_UPDATE" = "";
    "STATE" = "";
    "ESTIMATED_SIZE_MB" = "";
    "DATA_SIZE_MB" = "";
    "COMPATIBILITY_LEVEL" = "";   
}
$DatabaseDetails += $Dbdetail
WriteTable $($DatabaseDetails | Select NAME, DATASOURCE, CREATE_DATE, LAST_UPDATE, STATE, ESTIMATED_SIZE_MB, DATA_SIZE_MB, COMPATIBILITY_LEVEL)
#WriteTable $($DatabaseDetails | Select NAME, ESTIMATED_SIZE_MB, DATA_SIZE_MB)

########## Object Details ###########
WriteLog ">>>> Object Details"
$dbcounter=0
foreach($db in $olapserver.Databases){
    if($DropDatabases -icontains $db.name){
        $dbcounter=$dbcounter + 1
        $ObjectDetails = @()
        try{
            ### Cube Details
            foreach($cube in $db.Cubes){
                [array]$cubeDetail = New-Object PSObject -Property @{
                    "DATABASE" = $db.Name;
                    "OBJECT" = $Cube.name;
                    "TYPE" = "Cube";
                    "STATE" = $cube.State;
                    "STORAGEMODE" = $cube.StorageMode;
                }
                $ObjectDetails += $cubeDetail
            }
            ### Dimension Details
            foreach($dim in $db.Dimensions){
                [array]$dimDetail = New-Object PSObject -Property @{
                    "DATABASE" = $db.Name;
                    "OBJECT" = $dim.name;
                    "TYPE" = "Dimension";
                    "STATE" = $dim.State;
                    "STORAGEMODE" = $dim.StorageMode;
                }
                $ObjectDetails += $dimDetail
            }
        }catch{
            WriteLog "Error : $($_.Exception.Message)"
        }
        WriteTable $($ObjectDetails | Select DATABASE, OBJECT, TYPE, STATE, STORAGEMODE )
    }
        
} 
if($dbcounter -eq 0){
    $ObjectDetails = @()
    [array]$dimDetail = New-Object PSObject -Property @{
        "DATABASE" = "";
        "OBJECT" = "";
        "TYPE" = "";
        "STATE" = "";
        "STORAGEMODE" = "";
    }
    $ObjectDetails += $dimDetail
    WriteTable $($ObjectDetails | Select DATABASE, OBJECT, TYPE, STATE, STORAGEMODE )
}

