﻿$path = '\\nveidbbackupp1\Adhoc_Backup\NPlink'
$dbadm_pwd = 'h9OT6F*1DG'

[System.Reflection.Assembly]::LoadwithpartialName('Microsoft.SqlServer.Smo') | Out-Null

$centralserver = New-Object 'Microsoft.SqlServer.Management.Smo.Server' 'NPEIBACKUPP1'
Import-Module sqlps -DisableNameChecking
set-Location 'C:\'
$To_create =@(

'ADSI',
'NVEI1ADBU10',
'NVEI1ADBU11',
'NVEI2ADBU01',
'NVEI2ADBU02',
'NVEIADBP01',
'NVEIADBP02',
'NVEIHOSTRDBP1',
'NVEIHOSTRDBP2',
'NVEIODBP1',
'NVEIODBP2',
'NVEIODBP8',
'NVEIPROCRDB01',
'NVEIPROCRDB02',
'NVEIPROCRDB03',
'NVEIPROCRDB04',
'NVEIRDBP1',
'NVEIRDBP2',
'NVEIRDBP8',
'NVEISVCQCP2',
'NVSOAMDBP2.D2HAWKEYE.NET',
'PROD-ADB-AG'
)

foreach($lnk in $centralserver.LinkedServers){
    if($To_create -icontains $lnk.Name){
        $lnk.name
         $sqlfile = "$path\$($lnk.Name).sql"
        $($lnk.script()).replace('########', $dbadm_pwd) | out-file $sqlfile

        invoke-sqlcmd -inputfile $sqlfile -ServerInstance 'NVEIDBBACKUPP1' -Database 'master' -DisableVariables
    }
}