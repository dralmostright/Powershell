﻿$path = '\\nveidbbackupp1\Adhoc_Backup\NPjobs'

[System.Reflection.Assembly]::LoadwithpartialName('Microsoft.SqlServer.Smo') | Out-Null

$centralserver = New-Object 'Microsoft.SqlServer.Management.Smo.Server' 'NPEIBACKUPP1'
Import-Module sqlps -DisableNameChecking
set-Location 'C:\'

foreach($job in $centralserver.JobServer.Jobs){
    if($job.IsEnabled -eq $true){
        $sqlfile = "$path\$($job.Name).sql"
        $sqlfile 
        $($job.Script()).replace('\\npeibackupp1','\\nveidbbackupp1') | out-file "$sqlfile"
       

        invoke-sqlcmd -inputfile $sqlfile -ServerInstance 'NVEIDBBACKUPP1' -Database 'master' -DisableVariables
    }

} 
