﻿$path = '\\nveidbbackupp1\Adhoc_Backup\NPproc'

[System.Reflection.Assembly]::LoadwithpartialName('Microsoft.SqlServer.Smo') | Out-Null

$centralserver = New-Object 'Microsoft.SqlServer.Management.Smo.Server' 'NPEIBACKUPP1'
Import-Module sqlps -DisableNameChecking
set-Location 'C:\'

$db = $centralserver.Databases.Item('master')
#$db.StoredProcedures.Owner # |get-member
$proc = $db.StoredProcedures  | where-object {$_.schema -ieq 'dbo'} #| get-member
foreach($myproc in $proc){
   if($myproc.name -imatch 'sp_MS') {continue}
   $sqlfile = "$path\$($myproc.Name).sql"
   $($myproc.Script()).replace('SET QUOTED_IDENTIFIER ON', 'SET QUOTED_IDENTIFIER ON
   GO') | out-file $sqlfile

   invoke-sqlcmd -inputfile $sqlfile -ServerInstance 'NVEIDBBACKUPP1' -Database 'master' -DisableVariables
}



