﻿param($servername, $csvfile)

Function WriteTable{
    param($disObject)

    $disObject | Format-Table -AutoSize #| out-file -Append $logfile
}

function GetFolderSize{
    param($foldername)
    try{
        $foldersize = Get-ChildItem -recurse $foldername -ErrorAction Stop | Measure-Object -Property Length -Sum 
        $sizeMB = $foldersize.Sum /1MB
    }catch{
        $sizeMB = -1
    }
    return $sizeMB
}

Function OLAPsize{
    param($db, $defaultdir)
    
    #Get base location of database
    $baselocation = $defaultdir
    if($db.DbStorageLocation -ne $null){
        if($db.DbStorageLocation.StartsWith("\\?\")){
            $baselocation = $db.DbStorageLocation.replace("\\?\","")
        }
        else{
            $baselocation = $db.DbStorageLocation
        }
    }

    try{
        #Get database folder
        $namecheck = $db.ID + "."
        $folder = $($(Get-ChildItem $baselocation | Where-Object {$_.PSIsContainer -eq $True}) | Where-Object {$_.Name.StartsWith($namecheck)}).Name
        if($folder -eq $null){
            throw "Folder not Found"
        }
        $Dblocation = $baselocation + "\"+$folder
    
        #Get database size
        $dbsize = GetFolderSize $Dblocation
        if($dbsize -lt 0){
            throw "Get-ChildItem Error"
        }

        #Check if partition data exists in different location
        $partFolders = @()
        foreach($cube in $db.Cubes){
            foreach($mg in $cube.MeasureGroups){
                foreach($part in $mg.Partitions){
                    if($part.StorageLocation -ne $null){
                        if($partFolders -notcontains $part.StorageLocation){
                            $partFolders += $part.StorageLocation
                        }
                    }
                }
            }
        }
        if($partFolders.Length -gt 0){
            foreach($partFolder in $partFolders){
                $partsize = GetFolderSize $partFolder
                if($partsize -lt 0){
                    throw "Get-ChildItem Error"
                }
                $dbsize += $partsize
            }
        }

    }catch{
        $dbsize = -1
    }
    return [math]::Round($dbsize,2)
}


#$flatfile = "C:\temp\$($servername)_Catalogs.csv"
#Out-File $flatfile
[Reflection.Assembly]::LoadWithPartialName("Microsoft.AnalysisServices") ;

$olapserver = New-Object Microsoft.AnalysisServices.Server ;
$olapserver.connect($servername)
$defaultdatadir = $($olapserver.ServerProperties | Where-object {$_.Name -eq "DataDir"}).Value

$Catalog_array=@()
foreach($db in $olapserver.databases){
    echo "$($db.name)"
    $olapsize = Olapsize $db $defaultdatadir
    $catalog_details = New-Object PSObject -Property @{
        "Server" = $($olapserver.name);
        "Database" = $($db.Name);
        "Estimated_Size" = $($db.EstimatedSize/1MB);
        "Actual_Size_MB" = [math]::round($olapsize,2)
        "Actual_Size_GB" = [math]::round($olapsize/1024,2)
    }
    $Catalog_array += $catalog_details
    #WriteTable $($catalog_details | select Server,Database,Estimated_Size,Actual_Size)
}

$Catalog_array | select Server,Database,Estimated_Size,Actual_Size_MB,Actual_Size_GB | export-csv $csvfile -NoTypeInformation


