﻿#$serverlist = @('NVEI2HOSTRDBU01', 'NVEI2ADBU01', 'NVEI2ADBU02')
#$serverlist = @('NVEI1RDBU1','NVEI1RDBU3','NVEI1ADBU10', 'NVEI1ADBU11')
#$serverlist = @('NVEIPROCRDB01', 'NVEIPROCRDB02', 'NVEIPROCRDB03', 'NVEIPROCRDB04')
$serverlist = @('NVEIHOSTRDBP1', 'NVEIHOSTRDBP2', 'NVEIRDBP1', 'NVEIRDBP2')
#$serverlist = @('NVEI2HOSTRDBU01')
#$userlist = @('i82282', 'araryal', 'arjunaryal', 'arjaryal')
$userlist = @('angeelamanandhar',
'amanandhar',
'i20775')
$disable = 0


Function DisableUser{
    param([ref]$Errorlist)
    $userArray = @()
    [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null
    foreach($servername in $serverlist){
        echo "`nServer :: $($servername)"
        $server = New-Object Microsoft.SqlServer.Management.Smo.Server $servername
        $logins = $server.Logins
        foreach($login in $logins){
            foreach($username in $userlist){
                if($login.Name.ToUpper() -imatch $username){
                    if($disable -eq 1){
                        echo "Disabling Login $($login.Name)"
                        try{
                            $login.Disable()
                            echo "Disable Successful for Login $($login.name)"
                        }
                        catch{
                            $ErrorList.Value += "Disable Failed for Login $($login.Name) : $($_.Exception.Message)"
                        }
                    }
                    else{
                        echo $username
                        echo "Login $($login.Name) exists."    
                    }
                }
            }
        }
    }
}

#$csvfile = $path + '\'+$servername+'_RdmcleanUplist.csv'
$Errorlist = @()

DisableUser ([Ref]$Errorlist)

if($Errorlist.Count -gt 0){
    echo "Error Summary:"
    foreach($err in $Errorlist){
        echo "`t`t $err"
    }
}