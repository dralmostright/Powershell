﻿$serverlist = @(
'NVEI2HOSTRDBU01',	
'NVEI2ADBU01',	
'NVEI2ADBU02',	
'NVEI1RDBU1',	
'NVEI1RDBU3',	
'NVEI1ADBU10',	
'NVEI1ADBU11')
$loadinfo = [Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")

foreach($servername in $serverlist){
    $accessDetails =@()
    $sqlserver = New-Object("Microsoft.SqlServer.Management.Smo.Server") $servername
    $csvfile = "C:\Temp\$($servername).csv"


    foreach($login in $sqlserver.logins){
        if($login.Name.ToUpper().StartsWith('NT') -or $login.Name.ToUpper().StartsWith('##')) { continue } 
        $serverRoles= @('public')
        foreach($role in $sqlserver.Roles){
            $members = $role.EnumServerRoleMembers()
            if($members -icontains $login.Name){
                $serverRoles += $role.Name
            }
        }
       [array]$useraccess = New-object PSObject -Property @{
                "Database" = " -- "
                "Username" = $login.Name
                "Roles" = $serverRoles -join ', '
                "Grants" = ''
            }
            $accessDetails += $useraccess
             
    }

    $excludeDBs = @('MASTER', 'MODEL', 'MSDB', 'TEMPDB', 'DISTRUBUTION')
    foreach($db in $sqlserver.Databases){
        $db.Name
        if($excludeDBs -icontains $db.name) { continue }
        if($db.Status -imatch 'Offline') { continue }
        $excludeUsers = @('sys', 'dbo', 'guest', 'INFORMATION_SCHEMA')
        foreach($usr in $db.Users){
            $usr.Name
            if($excludeUsers -icontains $usr.Name) { continue }
            $userName = $usr.Name
            $userRoles =  $usr.EnumRoles()
            $grants = $db.EnumObjectPermissions() | where-object { $_.Grantee -ieq $usr.Name}
            if($grants -ne $null){
                $userGrants = @()
                foreach($grant in $grants){
                    $userGrants += "$($grant.PermissionState) $($grant.PermissionType) on $($grant.ObjectName)"
                }

                [array]$useraccess = New-object PSObject -Property @{
                    "Database" = $db.Name
                    "Username" = $userName
                    "Roles" = $userRoles -join ', '
                    "Grants" = $userGrants -join ', '
                }
                $accessDetails += $useraccess
            }
        }

    }

$accessDetails | select Database, Username, Roles, Grants | export-csv -path $csvfile -NoTypeInformation    
}



