﻿########################################################################################################################
# Filename	: SSRS_GetDataSources.ps1
# Created by	: Pawan K Shrestha
# Created on	: 2017-06-08
# 
# This script will generate a csv file with datasource for reports
# https://msdn.microsoft.com/en-us/library/reportservice2005.datasourcedefinition.credentialretrieval(v=sql.105).aspx
#
# .\SSRS_GetDataSources.ps1 -servername 'nveihostrpsp02' -path 'C:\Temp'
#
########################################################################################################################
#param($path, $servername) 

$path = 'C:\temp'
$servername = 'nveihostrpsp02'


$debug=1
$global:msgCollection=""
$commonLog=""
$logfile = "$($path)\SSRS_datasourcelog_$(get-date -Format "yyyyMMdd_hhmmss").txt"

Function LogMessage{
    if($debug -eq 1){
        write-host $args
    }
    $global:msgCollection=$global:msgCollection + "`r`n" + $args
}

$outputCSVFile=$path+"\SSRS_Datasources.csv"
$ReportServerUri = 'http://'+$servername+'/ReportServer/ReportService2010.asmx?wsdl'

$rsProxy = New-WebServiceProxy -Uri $ReportServerUri -UseDefaultCredential

$dsItem= @()
$dsResult=@()
$reports = $rsProxy.ListChildren("/", $true) | SELECT TypeName, Path, ID, Name,Role | Where-Object { ($_.typeName -eq "Report") }
$reports | ForEach-Object {
            $reportPath = $_.path
            $reportType = $_.TypeName
            $dataSources=$rsProxy.GetItemDataSources($reportPath)
           
            
            foreach($ds in $dataSources){
                #Write-host $reportPath ":" $ds.Name ":" $ds.Item.ConnectString ":" $ds.Item.UserName ":" $ds.Item.Password
                #if($ds.Item.ConnectString -imatch "vs_relational2"){
                    LogMessage "Info |" (Get-Date) " | Scripting Datasource properties for $($reportPath)"
                    [array]$dsItem = New-Object PSObject -Property @{
                        "TypeName" = $reportType
			            "Path" = $reportPath
			            "Name" = $ds.Name
                        "Reference" = $ds.Item.Reference
			            "ConnectString"=$ds.Item.ConnectString
			            "CredentialRetrieval"=$ds.Item.CredentialRetrieval
			            "Enabled"=$ds.Item.Enabled
			            "EnabledSpecified"=$ds.Item.EnabledSpecified
			            "Extension"=$ds.Item.Extension
			            "ImpersonateUser"=$ds.Item.ImpersonateUser
			            "ImpersonateUserSpecified"=$ds.Item.ImpersonateUserSpecified
			            "OriginalConnectStringExpressionBased"=$ds.Item.OriginalConnectStringExpressionBased
			            "Password"=$ds.Item.Password
			            "Prompt"=$ds.Item.Prompt
			            "UseOriginalConnectString"=$ds.Item.UseOriginalConnectString
			            "UserName"=$ds.Item.UserName
			            "WindowsCredentials"=$ds.Item.WindowsCredentials
             	    }
                    $dsResult += $dsItem
                    LogMessage "Info |" (Get-Date) " | Completed Scripting Datasource properties for $($reportPath)"
                #}
            }
            
} 


$dss = $rsProxy.ListChildren("/", $true) | SELECT TypeName, Path, ID, Name,Role | Where-Object { ($_.typeName -eq "DataSource") }
foreach($ds in $dss){
    $dsinfo = $rsproxy.GEtDataSourceContents($ds.Path)
        #if($dsinfo.ConnectString -imatch "vs_relational5"){
        [array]$dsItem = New-Object PSObject -Property @{
                "TypeName" = $ds.TypeName
			    "Path" = $ds.Path
			    "Name" = $ds.Name
                "Reference" = $ds.Path
			    "ConnectString"=$dsinfo.ConnectString
			    "CredentialRetrieval"=$dsinfo.CredentialRetrieval
			    "Enabled"=$dsinfo.Enabled
			    "EnabledSpecified"=$dsinfo.EnabledSpecified
			    "Extension"=$dsinfo.Extension
			    "ImpersonateUser"=$dsinfo.ImpersonateUser
			    "ImpersonateUserSpecified"=$dsinfo.ImpersonateUserSpecified
			    "OriginalConnectStringExpressionBased"=$dsinfo.OriginalConnectStringExpressionBased
			    "Password"=$dsinfo.Password
			    "Prompt"=$dsinfo.Prompt
			    "UseOriginalConnectString"=$dsinfo.UseOriginalConnectString
			    "UserName"=$dsinfo.UserName
			    "WindowsCredentials"=$dsinfo.WindowsCredentials
        }
        $dsResult += $dsItem
    #}
}


$dsResult | SELECT TypeName,Path,Name, Reference,ConnectString,CredentialRetrieval,Enabled,EnabledSpecified,Extension,ImpersonateUser,ImpersonateUserSpecified,OriginalConnectStringExpressionBased,Password,Prompt,UseOriginalConnectString,UserName,WindowsCredentials | Export-Csv -Path $outputCSVFile -NoTypeInformation

$global:msgCollection | Out-File $logFile