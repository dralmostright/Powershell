﻿[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null

$serverlist = @(
"NVEIDBBACKUPP1"
)

#$servername = 'nveidbbackupp1'

foreach($servername in $serverlist){
    echo "Creating operators in $servername"
    $sqlserver = new-object "Microsoft.SqlServer.Management.Smo.Server" $servername
    $oper = 'SYSDBA'
    $op = New-Object ('Microsoft.SqlServer.Management.Smo.Agent.Operator') ($sqlserver.JobServer,$oper)
    $op.EmailAddress = "#DL-MSSQLSYSDBA@cotiviti.com"
    $op.Create()
    
    
}





