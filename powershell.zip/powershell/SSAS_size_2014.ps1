﻿$SSASServerName = 'nvei2hostodbu01'
$txtfile = "\\npeibackupp1\Adhoc_Backup\Reports\nvei2hostodbu01_SSASsize.txt"

function GetFolderSize{
    param($foldername)
    try{
        $foldersize = Get-ChildItem -recurse $foldername -ErrorAction Stop | Measure-Object -Property Length -Sum 
        $sizeMB = $foldersize.Sum /1MB
    }catch{
        $sizeMB = -1
    }
    return $sizeMB
}


[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.AnalysisServices") | Out-Null
$server = new-object Microsoft.AnalysisServices.Server
$server.connect($SSASServerName)
echo "$("Catalog".PadRight(50))$("Size in MB")" | Out-File $txtfile

$defaultdir = $($server.ServerProperties | Where-object {$_.Name -eq "DataDir"}).Value

foreach($db in $server.Databases){
    echo $db.Name
    #Get base location of database
    $baselocation = $defaultdir
    if($db.DbStorageLocation -ne $null){
        if($db.DbStorageLocation.StartsWith("\\?\")){
            $baselocation = $db.DbStorageLocation.replace("\\?\","")
        }
        else{
            $baselocation = $db.DbStorageLocation
        }
    }

    try{
        #Get database folder
        $namecheck = $db.Name + "."
        $folder = $($(Get-ChildItem $baselocation | Where-Object {$_.PSIsContainer -eq $True}) | Where-Object {$_.Name.StartsWith($namecheck)}).Name
        if($folder -eq $null){
            throw "Folder not Found"
        }
        $Dblocation = $baselocation + "\"+$folder
        echo $Dblocation
    
        #Get database size
        $dbsize = GetFolderSize $Dblocation
        if($dbsize -lt 0){
            throw "Get-ChildItem Error"
        }
    }catch{
        echo "Needs Manual Check"
        echo "$($db.Name.PadRight(50))N/A" | Out-File -Append $txtfile
        continue;
    }

    #Check if partition data exists in different location
    $partFolders = @()
    foreach($cube in $db.Cubes){
        foreach($mg in $cube.MeasureGroups){
            foreach($part in $mg.Partitions){
                if($part.StorageLocation -ne $null){
                    if($partFolders -notcontains $part.StorageLocation){
                        $partFolders += $part.StorageLocation
                    }
                }
            }
        }
    }
    if($partFolders.Length -gt 0){
        foreach($partFolder in $partFolders){
            echo $partFolder
            $partsize = GetFolderSize $partFolders
            $dbsize += $partsize
        }
    }
    echo "$($db.Name.PadRight(50))$([math]::Round($dbsize,2))" | Out-File -Append $txtfile
}
