﻿Import-Module "$($PSScriptRoot)\Writer.psm1"
Import-Module "$($PSScriptRoot)\rdmrestore.psm1"
Import-Module "$($PSScriptRoot)\ThreadHelper.psm1"



$centralservername = 'nveidbbackupp1'
$centralDBName = 'REPORT'
$BackupDir = '\\10.48.2.85\Adhoc_Backup\ProdUpgrade\RDM'
$serverlist = @(

'NVEIPROCRDB01-n.prod.ops.global.ad',
'NVEIPROCRDB02-n.prod.ops.global.ad',
'NVEIPROCRDB04-n.prod.ops.global.ad'

)

[System.Reflection.Assembly]::LoadwithpartialName('Microsoft.SqlServer.Smo') | Out-Null

$MaxThreads = $serverlist.Count
$ISS = [system.management.automation.runspaces.initialsessionstate]::CreateDefault()
$ISS.ImportPSModule("$($PSScriptRoot)\rdmrestore.psm1")
$ISS.ImportPSModule("$($PSScriptRoot)\Writer.psm1")
$RunspacePool = [runspacefactory]::CreateRunspacePool(1, $MaxThreads, $ISS, $Host)
$RunspacePool.Open() | Out-Null

$jobs=@()

### Execute PreRecord in threads
$jobs = ThreadInitiate $RunspacePool $CentralServerName $serverlist $BackupDir
ThreadStatus $jobs
$Errorlist = ThreadCleanup $jobs

$RunspacePool.Close()