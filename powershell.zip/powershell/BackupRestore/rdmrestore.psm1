﻿function ExecBackupRestore{
    param($centralServerName, $servername, $serverlog, $backupDir)

    [System.Reflection.Assembly]::LoadwithpartialName('Microsoft.SqlServer.Smo') | Out-Null
    [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoExtended") | Out-Null

    $centralserver = New-Object 'Microsoft.SqlServer.Management.Smo.Server' $centralServerName
    $centralserver.ConnectionContext.StatementTimeout = 0
    $centralDB = $centralserver.Databases.Item('REPORT')
    
    while(1){
        $loopQuery = "Select * from dbo.BackupRestore where RestoreServerName = '$servername' and status < 4"
        $loopResult = $centralDB.ExecuteWithResults($loopQuery)
        if($loopResult.Tables[0].Rows.Count -eq 0){
            LogMessage "$servername :: Restore Completed" $serverlog
            break
        }
        $jobQuery = "Select Top 1 * from dbo.BackupRestore where RestoreServerName = '$servername' and Status = 2"
        $QueryResult = $centralDB.ExecuteWithResults($jobQuery)
        if($QueryResult.Tables[0].Rows.Count -eq 0){
            DisplayMessage "$servername :: No Jobs in Queue" $serverlog
            sleep 30
            continue
        }

        $restoreJob = $QueryResult.Tables[0].Rows[0]
        $jobID = $restoreJob.JobID
        $BackupServerName = $restoreJob.ServerName
        $DatabaseName = $restoreJob.DatabaseName
        $DataDir = $restoreJob.DataDir
        $LogDir = $restoreJob.LogDir
        $BackupDir = $restoreJob.BackupDir
        $DOP = $restoreJob.DOP
        if([System.DBNull]::Value.Equals($DOP)) { $DOP = 1}

        # Update the table indicating backup started
        $centralDB.ExecuteNonQuery("Update dbo.BackupRestore set Status = 3 where JobID = $jobID")
        LogMessage "$servername :: Restore Started for db $DatabaseName" $serverlog
        try{
            #Server Connection
            $sqlserver = New-Object 'Microsoft.SqlServer.Management.Smo.Server' $servername
            $sqlserver.ConnectionContext.StatementTimeout = 0
            
            #Getting Domain name
            $comp_domain = $(Get-WmiObject Win32_ComputerSystem).Domain
            $fqdn = "$($servername).$($comp_domain)"

            #Creating Data and Log Directory if doesnot exists
            Invoke-Command -ComputerName $fqdn -ScriptBlock { param($DataDir) New-Item -ItemType directory -Path $DataDir -Force } -ArgumentList $DataDir | out-Null
            Invoke-Command -ComputerName $fqdn -ScriptBlock { param($LogDir) New-Item -ItemType directory -Path $LogDir -Force } -ArgumentList $LogDir | out-Null

            #Configure Restore Parameters
            $restore = New-Object Microsoft.SqlServer.Management.Smo.Restore
            $restore.Database = $DatabaseName

            #Adding the backup files
            for($i=1;$i -le $DOP; $i++){
                $bkpFileName = "$BackupDir\$($DatabaseName)_$($i).bak"
                $backupDeviceItem = new-object Microsoft.SqlServer.Management.Smo.BackupDeviceItem($bkpFileName, [Microsoft.SqlServer.Management.Smo.DeviceType]::File)
                $restore.Devices.Add($backupDeviceItem)
            }

            #Relocating the data and log files
            foreach($file in $restore.ReadFileList($sqlserver)){
                $relocateFile = New-object Microsoft.SqlServer.Management.Smo.RelocateFile
                $relocateFile.LogicalFileName = $file.LogicalName
                $Datafile = $($file.PhysicalName).Substring($($file.PhysicalName).LastIndexOf('\')+1)
                if($file.Type -ieq 'D'){
                    $relocateFile.PhysicalFileName = "$($DataDir)\$($Datafile)"
                }
                else{
                    $relocateFile.PhysicalFileName = "$($LogDir)\$($Datafile)"
                }
                $restore.RelocateFiles.Add($relocateFile)
            }

            #Percent Completed Event
            $percent = [Microsoft.SqlServer.Management.Smo.PercentCompleteEventHandler] {
                             LogMessage "$servername :: $DatabaseName Restore Progress $($_.Percent) %" $serverlog
                        }
            $restore.add_PercentComplete($percent)

            # Execute restore
            $restore.SqlRestore($sqlserver)

            #Close connection
            $sqlserver.ConnectionContext.Disconnect()

            #Update Table on completion of restore
            $centralDB.ExecuteNonQuery("Update dbo.BackupRestore set Status = 4 where JobID = $jobID")
            LogMessage "$servername :: Restore Completed for db $DatabaseName" $serverlog


        }catch{
            $ErrMsg = "$($_.Exception.Message.Replace("'", " "))"
            #Update Table on Failure of restore
            $centralDB.ExecuteNonQuery("Update dbo.BackupRestore set Status = 200, Remarks ='$ErrMsg' where JobID = $jobID")
            LogMessage "$servername :: Restore Failed for db $DatabaseName" $serverlog

            #Close connection
            $sqlserver.ConnectionContext.Disconnect()
        }

    } 

    #Close connection
    $centralserver.ConnectionContext.Disconnect()
}