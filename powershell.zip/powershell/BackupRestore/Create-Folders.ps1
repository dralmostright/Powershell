﻿$pathlist = @(
'E:\MSSQL\LOG\DEMO_2M',
'E:\MSSQL\Log\DEMO_DEVSTG',
'E:\MSSQL\LOG\DEMO_SYS',
'E:\MSSQL\Log\EnterpriseIntelligenceDemo_Devstg',
'E:\MSSQL\Log\EnterpriseIntelligenceDemo_Host',
'E:\MSSQL\DATA\DEMO_2M',
'E:\MSSQL\Data\DEMO_DEVSTG',
'E:\MSSQL\DATA\DEMO_SYS',
'E:\MSSQL\Data\EnterpriseIntelligenceDemo_Devstg',
'E:\MSSQL\Data\EnterpriseIntelligenceDemo_Host'
)

foreach($path in $pathlist){
New-Item -ItemType Directory -Force -Path $path
}