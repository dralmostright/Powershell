﻿Function ListUser{
    param($servername, $csvfile, $logfile)
    $userArray = @()
    [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.AnalysisServices") | Out-Null
    $server = New-Object Microsoft.AnalysisServices.Server
    $server.connect($servername)

    $administrators = $server.Roles["Administrators"]
    foreach($member in $administrators.Members){
        if($member.Name.ToUpper().StartsWith('PROD') -or $member.Name.ToUpper().StartsWith('D2HAWKEYE')){
            LogMessage "$servername :: Auditing User $($member.Name)" $logfile
            $userResult = New-Object PSObject -Property @{
                "Database" = "None";
                "Role" = "Administrators";
                "Member" = $member.Name
            }
            $userArray += $userResult
        }
    }

    $userArray | Export-Csv -path $csvfile -NoTypeInformation
}

Function CreateUser{
    param($servername, $csvfile, $logfile)

    [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.AnalysisServices") | Out-Null
    $server = New-Object Microsoft.AnalysisServices.Server
    $server.connect($servername)

    $userArray = Import-csv -path $csvfile
    foreach($user in $userArray){
        if($user.Database -eq "None"){
            LogMessage "$servername :: Adding Member $($user.Member) to Role $($user.Role)" $logfile
            $administrators = $server.Roles["Administrators"]
            try{
                if($administrators.Members.Name -icontains $user.Member){
                    throw "Member already exists."
                }
                $administrators.Members.Add($user.Member) | Out-Null
                $administrators.Update() 
                LogMessage "$servername :: Added Member $($user.Member) to Role $($user.Role)" $logfile
            }catch{
                LogMessage "$servername :: Failed to add Member $($user.Member) to Role $($user.Role) : $($_.Exception.Message)" $logfile
            }
        }
    }
}