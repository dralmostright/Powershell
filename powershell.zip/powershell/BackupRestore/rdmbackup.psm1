﻿function ExecBackupRestore{
    param($CentralServerName, $servername, $serverlog, $backupDir)

    [System.Reflection.Assembly]::LoadwithpartialName('Microsoft.SqlServer.Smo') | Out-Null
    [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoExtended") | Out-Null

    $centralserver = New-Object 'Microsoft.SqlServer.Management.Smo.Server' $CentralServerName
    $centralserver.ConnectionContext.StatementTimeout = 0
    $centralDB = $centralserver.Databases.Item('REPORT')
    
    while(1){
        $jobQuery = "Select Top 1 * from dbo.BackupRestore where ServerName = '$servername' and Status = 0"
        $QueryResult = $centralDB.ExecuteWithResults($jobQuery)
        if($QueryResult.Tables[0].Rows.Count -eq 0){
            LogMessage "$servername :: No Jobs in Queue" $serverlog
            break
        }

        $backupJob = $QueryResult.Tables[0].Rows[0]
        $jobID = $backupJob.JobID
        $DatabaseName = $backupJob.DatabaseName
        $DOP = $backupJob.DOP
        if([System.DBNull]::Value.Equals($DOP)) { $DOP = 1}

        # Update the table indicating backup started
        $centralDB.ExecuteNonQuery("Update dbo.BackupRestore set Status = 1 where JobID = $jobID")
        LogMessage "$servername :: Backup Started for db $DatabaseName" $serverlog
        try{
            #Server Connection
            $sqlserver = New-Object 'Microsoft.SqlServer.Management.Smo.Server' $servername
            $sqlserver.ConnectionContext.StatementTimeout = 0
            $db = New-Object Microsoft.SqlServer.Management.Smo.Database
            $db = $sqlserver.Databases.Item($DatabaseName)

            #Get DataDir and LogDir
            $masterfile = $($db.FileGroups.Files.FileName) | where-object { $_.ToLower().endswith('.mdf') } | select -First 1
            $DataDir = $masterfile.Substring(0,$masterfile.LastIndexOf('\'))
            $logfile = $($db.LogFiles.FileName) | where-object { $_.ToLower().endswith('.ldf') }
            $logDir = $logfile.Substring(0,$logfile.LastIndexOf('\'))

            #Creating Backup Directory if doesnot exists
            $bkpLocation = "$($backupDir)\$($servername)\$($DatabaseName)"
            New-Item -ItemType directory -Path $bkpLocation -Force | Out-Null

            #Configure Backup Parameters
            $bkp = new-object 'Microsoft.SqlServer.Management.Smo.Backup'
            $bkp.Action = [Microsoft.SqlServer.Management.Smo.BackupActionType]::Database
            $bkp.Database = $DatabaseName
            for($i=1; $i -le $DOP; $i++){
                $bkpFileName = "$($bkpLocation)\$($db.Name)_$($i).bak"
                $bkpDevice = new-object Microsoft.SqlServer.Management.Smo.BackupDeviceItem($bkpFileName, [Microsoft.SqlServer.Management.Smo.DeviceType]::File)
                $bkp.Devices.Add($bkpDevice)
            }
            $bkp.CompressionOption=1

            #Percent Completed Event
            $percent = [Microsoft.SqlServer.Management.Smo.PercentCompleteEventHandler] {
                             LogMessage "$servername :: $DatabaseName Backup Progress $($_.Percent) %" $serverlog
                        }
            $bkp.add_PercentComplete($percent)

            # Execute Backup
            $bkp.SqlBackup($sqlserver)
            
            # Close connection
            $sqlserver.ConnectionContext.Disconnect()

            #Update Table on completion of backup
            $centralDB.ExecuteNonQuery("Update dbo.BackupRestore set Status = 2, BackupDir = '$bkpLocation' where JobID = $jobID")
            LogMessage "$servername :: Backup Completed for db $DatabaseName" $serverlog


        }catch{
            $ErrMsg = "$($_.Exception.Message.Replace("'", " "))"
            $centralDB.ExecuteNonQuery("Update dbo.BackupRestore set Status = 100, Remarks ='$ErrMsg' where JobID = $jobID")
            LogMessage "$servername :: Backup Failed for db $DatabaseName" $serverlog

            # Close connection
            $sqlserver.ConnectionContext.Disconnect()
        }

    } 

    #Close central server
    $centralserver.ConnectionContext.Disconnect()
}