﻿Import-Module "$($PSScriptRoot)\Writer.psm1"
Import-Module "$($PSScriptRoot)\rdmUserRole.psm1"


$logpath = '\\npeibackupp1\Adhoc_Backup\Virtualization\Logins'

# Change the type value
#      1. 'pre' to fetch from physical server
#      2. 'post' to create in virtual server 
$type = 'post'   
$sourceserverlist = @('NPEIRDBP1','NPEIRDBP2', 'NPEIRDBP3', 'NPEIRDBP8')
$targetserverlist = @('NVEIHOSTRDBP1','NVEIHOSTRDBP2','NVEIHOSTRDBP3','NVEIHOSTRDBP4')

$dict = @{}
$dict.set_item('NVEIHOSTRDBP1','NPEIRDBP1')
$dict.set_item('NVEIHOSTRDBP2','NPEIRDBP2')
$dict.set_item('NVEIHOSTRDBP3','NPEIRDBP3')
$dict.set_item('NVEIHOSTRDBP4','NPEIRDBP8')


if($type -eq 'pre'){
    foreach($servername in $sourceserverlist){
        $logfile = "$($logpath)\$($servername).txt"

        #List the users
        $csvfile = "$($logpath)\$($servername)_RDMusers.csv"
        ListUser $servername $csvfile $logfile

        #List the server roles
        $csvfile = "$($logpath)\$($servername)_RDMroles.csv"
        ListRole $servername $csvfile $logfile
    }    
}elseif($type -eq 'post'){
    foreach($servername in $targetserverlist){
        $logfile = "$($logpath)\$($servername).txt"
        $mapped_server = $dict.get_item($servername)

        #List the users
        $csvfile = "$($logpath)\$($mapped_server)_RDMusers.csv"
        CreateUser $servername $csvfile $logfile

        #List the server roles
        $csvfile = "$($logpath)\$($mapped_server)_RDMroles.csv"
        CreateRole $servername $csvfile $logfile
    }    
}


