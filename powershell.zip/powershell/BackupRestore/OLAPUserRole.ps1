﻿Import-Module "$($PSScriptRoot)\Writer.psm1"
Import-Module "$($PSScriptRoot)\olapUserRole.psm1"


$logpath = '\\npeibackupp1\Adhoc_Backup\Virtualization\Logins'

# Change the type value
#      1. 'pre' to fetch from physical server
#      2. 'post' to create in virtual server 
$type = 'post'
$sourceserverlist = @('NPEIODBP3','NPEIODBP5', 'NPEIODBP6', 'NPEIODBP8') 
$targetserverlist = @(
'NVEIHOSTODBP3',
'NVEIHOSTODBP5',
'NVEIHOSTODBP1',
'NVEIHOSTODBP4'
)

$dict = @{}
$dict.set_item('NVEIHOSTODBP3','NPEIODBP3')
$dict.set_item('NVEIHOSTODBP5','NPEIODBP5')
$dict.set_item('NVEIHOSTODBP1','NPEIODBP6')
$dict.set_item('NVEIHOSTODBP4','NPEIODBP8')


if($type -eq 'pre'){
    foreach($servername in $sourceserverlist){
        $logfile = "$($logpath)\$($servername).txt"

        #List the users
        $csvfile = "$($logpath)\$($servername)_OLAPusers.csv"
        ListUser $servername $csvfile $logfile

    }    
}elseif($type -eq 'post'){
    foreach($servername in $targetserverlist){
        $logfile = "$($logpath)\$($servername).txt"
        $mapped_server = $dict.get_item($servername)

        #List the users
        $csvfile = "$($logpath)\$($mapped_server)_OLAPusers.csv"
        CreateUser $servername $csvfile $logfile

    }    
}
