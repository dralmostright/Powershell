﻿Import-Module "$($PSScriptRoot)\Writer.psm1"
Import-Module "$($PSScriptRoot)\olaprestore.psm1"
Import-Module "$($PSScriptRoot)\ThreadHelper.psm1"



$centralservername = 'NVEIDBBACKUPP1'
$centralDBName = 'REPORT'
$BackupDir = '\\10.48.2.85\Adhoc_Backup\ProdUpgrade\OLAP'
$serverlist = @(


'NVEIPROCODB02-n.prod.ops.global.ad',
'NVEIPROCODB01-n.prod.ops.global.ad'

)

[System.Reflection.Assembly]::LoadwithpartialName('Microsoft.SqlServer.Smo') | Out-Null

$MaxThreads = $serverlist.Count
$ISS = [system.management.automation.runspaces.initialsessionstate]::CreateDefault()
$ISS.ImportPSModule("$($PSScriptRoot)\olaprestore.psm1")
$ISS.ImportPSModule("$($PSScriptRoot)\Writer.psm1")
$RunspacePool = [runspacefactory]::CreateRunspacePool(1, $MaxThreads, $ISS, $Host)
$RunspacePool.Open() | Out-Null

$jobs=@()

### Execute PreRecord in threads
$jobs = ThreadInitiate $RunspacePool $CentralServerName $serverlist $BackupDir
ThreadStatus $jobs
$Errorlist = ThreadCleanup $jobs

$RunspacePool.Close()