﻿Function ListUser{
    param($servername, $csvfile, $logfile)
    $userArray = @()
    [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null
    $server = New-Object Microsoft.SqlServer.Management.Smo.Server $servername
    
    $logins = $server.Logins
    #$logins | get-member
    foreach($login in $logins){
        if($($login.Name.ToUpper().Startswith('PROD') -or $login.Name.ToUpper().Startswith('D2HAWKEYE')) ){
            LogMessage "$servername :: Auditing Login $($login.Name)" $logfile
            $userResult = New-Object PSObject -Property @{
                "USerType" = "Login";
                "Database" = "None";
                "Username" = $login.Name;
                "LoginType" = $login.LoginType;
            } 
            $userArray += $userResult
        }
    }

    $userArray | Export-Csv -path $csvfile -NoTypeInformation
}

Function ListRole{
    param($servername, $csvfile, $logfile)
    $roleArray = @()
    [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null
    $server = New-Object Microsoft.SqlServer.Management.Smo.Server $servername

    #Add the members of server roles
    $serverRoles = $server.Roles
    foreach($role in $serverRoles){
        LogMessage "$servername :: Auditing Role $($role.Name)" $logfile
        $role.EnumServerRoleMembers() | foreach{
            if($($_.ToUpper().Startswith('PROD') -or $_.ToUpper().Startswith('D2HAWKEYE'))){
                $roleResult =  New-object PSObject -Property @{
                    "Database" = "None";
                    "Role" = $role.Name;
                    "Member" = $_;
                }
                $roleArray += $roleResult
            }
        }
    }

    $roleArray | Export-Csv -path $csvfile -NoTypeInformation
}

Function CreateUser{
    param($servername, $csvfile, $logfile)

    [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null
    $server = New-Object Microsoft.SqlServer.Management.Smo.Server $servername
    
    $userArray = Import-csv -path $csvfile
    foreach($user in $userArray){
        if($user.UserType -eq "Login"){
            LogMessage "$servername :: Adding Login $($user.username)" $logfile
            $login = New-Object Microsoft.SqlServer.Management.Smo.Login -ArgumentList $server, $user.Username
            $login.LoginType = $user.LoginType
            try{
                $login.Create()
                LogMessage "$servername :: Added Login $($user.Username)" $logfile
            }catch{
                LogMessage "$servername :: Failed to add Login $($user.Username) :: $($_.Exception.Message)" $logfile
            }
        }
    }
}

Function CreateRole{
    param($servername, $csvfile, $logfile)
    
    [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null
    $server = New-Object Microsoft.SqlServer.Management.Smo.Server $servername

    $roleArray = Import-csv -path $csvfile
    foreach($role in $roleArray){
        if($role.Database -eq "None"){
            LogMessage "$servername :: Adding Member $($role.Member) to Role $($role.Role)" $logfile
            $login = $server.Logins | Where-Object {$_.Name.ToUpper() -eq $role.Member.ToUpper()}
            try{
                $login.AddToRole($role.Role)
                $login.Alter()
                LogMessage "$servername :: Added Member $($role.Member) to Role $($role.Role)" $logfile
            }
            catch{
                LogMessage "$servername :: Failed to add Member $($role.Member) to Role $($role.Role) :: $($_.Exception.Message)" $logfile
            }
        }
    }
}

    
    