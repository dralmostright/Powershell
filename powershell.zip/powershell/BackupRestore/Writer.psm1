﻿Function LogMessage{
    param($msg, $outfile)
    $now = get-date -format "yyyy-MM-dd HH:mm:ss"
    Write-Verbose "$now :: $msg" -Verbose
    echo "$now :: $msg" | Out-File -Append $outfile
}

Function DisplayMessage{
    param($msg)
    $now = get-date -format "yyyy-MM-dd HH:mm:ss"
    Write-Verbose "$now :: $msg" -Verbose
}