﻿
$serverlist = @(

'nvei1adbu10.uat1.ops.global.ad',
'NVEI1RDBU3.uat1.ops.global.ad'

)
$dict = @{}



$dict.set_item('nvei1adbu10.uat1.ops.global.ad',  'nvei1adbu1.uat1.ops.global.ad')
$dict.set_item('NVEI1RDBU3.uat1.ops.global.ad',  'NVEI1RDBU3-n.uat1.ops.global.ad')

$sysDB = @('master', 'msdb', 'model', 'tempdb', 'distribution')
#$sysDB = @('tempdb')


[System.Reflection.Assembly]::LoadwithpartialName('Microsoft.SqlServer.Smo') | Out-Null

$centralserver = New-Object 'Microsoft.SqlServer.Management.Smo.Server' 'NVEIDBBACKUPP1'
$centralDB = $centralserver.Databases.Item('REPORT')

foreach($servername in $serverlist){
    $sqlserver = New-Object 'Microsoft.SqlServer.Management.Smo.Server' $servername
    $i = 0
    echo $sqlserver.Name
    foreach($db in $sqlserver.Databases){
        
        if($sysDB -icontains $db.Name){ continue }
        if($db.Status -ieq 'Offline'){ continue }

         #Get DataDir and LogDir
        $masterfile = $($db.FileGroups.Files.FileName) | where-object { $_.ToLower().endswith('.mdf') } | select -First 1
        $DataDir = $masterfile.Substring(0,$masterfile.LastIndexOf('\'))
        $logfile = $($db.LogFiles.FileName) | where-object { $_.ToLower().endswith('.ldf') }
        $logDir = $logfile.Substring(0,$logfile.LastIndexOf('\'))

        #if($RequiredDB -icontains $db.Name){
        $query = "insert into dbo.BackupRestore(Servername, RestoreServerName, DatabaseName, Status, DataDir, LogDir, DOP) values('$servername','$($dict.get_item($servername))','$($db.Name)', 0, '$($DataDir)', '$($LogDir)', 1)"
        echo $query
        #$centralDB.ExecuteNonQuery($query)
        #}
    }
}