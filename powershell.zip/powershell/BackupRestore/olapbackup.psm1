﻿function ExecBackupRestore{
    param($CentralServerName, $servername, $serverlog, $backupDir)

    [System.Reflection.Assembly]::LoadwithpartialName('Microsoft.SqlServer.Smo') | Out-Null
    [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.AnalysisServices") | Out-Null

    $centralserver = New-Object 'Microsoft.SqlServer.Management.Smo.Server' $CentralServerName
    $centralserver.ConnectionContext.StatementTimeout = 0
    $centralDB = $centralserver.Databases.Item('REPORT')
    
    while(1){
        $jobQuery = "Select Top 1 * from dbo.OLAPBackupRestore where ServerName = '$servername' and Status = 0"
        $QueryResult = $centralDB.ExecuteWithResults($jobQuery)
        if($QueryResult.Tables[0].Rows.Count -eq 0){
            LogMessage "$servername :: No Jobs in Queue" $serverlog
            break
        }

        $backupJob = $QueryResult.Tables[0].Rows[0]
        $jobID = $backupJob.JobID
        $DatabaseName = $backupJob.DatabaseName

        # Update the table indicating backup started
        $centralDB.ExecuteNonQuery("Update dbo.OLAPBackupRestore set Status = 1 where JobID = $jobID")
        LogMessage "$servername :: Backup Started for db $DatabaseName" $serverlog
        try{
            #Server Connection
            $SSASServer = New-Object Microsoft.AnalysisServices.Server
            $SSASServer.connect($servername)
            $db = $SSASServer.Databases.FindByName($DatabaseName)

            #Get DataDir
            if($db.DbStorageLocation -ne $null){
                $DataDir = $db.DbStorageLocation
                if($DataDir.StartsWith("\\?\")){
                    $DataDir = $DataDir.replace("\\?\","")
                }
            }
            else{
                $DataDir = $($SSASServer.ServerProperties | Where-object {$_.Name -eq "DataDir"}).Value
            }

            #Check if partition exists
            $partFolders = @()
            foreach($cube in $db.Cubes){
                foreach($mg in $cube.MeasureGroups){
                    foreach($part in $mg.Partitions){
                        if($part.StorageLocation -ne $null){
                            #echo "$($cube.Name) == $($mg.Name) == $($part.Name)"
                            if($partFolders -notcontains $part.StorageLocation){
                                $partFolders += $part.StorageLocation
                            }
                        }
                    }
                }
            }

            if($partFolders.Length -gt 0){
                $partDir = "'$($partFolders[0])'"
            }else{
                $partDir = 'null'
            }

            
            #Creating Backup Directory if doesnot exists
            $bkpLocation = "$($backupDir)\$($servername)\$($DatabaseName)"
            New-Item -ItemType directory -Path $bkpLocation -Force | Out-Null

            #Configure Backup Parameters
            [Microsoft.AnalysisServices.BackupInfo]$olapBackup = New-Object([Microsoft.AnalysisServices.BackupInfo])
            $olapBackup.AllowOverwrite = 1
            $olapBackup.ApplyCompression = 1
            $olapBackup.BackupRemotePartitions = 1
            $olapBackup.file = "$($bkpLocation)\$($db.Name).abf"

            # Execute Backup
            $db.Backup($olapBackup)
            
            #Update Table on completion of backup
            $centralDB.ExecuteNonQuery("Update dbo.OLAPBackupRestore set Status = 2, BackupDir = '$bkpLocation' where JobID = $jobID")
            LogMessage "$servername :: Backup Completed for db $DatabaseName" $serverlog


        }catch{
            $ErrMsg = "$($_.Exception.Message.Replace("'", " "))"
            $centralDB.ExecuteNonQuery("Update dbo.OLAPBackupRestore set Status = 100, Remarks ='$ErrMsg' where JobID = $jobID")
            LogMessage "$servername :: Backup Failed for db $DatabaseName" $serverlog
        }

    }
    
    #Close central server
    $centralserver.ConnectionContext.Disconnect() 

}