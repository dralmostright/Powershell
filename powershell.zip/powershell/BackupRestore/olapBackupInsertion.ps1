﻿$serverlist = @(

'NVEI1ODBU3.uat1.ops.global.ad'

)
$dict = @{}




$dict.set_item('NVEI1ODBU3.uat1.ops.global.ad',  'NVEI1ODBU3-n.uat1.ops.global.ad')



#$requiredDB =@('WillisMed - Production')#,'WillisMed Proofing Agg', 'Enterprise Intelligence Demo - Standard', 'Enterprise Intelligence Demo - Health Management', 'Commercial Norm')

[System.Reflection.Assembly]::LoadwithpartialName('Microsoft.SqlServer.Smo') | Out-Null
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.AnalysisServices") | Out-Null

$centralserver = New-Object 'Microsoft.SqlServer.Management.Smo.Server' '10.48.2.85'
$centralDB = $centralserver.Databases.Item('REPORT')
foreach($servername in $serverlist){
    $SSASServer = New-Object Microsoft.AnalysisServices.Server
    $SSASServer.connect($servername)
    $i=0
    foreach($db in $SSASServer.Databases){
    #if($requiredDB -icontains $db.Name){
         
        #Get DataDir
        if($db.DbStorageLocation -ne $null){
            $DataDir = $db.DbStorageLocation
            if($DataDir.StartsWith("\\?\")){
                $DataDir = $DataDir.replace("\\?\","")
            }
        }
        else{
            $DataDir = $($SSASServer.ServerProperties | Where-object {$_.Name -eq "DataDir"}).Value
        }

        #Check if partition exists
        $partFolders = @()
        foreach($cube in $db.Cubes){
            foreach($mg in $cube.MeasureGroups){
                foreach($part in $mg.Partitions){
                    if($part.StorageLocation -ne $null){
                        #echo "$($cube.Name) == $($mg.Name) == $($part.Name)"
                        if($partFolders -notcontains $part.StorageLocation){
                            $partFolders += $part.StorageLocation
                        }
                    }
                }
            }
        }

        if($partFolders.Length -gt 0){
            $partDir = "'$($partFolders[0])'"
        }else{
            $partDir = 'null'
        }

        $query = "insert into dbo.OLAPBackupRestore(Servername, RestoreServerName, DatabaseName, Status, DataDir, PartDir) values('$servername','$($dict.get_item($servername))','$($db.Name)', 0, '$($DataDir)', $($partDir))"
        echo $query
        #$centralDB.ExecuteNonQuery($query)
        }
    #}
}