﻿Import-Module "$($PSScriptRoot)\Writer.psm1"
Import-Module "$($PSScriptRoot)\rdmbackup.psm1"
Import-Module "$($PSScriptRoot)\ThreadHelper.psm1"

$centralservername = 'NVEIDBBACKUPP1'
$centralDBName = 'REPORT'
$BackupDir = '\\10.144.158.80\oraBackupDM02MI\EI_Backup\MSSQL'
$serverlist = @(
#'NVEIPROCRDB01',
#'NVEIPROCRDB02'
#'NVEIPROCRDB03',
'NVEIPROCRDB04'
)

### Create Directory for Log
New-Item -ItemType directory -Path "$BackupDir\Log" -Force | out-null

[System.Reflection.Assembly]::LoadwithpartialName('Microsoft.SqlServer.Smo') | Out-Null

$MaxThreads = $serverlist.Count
$ISS = [system.management.automation.runspaces.initialsessionstate]::CreateDefault()
$ISS.ImportPSModule("$($PSScriptRoot)\rdmbackup.psm1")
$ISS.ImportPSModule("$($PSScriptRoot)\Writer.psm1")
$RunspacePool = [runspacefactory]::CreateRunspacePool(1, $MaxThreads, $ISS, $Host)
$RunspacePool.Open() | Out-Null

$jobs=@()

### Execute PreRecord in threads
$jobs = ThreadInitiate $RunspacePool $CentralServerName $serverlist $BackupDir
ThreadStatus $jobs
$Errorlist = ThreadCleanup $jobs
echo $Errorlist

$RunspacePool.Close()

