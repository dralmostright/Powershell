﻿########################################################################################################################
# Filename	: SSRS_SetDataSources.ps1
# Created by	: Pawan K Shrestha
# Created on	: 2017-06-08
# 
# This script will update datasource for reports from a csv file 
########################################################################################################################
#param($path, $servername, $password)
$path='\\kvmsqldb\kvmsqldb'
$servername = 'dbawincluster1'

Function TrueFalse{
    param($string)
    if($string -ieq "true"){
        return $true
    }else{
        return $false
    }
}



$inputCSVFile=$path+"\SSRS_DataSources_Updated.csv"
$ReportServerUri = 'http://'+$servername+'/ReportServer/ReportService2010.asmx?wsdl'
$myPwd='P@ssw0rd'#$password#[DBADM_PASSWORD]


Write-Host "Start reading datasources from csv file @" (Get-Date)
$RPTDataSources =Import-Csv $inputCSVFile
$InheritParent = $true
$rsProxy = New-WebServiceProxy -Uri $ReportServerUri -UseDefaultCredential
$type = $rsProxy.GetType().Namespace;
$policyType = "{0}.Policy" -f $type;
$roleType = "{0}.Role" -f $type;
$Errorlist = @()

Write-Host "Start setting datasources @" (Get-Date)

foreach ($RPTDS in $RPTDataSources){
	$myPath = $RPTDS.Path
	$myName = $RPTDS.Name
	$myConnectString=$RPTDS.ConnectString
	$myCredentialRetrieval=$RPTDS.CredentialRetrieval
	$myUserName=$RPTDS.UserName
	$myPassword=$RPTDS.Password
	$myUseOriginalConnectString=$RPTDS.UseOriginalConnectString
    $myOriginalConnectStringExpressionBased = $RPTDS.OriginalConnectStringExpressionBased

    if($RPTDS.TypeName -ieq "DataSource"){
        $dsinfo = $rsProxy.GetDataSourceContents($myPath)
        $dsinfo.ConnectString=$myConnectString
        $dsinfo.CredentialRetrieval = $myCredentialRetrieval
        $dsinfo.UseOriginalConnectString = TrueFalse $myUseOriginalConnectString
        #$dsinfo.OriginalConnectStringExpressionBased = TrueFalse $myOriginalConnectStringExpressionBased
        
        <#
        if($myCredentialRetrieval -ieq "Store"){
            $dsinfo.UserName = $myUserName
            $dsinfo.Password = $myPwd
        }
        #>
        try{
			$rsProxy.SetDataSourceContents($myPath, $dsinfo)
			Write-Host "Success: datasource info updated in [" $myName "] for [" $myPath "]@" (Get-Date)
		}
		catch{
			Write-Host "Error: datasource info updated in [" $myName "] for [" $myPath "]@" (Get-Date)
            $Errorlist += "$myName :: $myPath :: $($_.Exception.Message)"
		}
    }
    else{
	    $dataSources = $rsProxy.GetItemDataSources($myPath)	

	    foreach($ds in $dataSources){             
		    if($ds.Name -eq $myName){        
			    $dsChangeMsg=""
			    $ds.Item.ConnectString=$myConnectString
                $ds.Item.CredentialRetrieval=$myCredentialRetrieval
                
                if($myCredentialRetrieval -ieq "Store"){
			        $ds.Item.Password=$myPwd
			        $ds.Item.UserName=$myUserName
                }
                
    		    $ds.Item.UseOriginalConnectString= TrueFalse $myUseOriginalConnectString
			    try{
                    echo $ds.Item.ConnectString
				    $rsProxy.SetItemDataSources($myPath, $ds)
				    Write-Host "Success: datasource info updated in [" $myName "] for [" $myPath "]@" (Get-Date)
			    }
			    catch{
				    Write-Host "Error: datasource info updated in [" $myName "] for [" $myPath "]@" (Get-Date)
                    $Errorlist += "$myName :: $myPath :: $($_.Exception.Message)"
			    }
		    }
	    }
    }        
}

Write-Host "Completed setting datasources @" (Get-Date)
if($Errorlist.Count -gt 0){
    Write-Host "Error Summary:"
    foreach($err in $Errorlist){
        Write-Host "`t`t $err"
    }
}