﻿[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null

$serverlist = @(
"NVEIDBBACKUPP1"
)

#$servername = 'nveidbbackupp1'

foreach($servername in $serverlist){
    echo "Updating operators in $servername"
    $sqlserver = new-object "Microsoft.SqlServer.Management.Smo.Server" $servername
    foreach($dbaOp in $sqlserver.JobServer.Operators ){
        if($dbaOp.Name -ieq 'SQLDBA' -or $dbaOp.Name -ieq 'RIC-Devops'){ continue; }
        echo "Operator $($dbaOp.Name)"
        $vemail = $dbaOp.EmailAddress
        $cemail = $vemail.replace('verscend', 'cotiviti')
        $dbaOp.EmailAddress = $cemail
        $dbaOp.Alter()
    }

    
}





