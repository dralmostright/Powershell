﻿#param($servername, $path, $type, $olddomain, $newdomain)

$servername = 'NVEI2ADBU01'
$path = '\\npeibackupp1\Adhoc_Backup\Projects\MSSQL_Audit\Cleanup_backup'
$type = 'pre'

Function ListUser{
    param($servername, $csvfile)
    $userArray = @()
    [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null
    $server = New-Object Microsoft.SqlServer.Management.Smo.Server $servername
    
    $logins = $server.Logins
    #$logins | get-member
    foreach($login in $logins){
        $userResult = New-Object PSObject -Property @{
            "USerType" = "Login";
            "Database" = "None";
            "Username" = $login.Name;
            "LoginType" = $login.LoginType;
        } 
        $userArray += $userResult
    }

    $dbs = $server.Databases
    foreach($db in $dbs){
        foreach($user in $db.Users){
            $userResult = New-Object PSObject -Property @{
                "USerType" = "DBUser";
                "Database" = $db.Name;
                "Username" = $user.Name;
                "LoginType" = $user.LoginType;
            } 
            $userArray += $userResult
        }
    }

    $userArray | sort -Property Username,UserType,Database | Export-Csv -path $csvfile -NoTypeInformation
}

Function ListRole{
    param($servername, $csvfile)
    $roleArray = @()
    [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null
    $server = New-Object Microsoft.SqlServer.Management.Smo.Server $servername

    #Add the members of server roles
    $serverRoles = $server.Roles
    foreach($role in $serverRoles){
        $role.EnumServerRoleMembers() | foreach{
            $roleResult =  New-object PSObject -Property @{
                "Database" = "None";
                "Role" = $role.Name;
                "Member" = $_;
            }
            $roleArray += $roleResult
        }
    }

     #Add the members of database roles
    $dbs = $server.Databases
    foreach($db in $dbs){
        $dbRoles = $db.Roles
        foreach($role in $dbRoles){
            $role.EnumMembers() | foreach{
                $roleResult =  New-object PSObject -Property @{
                    "Database" = $db.Name;
                    "Role" = $role.Name;
                    "Member" = $_;
                }
                $roleArray += $roleResult
            }
        }
    }

    $roleArray | Export-Csv -path $csvfile -NoTypeInformation
}


Function CreateUser{
    param($server, $user, [ref]$Errorlist)
    
    if($user.UserType -eq "Login"){
        echo "Adding Login $($user.username)"
        $login = New-Object Microsoft.SqlServer.Management.Smo.Login -ArgumentList $server, $user.Username
        $login.LoginType = $user.LoginType
        try{
            $login.Create()
            echo "Added Login $($user.Username)"
        }catch{
            echo "Failed to add Login $($user.Username)"
            $Errorlist.Value += "Failed to Add Login $($user.Username) $($_.Exception.Message)"
        }
    }

    if($user.userType -eq "DBUser"){
        echo "Adding User $($user.Username) in database $($user.Database)"
        $db = $server.Databases | Where-Object {$_.Name -eq $user.Database}
        $DBuser = New-object Microsoft.SqlServer.Management.Smo.User($db, $user.Username)
        $DBuser.Login = $user.Username
        try{
            $DBuser.Create()
            echo "Added User $($user.Username) in database $($user.Database)"
        }catch{
            echo "Failed to add User $($user.Username) in database $($user.Database)"
            $Errorlist.value += "Failed to Add user $($user.name) in $($user.Database) $($_.Exception.Message)"
        }
    }
}

Function CreateRole{
    param($server, $role, [ref]$Errorlist)

    if($role.Database -eq "None"){
        echo "Adding Member $($role.Member) to Role $($role.Role)"
        $login = $server.Logins | Where-Object {$_.Name.ToUpper() -eq $role.Member.ToUpper()}
        try{
            $login.AddToRole($role.Role)
            $login.Alter()
            echo "Added Member $($role.Member) to Role $($role.Role)"
        }
        catch{
            echo "Failed to add Member $($role.Member) to Role $($role.Role)"
            $Errorlist.Value += "Failed to Add Member $($role.Member) to role $($role.Role) $($_.Exception.Message)"
        }
    }
    else{
        echo "Adding Member $($role.Member) to Role $($role.Role) in db $($role.Database)"
        $db = $server.Databases | Where-Object {$_.Name -eq $role.Database}
        $DBuser = $db.Users | Where-Object {$_.Name.ToUpper() -eq $role.Member.ToUpper()}
        try{
            $DBuser.AddToRole($role.Role)
            $DBUser.Alter()
            echo "Added Member $($role.Member) to Role $($role.Role) in db $($role.Database)"
        }catch{
            echo "Failed to add Member $($role.Member) to Role $($role.Role) in db $($role.Database)"
            $Errorlist.Value += "Failed to Add Member $($role.Member) to role $($role.Role) in db $($role.Database) $($_.Exception.Message)"
        }
    }
}

$usercsvfile = $path + '\'+$servername+'_RdmUsers.csv'
$rolecsvfile = $path + '\'+$servername+'_RdmRoles.csv'
$Errorlist = @()
if($type -eq "pre"){
    ListUser $servername $usercsvfile
    ListRole $servername $rolecsvfile
}
if($type -eq "post"){
    #replace the domains in csvfiles
    $(Get-Content $usercsvfile) -iReplace $olddomain, $newdomain | Set-Content $usercsvfile
    $(Get-Content $rolecsvfile) -iReplace $olddomain, $newdomain | Set-Content $rolecsvfile

    
    [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null
    $server = New-Object Microsoft.SqlServer.Management.Smo.Server $servername

    $userArray = Import-csv -path $usercsvfile
    $userArray = $userArray | Where-object {$_.Username.ToUpper().StartsWith($newdomain.ToUpper()) }
    foreach($user in $userArray){
        CreateUser $server $user ([ref]$Errorlist)
    }

    $roleArray = Import-csv -path $rolecsvfile
    $roleArray = $roleArray | Where-object {$_.Member.ToUpper().StartsWith($newdomain.ToUpper()) }
    foreach($role in $roleArray){
        CreateRole $server $role ([ref]$Errorlist)
    }
    if($Errorlist.Count -gt 0){
        echo "Error Summary:"
        foreach($err in $Errorlist){
            echo "`t`t $err"
        }
    }
    
    
}
