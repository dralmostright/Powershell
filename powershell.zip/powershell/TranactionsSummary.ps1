﻿$servers= @('NPEIRDBP1','NPEIRDBP2','NPEIRDBP3','NPEIRDBP8','NVEIRDBP1','NVEIRDBP2','NVEIRDBP8','NVEIHOSTRDBP99','NVEIADBP02', 'NVEIRDBPC2', 'NVEIRDBPC3'
            'NVEIRDBPC6', 'NVEIPROCRDB01', 'NVEIPROCRDB02', 'NVEIPROCRDB03', 'NVEIPROCRDB04', 'NVEISVCQCP1', 'NVEISVCQCP2', 'NPEIBACKUPP1')

$serverDetails = @()

foreach($servername in $servers){
    $dbname = "MASTER"
    $connectionstring = "Server=$servername; uid=$username; pwd=$password; Database=$dbname; Integrated Security=True;"
    $connection = new-object System.Data.SqlClient.SqlConnection
    $connection.ConnectionString = $connectionstring
    $connection.open()
    $command = new-object System.Data.Sqlclient.Sqlcommand
    $command.connection = $connection
    #insert and update may take several minutes and sqlcommand may get timedout so ->
    $command.CommandTimeout = 0
    $command.CommandText="IF OBJECT_ID('tempdb..#transactions') IS NOT NULL
    DROP TABLE #transactions;

IF OBJECT_ID('tempdb..#DBSizes') IS NOT NULL
    DROP TABLE #DBSizes;

/************************************************************/
/******* SQL Server Transactions Per Day / Hour / Min *******/
/************************************************************/
DECLARE @Days SMALLINT,
        @Hours INT,
        @Minutes BIGINT,
        @Restarted_Date DATETIME;

/*** Capture the SQL Server instance last restart date ***/
/*** We will get the Tempdb creation date ***/
SELECT @Days = DATEDIFF(D, create_date, GETDATE()),
       @Restarted_Date = create_date
FROM sys.databases
WHERE database_id = 2;

/*** Prepare Number of Days and Hours Since the last SQL Server restart ***/
SELECT @Days = CASE
                   WHEN @Days = 0 THEN
                       1
                   ELSE
                       @Days
               END;
SELECT @Hours = @Days * 24;
SELECT @Minutes = @Hours * 60;

CREATE TABLE #Transactions
(
    Instance_Name VARCHAR(100),
    TransactionsByDay BIGINT
);
CREATE TABLE #DBSizes
(
    Server VARCHAR(20),
    Name VARCHAR(200),
    Size BIGINT
);


/*** Retrieve the total transactions occurred in SQL Server Instance since last restart ***/
INSERT INTO #Transactions
SELECT @@SERVERNAME AS 'Instance_Name',
       cntr_value / @Days AS 'TransPerDay'
FROM sys.dm_os_performance_counters
WHERE counter_name = 'Transactions/sec'
      AND Instance_Name = '_Total';


INSERT INTO #DBSizes
EXEC sp_MSforeachdb @command1 = 'use ?; SELECT @@ServerName server, name, size FROM sys.database_files;';

SELECT t.Instance_Name,
       CONVERT(DECIMAL(15, 0), FileSizeInGB) AS Volume,
       tr.TransactionsByDay
FROM
(
    SELECT Server Instance_Name,
           SUM(Size / 128.0) / 1024 FileSizeInGB
    FROM #DBSizes
    GROUP BY Server
) t
    INNER JOIN #Transactions tr
        ON t.Instance_Name = tr.Instance_Name
ORDER BY Instance_Name ASC;"

    $result = $command.ExecuteReader()
    $table = New-Object System.Data.DataTable
    $table.load($result)
    $result.close()
     [array]$tResult = New-Object PSObject -Property @{
                "Instance_Name" = $table.Instance_Name;
                "Volume" = $table.Volume;
                "TransactionsByDay" = $table.TransactionsByDay
            }
    $serverDetails += $tResult
}

echo $serverDetails | select Instance_Name, Volume, TransactionsByDay | Out-File C:\temp\TransactionsDetails_prod.txt