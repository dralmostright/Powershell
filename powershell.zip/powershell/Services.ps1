﻿param($serverid_list, $mode="stop")

function GetServerList{
    param($serverid_list)
    [int[]]$serverid = @()
    $servername = @()
    try{
    Import-csv $serverfile | ForEach-Object{
    $serverid += $_.serverid
    $servername += $_.server
    }
    }
    catch{
    echo "Couldnot open $serverfile. Make sure it exists."
    }
    $serverlist = @()
    if($serverid_list -eq 'all')
    {
        $serverlist = $servername
    }
    else
    {
        foreach($id in $serverid_list)
        {
            if($serverid -contains $id)
            {
                $index = [array]::indexof($serverid,$id)
                $serverlist += $servername[$index]
            }
            else
            {
                echo "The serverID $id doesnot exists."
                exit
            }
        }
    }
    return $serverlist
}



#main execution
$serverfile = 'C:\MSSQL\scripts\powershell\serverlist.csv'
$errorfile = 'C:\MSSQL\scripts\powershell\Service_error.txt'
#$serverlist = GetServerList $serverid_list
$serverlist=@("nveiodp1")
$services = ('MSSQLSERVER', 'MSSQLSERVEROLAPSERVICE')
if($mode -eq "stop")
{
foreach($server in $serverlist){
    foreach($service in $services){
        try{
            #$service.DependentServices.count
            $check = Get-Service -ComputerName $server -ErrorAction stop
            try{
            $status = $(Get-Service -ComputerName $server -Name $service -ErrorAction stop).status
            if($status -ne "Stopped"){
            try{
            Get-Service -ComputerName $server -Name $service | Stop-Service -Force
            echo "$server  $service status - Stopped"
            }
            catch{
            $now = get-date -format "yyyy/MM/dd hh:mm:ss"
            echo "$server : Could not stop $service because it has dependent services. $now" | Tee-Object -filepath $errorfile -append
            }
            }
            else{
            echo "$server $service already in Stopped mode"
            }
            }
            catch{
            $now = get-date -format "yyyy/MM/dd hh:mm:ss"
            echo "$server : $service is unavailabe $now" | Tee-Object -filepath $errorfile -append
            }
        }
        catch{
        $now = get-date -format "yyyy/MM/dd hh:mm:ss"
        echo "$server : Could Access $service. Error may be due to Privilage issue or unavailable server $now" | Tee-Object -filepath $errorfile -append
        }
    }
}
}
elseif($mode -eq "start")
{
foreach($server in $serverlist){
    foreach($service in $services){
        try{
            #$service.DependentServices.count
            $status = $(Get-Service -ComputerName $server -Name $service -ErrorAction stop).status
            if($status -ne "Running"){
            try{
            Get-Service -ComputerName $server -Name $service | Start-Service
            echo "$server  $service status - Running"
            }
            catch{
            $now = get-date -format "yyyy/MM/dd hh:mm:ss"
            echo "$server : Could not start $service $now" | Tee-Object -filepath $errorfile -append
            }
            }
            else{
            echo "$server $service already in Running mode"
            }
        }
        catch{
        $now = get-date -format "yyyy/MM/dd hh:mm:ss"
        echo "$server : Could Access $service. Error may be due to Privilege issue or unavailable service $now" | Tee-Object -filepath $errorfile -append
        }
    }
}
}
else
{
echo "Invalid Arguments"
}