﻿<#
.SYNOPSIS
  Nagios downtime scheduler
.DESCRIPTION
  <Brief description of script>
.PARAMETER StartTime
    Downtime start date/time in format YYYY-MM-DD HH24:mm:ss
.PARAMETER TargetHosts
    Comma-separated list of machines. Short hostname should be used.
.PARAMETER TargetClusters
    Comma-separated list of clusters (based on BatmanAPI). Do not specify if TargetHosts is already specified.
.PARAMETER TargetEnv
    Enviornment name (based on BatmanAPI). Do not specify if TargetHosts is already specified. Use this along with TargetClusters
.PARAMETER Minutes
    Downtime duration in minutes
.PARAMETER TestMode
    Runs in test mode
.NOTES
  Version:        1.0
  Author:         Nihir J. Patel
  Creation Date:  12/02/2016
  Purpose/Change: Nagios alert manager - initial version allows schedule downtime. Server list from BatmanAPI based on $myEnv

  Version:        1.1
  Author:         Rupendra Chulyadyo
  Creation Date:  04/21/2017
  Purpose/Change: Parameterized inputs to avoid script edit before each run

	Version:        1.2
  Author:        	Sajal N. Shrestha
  Creation Date:  11/30/2017
  Purpose/Change: Added function to convert the local time to EST

.EXAMPLE
  .\Nagios-API.ps1 -TargetEnv EIUAT -TargetClusters EISVCSA,EISVCSB -StartTime "2017-04-21 10:11:10" -Minutes 30
  .\Nagios-API.ps1 -TargetHosts NVEISVCSAU1,NVEISVCSAU2 -StartTime "2017-04-21 10:11:10" -Minutes 30
  .\Nagios-API.ps1 -TargetEnv EIUAT -TargetClusters EISVCSA,EISVCSB -StartTime "2017-04-21 10:11:10" -Minutes 30 -TestMode
  .\Nagios-API.ps1 -TargetHosts NVEISVCSAU1,NVEISVCSAU2 -StartTime "2017-04-21 10:11:10" -Minutes 30  -TestMode
#>

[cmdletbinding(
	DefaultParameterSetName='hosts'
)]
Param(
    [Parameter(Position=0, Mandatory=$true, HelpMessage='Enter downtime start date/time in format YYYY-MM-DD HH24:mm:ss')]
    [String]$StartTime,

    [Parameter(ParameterSetName='hosts', Mandatory=$true, HelpMessage='Enter list of host names separated by comma')]
    [array]$TargetHosts,

    [Parameter(ParameterSetName='clusters', Mandatory=$true, HelpMessage='Enter list of cluster names separated by comma')]
    [array]$TargetClusters,

	[Parameter(ParameterSetName='clusters', Mandatory=$true, HelpMessage='Enter the environment name')]
    [String]$TargetEnv,

    [Parameter(Mandatory=$true, HelpMessage='Enter downtime duration in minutes')]
    [int]$Minutes,

    [Parameter(Mandatory=$false, HelpMessage='Switch to run this in test mode')]
    [switch]$TestMode
)

function Convert-To-EST {
	Param(
		[Parameter(Mandatory=$true)]
		[ValidateNotNullOrEmpty()]
		[datetime]$Time

    )
  $formatTime = Get-Date -Date $Time -Format "yyyy-MM-dd HH:mm:ss"

  $fromTimeZone = [System.TimeZoneInfo]::Local
  $toTimeZone = [System.TimeZoneInfo]::FindSystemTimeZoneById("Eastern Standard Time")
  $UTC = [System.TimeZoneInfo]::ConvertTimeToUtc($formatTime, $fromTimeZone)
  $newTime = [System.TimeZoneInfo]::ConvertTime($UTC, $toTimeZone)
  return $newTime
}

function Get-MachinesInEnvironment {
    param (
           [Parameter(Mandatory = $true)][String]$Environment,
		   [Parameter(Mandatory = $false)][String]$Cluster,
		   [Parameter(Mandatory = $false)][switch]$IncludeActiveOnly
    )
	$Get = ""
	if($Cluster){  $Get = "?Cluster=$Cluster" }
	if ($IncludeActiveOnly) {
		if($Get) { $Get = $Get+"&Status=Active"  }
		else { $Get = "Status=Active"  }
	}

    $URL = "$($SCRIPT:API)/environments/$($Environment)/machines"+$Get
    Write-Host "Getting machines from $URL"
    [XML]$xml = Get-HttpRequest $URL
    return $xml
}

function Get-HttpRequest([string]$URL)
{
		$request = [System.Net.WebRequest]::Create($URL)
        $request.Proxy = $request.DefaultWebProxy
		$request.Credentials = [System.Net.CredentialCache]::DefaultCredentials
		$request.UseDefaultCredentials = "True"
		$request.UserAgent = "Nagios Downtime Scheduler"
		$request.Method = "GET"
		$request.Accept = "application/xml"

		$response = $request.GetResponse()
        $requestStream = $response.GetResponseStream()
		$readStream = new-object System.IO.StreamReader $requestStream

    new-variable db
    $db = $readStream.ReadToEnd()
    $readStream.Close()
    $response.Close()
    return ,[xml]$db
}

function ScheduleDowntime([string]$machine, [string]$start, [string]$end)
{
	$cgiurl="/cgi-bin/cmd.cgi"
    $uri = $url + $cgiurl
    echo $uri

	$action = 55 # schedule downtime for a particular host
	#$machine = ""
	$comment = "Scheduled downtime via PowerShell by $($Script:UserName) on $($Script:ComputerName)"
	#$start = (Get-Date -Format "MM-dd-yyyy HH:mm:ss")
	#$end =((Get-Date).AddMinutes(2).ToString("MM-dd-yyyy HH:mm:ss"))

	#Write-Host "DEBUG: URL: $($uri) - FormFields:"
	$formFields = @{cmd_typ=$action;cmd_mod=2;host=$machine;com_data=$comment;trigger=0;start_time=$start;end_time=$end;fixed=1;hours=2;minutes=0;btnSubmit="Commit"}
	#$formFields

	Write-Host "###########################################################################"
	if(-not $TestMode)
	{
		Write-Host "Submitting cgi command to Nagios for $machine"
		#$WebRequest = Invoke-WebRequest -Uri $uri -Credential $Credential -Body $formFields -Method POST -ContentType 'application/x-www-form-urlencoded'
        $WebRequest = Invoke-WebRequest -Uri $uri -Credential $Credential -Body $formFields -Method POST -ContentType 'application/x-www-form-urlencoded'

		# If there was a problem with the hostname or other problem the errorMessage DIV field will be displayed. If not display the infoMessage of success.
		$Message = $WebRequest.ParsedHtml.getElementsByTagName("div") | Where-Object "classname" -Match "errorMessage|infoMessage" | select -ExpandProperty innerText
		if ($Message) {
		    $Message
		    }
		Write-Host "###########################################################################"
	}
	else
	{
		Write-Host "###########################################################################"
		Write-Host "Test mode (change TestMode to false if you don't want to run it in test mode" -ForegroundColor:Magenta
		$formFields
		Write-Host "###########################################################################"
	}
}

$Error.Clear()
Clear-Host

Write-host "Input parameters"
Write-host "----------------------------------"
ForEach($Key in $PSBoundParameters.Keys){
   $Key +": "+ $PSBoundParameters[$Key]
}

Write-host " "
try {
  $SelectedParameterSet = $PSCmdlet.ParameterSetName
}
catch {
 Write-host "Invalid arguments. "
 Exit
}


Write-host "Processing the request"
Write-host "----------------------------------"

$dateTime = try{ [DateTime]::ParseExact($StartTime,'yyyy-MM-dd HH:mm:ss',$null)  } catch{}
if(-Not $dateTime)  {
	Write-Host "Invalid start time. Should be of format YYYY-MM-DD HH24:mm:ss"
	Exit
}
$estDateTime = Convert-To-EST -Time $dateTime
$start = Get-Date -Date $estDateTime -Format "MM-dd-yyyy HH:mm:ss"
$end = Get-Date -Date ($estDateTime.AddMinutes($Minutes)) -Format "MM-dd-yyyy HH:mm:ss"


$Script:API = "https://env.verscend.com/BatmanAPI"
$url = "http://nvnagiosp2.d2hawkeye.net/nagios"
$action = 55 # scheduled downtime for a host
$NagiosUsername = "nagiosadmin"
$NagiosPassword = $NagiosUsername

# do not touch section
$Message = ""
$securepassword = ConvertTo-SecureString -String $NagiosPassword -AsPlainText -Force
$Credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $NagiosUsername,$securepassword
$Script:ComputerName = $Env:COMPUTERNAME
$Script:UserName = $Env:USERNAME
# do not touch section

$servers = @()
# If clusters are specified
if($SelectedParameterSet -like "clusters*"){
	foreach ($TargetCluster in $TargetClusters)
	{
		$ServersXML = Get-MachinesInEnvironment -Environment $TargetEnv -Cluster $TargetCluster -IncludeActiveOnly
		if(-Not $ServersXML){
			Write-Host "Failed to get machine list from Batman API"
		}
		else {
			$Machines = @($ServersXML.Machines.Machine) | sort -Property Cluster,Name
			if($Machines.Count -eq 0){
			  Write-Host "No machines found for the cluster $TargetCluster in environment $TargetEnv"
			}

			foreach ($Machine in $Machines)
			{
					$Servers += $Machine.Name.ToUpper().ToString()
			}
		}
	}
	Write-Host "Completed getting machine list."
}
# If individiual hosts are specified
else {
	foreach ($TargetHost in $TargetHosts)
	{
	        $Servers += $TargetHost
	}
}

Write-Host " "
Write-Host "Downtime window from $start to $end will be scheduled for following machines:"
ForEach($server in $Servers){
   Write-Host  "`t $server"
}

Write-host " "
Write-host "Executing the request"
Write-host "----------------------------------"

ForEach($server in $Servers){
   ScheduleDowntime -machine "$($server.ToUpper().ToString())" -start "$start" -end "$end"
}

Write-host " "
Write-host "Completed the execution"
Write-host " "
