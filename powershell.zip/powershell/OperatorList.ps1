﻿[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null

$serverlist = @(
'NVEIDBBACKUPP1'
)

#$servername = 'nveidbbackupp1'
$Operatorlist = @()
$csvfile = "C:\temp\Operators.csv"

foreach($servername in $serverlist){
    $servername
    $sqlserver = new-object "Microsoft.SqlServer.Management.Smo.Server" $servername
    foreach($dbOp in $sqlserver.JobServer.Operators){
        $Operator_info = New-Object PSObject -Property @{
            "ServerName" = $servername;
            "Operator" = $dbOp.Name;
            "Email" = $dbOp.EmailAddress;
        } 
        $Operatorlist += $Operator_info
    }

}

$Operatorlist | select ServerName, Operator, Email | Export-Csv -Path $csvfile -NoTypeInformation 





