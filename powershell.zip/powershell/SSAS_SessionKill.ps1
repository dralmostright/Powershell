﻿[Reflection.Assembly]::LoadWithPartialName("Microsoft.AnalysisServices") | Out-Null

#connection string parameters
$centralservername = 'npeibackupp1'
$servers=@("NVEIODBP1","NVEIODBP2","NVEIODBP8","NPEIODBP2","NPEIODBP3","NPEIODBP5","NPEIODBP6","NPEIODBP8")
$currentuser = 'veriskhealth\i20466'
$outputdir = 'C:\Temp'
$job = 1 #1 to get session_id  2 to kill session_id and verify

$dbname = "master"
$FormatEnumerationLimit = -1
$debug=1
$global:msgCollection=""
function logMessage{
    if($debug -eq 1){
        write-host $args
    }
    $curVal=$msgCollection + "`n" + $args
    #Set-Variable -Name "msgCollection" -Value $curVal -Scope Global
    $global:msgCollection = $global:msgCollection + "`r`n" + $args
}

Function GetSessions($servername){
    $sessionlist = @()
    $query = 'select SESSION_ID, SESSION_SPID, SESSION_CONNECTION_ID, SESSION_USER_NAME from openquery('+$servername+', ''select * from $system.discover_sessions where session_user_name <> '''''+$currentuser+''''' '')'
    #$query = 'select SESSION_ID, SESSION_SPID, SESSION_CONNECTION_ID, SESSION_USER_NAME from openquery('+$servername+', ''select * from $system.discover_sessions '')'# where session_user_name <> '''''+$currentuser+''''' '')'
    $command.CommandText = $query;
    $result = $command.ExecuteReader();
    $session_table =  new-object System.Data.DataTable
    $session_table.Load($result)
    $result.close()
    foreach($row in $session_table){
        [array]$mysession = New-Object PSObject -Property @{
            "servername" = $servername
            "session_id" = $row.SESSION_ID
            "session_spid" = $row.SESSION_SPID
            "connection_id" = $row.SESSION_CONNECTION_ID
            "username" = $row.SESSION_USER_NAME
        }
        $sessionlist += $mysession
    }
    return $sessionlist
}

Function KillQuery($mysession){
    $query = '<Cancel xmlns="http://schemas.microsoft.com/analysisservices/2003/engine">
		        <ConnectionID>'+$mysession.connection_id+'</ConnectionID>
		        <SessionID>'+$mysession.session_id+'</SessionID>
		        <SPID>'+$mysession.session_spid+'</SPID>
		        <CancelAssociated>1</CancelAssociated>
	        </Cancel>'
    return $query
}

Function KillSessions($SSASServername, $sessionlist)
{
    LogMessage "Info |" (Get-Date) "| ---------------------------------------------------------------- " 
    LogMessage "Info |" (Get-Date) "| Started session kill for server $($SSASServerName)"
    LogMessage "Info |" (Get-Date) "| ---------------------------------------------------------------- " 
    $SSASServer = New-Object Microsoft.AnalysisServices.Server
    $SSASServer.Connect($SSASServerName)
    foreach($mysession in $sessionlist){
        echo $mysession.session_spid
        LogMessage "Info |" (Get-Date) "| Killing session for user $($mysession.username)"
        $killquery = KillQuery $mysession
        $result = $SSASServer.Execute($killQuery)
        if($result.Messages.Length -gt 0){
            LogMessage "Error|" (Get-Date) "| Failed session kill for user $($mysession.username) $($result.Messages.Description)"
        }
        else{
            LogMessage "Info |" (Get-Date) "| Killed session for user $($mysession.username)"
        }
    }
    LogMessage "Info |" (Get-Date) "| ---------------------------------------------------------------- " 
    LogMessage "Info |" (Get-Date) "| Completed session kill for server $($SSASServerName)"
    LogMessage "Info |" (Get-Date) "| ---------------------------------------------------------------- " 

}


$connectionstring = "Server=$central_servername; Database=$dbname; Integrated Security=True;"
$connection = new-object System.Data.SqlClient.SqlConnection
$connection.ConnectionString = $connectionstring
$connection.open()
$command = new-object System.Data.Sqlclient.Sqlcommand
$command.connection = $connection
#insert and update may take several minutes and sqlcommand may get timedout so ->
$command.CommandTimeout = 0

$serversessionlist = @()
if($job -eq 1){
    $SessionCSV = "$($outputdir)\sessions_$(get-date -format "dd_MM_yyyy_hhmmss").csv"
    foreach($myserver in $servers){
        $sessionlist = GetSessions $myserver  
        $serversessionlist += $sessionlist
        #$sessionlist
    }
    $serversessionlist | Select servername, username, session_id, session_spid, connection_id | Export-CSV -Path $SessionCSV -NoTypeInformation
}
if($job -eq 2){
    $outputfile = "$($outputdir)\SessionKillLog_$(Get-Date -format "dd_MM_yyyy_hhmmss").txt"
    $global:msgCollection=""
    foreach($myserver in $servers){
        $sessionlist = GetSessions $myserver  
        $serversessionlist += $sessionlist
        KillSessions $myserver $sessionlist
    }
    $global:msgCollection | Out-File $outputfile
}


$connection.Close()