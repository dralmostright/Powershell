﻿ $serverlist = @(
'NVEIADBP01',
'NVEIADBP03',
'NVEIHOSTRDBP1',
'NVEIHOSTODBP1',
'NVEIHOSTODBP5',
'NVEIODBP1',
'NVEIODBP2',
'NVEIPROCRDB01',
'NVEIPROCRDB02',
'NVEIPROCRDB03',
'NVEIPROCRDB04',
'NVEIPROCODB01',
'NVEIPROCODB02',
'NVEIPROCODB03',
'NVEIJUMP01',
'NVEIJUMP02',
'NVEIJUMP03'
 )

$mem_array = @()
$csvfile = "C:\Temp\Storage_details.csv"
foreach($servername in $serverlist){
    $Disks = get-wmiobject -class "Win32_LogicalDisk" -computername "$servername" -filter "DriveType = 3"
        foreach($disk in $Disks){
        $mem_details = New-Object PSObject -Property @{
            "Server" = $servername
            "DeviceID" = $disk.DeviceID
            "VolumeName" = $disk.VolumeName
            "Total_Size_GB" = [math]::round($disk.Size/1024/1024/1024, 2)
            "Used_Size_GB" = [math]::round($($disk.Size-$disk.FreeSpace)/1024/1024/1024, 2)
            "Free_Size_GB" = [math]::round($disk.FreeSpace/1024/1024/1024, 2)
        }
        $mem_array += $mem_details
    }
}

#$mem_array | select Server, DeviceID, VolumeName, Total_Size_GB, Used_Size_GB, Free_Size_GB | Format-table
$mem_array | select Server, DeviceID, VolumeName, Total_Size_GB, Used_Size_GB, Free_Size_GB | export-csv $csvfile -NoTypeInformation
 
