﻿$token = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI3N2RlMzkzMS1mNzExLTRkNWMtYWI2ZC1jY2U2Y2JmNDRmZmMiLCJpc01mYVJlbWVtYmVyVG9rZW4iOmZhbHNlLCJpc3MiOiJmODM4NGZmOS1jMmU5LTRhZDItYTQ5OC01MjBlMzk3ZmY3OTEiLCJpYXQiOjE2NjAwNDQ1MDYsImp0aSI6ImE0Mjg1YmI1LTQwNTItNDJjNy05NGNiLTJkZDM3YjQ5YTU3YiJ9.A0s7tzz8XluV-5TLtWW1h4cNa7LMsYZhIwQMniqbu0g'
$rubrikServer = '10.142.162.150'

Connect-Rubrik -Server $rubrikServer -Token $token
#Connect-Rubrik -Server $rubrikServer -username 'svcPsqlbkpAudit'

$sourcedb = 'MREFLEGACY'
$sourceserver = 'prod-adb-cluster'
$targetserver = 'NVEIDBBACKUPP1.prod.ops.global.ad'
$TargetDataFilePath = 'E:\MSSQL\Data\Audit'
$TargetLogFilePath = 'E:\MSSQL\Data\Audit'

echo "geting target instance"
$targetInstance = Get-RubrikSQLInstance -ServerInstance $targetserver

echo "getting source database"
$restoredb = Get-RubrikDatabase -Name $sourcedb -Host $sourceserver -Instance 'MSSQLSERVER'
$restoredb.Name
#Get-RubrikDatabase -Name 'ARMS' -HOST 'DBQCSQL-002.ccaintranet.com' -Instance 'MSSQLSERVER'

echo "getting database datafiles"
$restoreDBFiles = Get-RubrikDatabaseFiles -id $restoredb.id -RecoveryDateTime (Get-Date (Get-RubrikDatabase -id $restoredb.id).latestRecoveryPoint)

#$restoreDBFiles


$TargetFiles = @()
foreach($dbfile in $restoreDBFiles){
    if($dbfile.fileType -eq "Log"){
        $TargetFiles += [pscustomobject]@{
            logicalName = $dbFile.logicalName
            exportPath = $TargetLogFilePath
            newFilename = $dbFile.originalName
            }
    }
    else{
        $TargetFiles += [pscustomobject]@{
            logicalName = $dbFile.logicalName
            exportPath = $TargetDataFilePath
            newFilename = $dbFile.originalName
            }
    }
}

echo "Restoring database"
$RubrikRequest = Export-RubrikDatabase -id $restoredb.id -recoveryDateTime (Get-date (Get-RubrikDatabase -id $restoredb.id).latestRecoveryPoint) -targetInstanceId $targetInstance.Id -targetDatabaseName ‘ExcellusAuditorsACP_Test’ -TargetFilePaths $TargetFiles -FinishRecovery

$RubrikJobStatus = Get-RubrikRequest -id $RubrikRequest.id -Type mssql -WaitForCompletion