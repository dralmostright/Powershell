﻿$servers = @(
'nvdwodbp01.prod.ops.global.ad',                          
'nveiadbp01.prod.ops.global.ad',                          
'nveiadbp02.prod.ops.global.ad',                          
'nveidbbackupp1.prod.ops.global.ad',                      
'nveihostodbp1.prod.ops.global.ad',                       
'nveihostodbp5.prod.ops.global.ad',                       
'nveihostrdbp1.prod.ops.global.ad',                       
'nveihostrdbp2.prod.ops.global.ad',                       
'nveihostrpsp01.prod.ops.global.ad',                      
'nveihostrpsp02.prod.ops.global.ad',                      
'nveiodbp1.prod.ops.global.ad',                           
'nveiodbp2.prod.ops.global.ad',                          
'nveiprocodb01.prod.ops.global.ad',                       
'nveiprocodb02.prod.ops.global.ad',                       
'nveiprocodb03.prod.ops.global.ad',                       
'nveiprocrdb01.prod.ops.global.ad',                       
'nveiprocrdb02.prod.ops.global.ad',                       
'nveiprocrdb03.prod.ops.global.ad',                       
'nveiprocrdb04.prod.ops.global.ad',                       
'nveirdbp1.prod.ops.global.ad',                           
'nveirdbp2.prod.ops.global.ad'   



)

$server_array = @()
$csvfile = "C:\Temp\Server_details.csv"

foreach($server in $servers){
$server
#$processors = get-wmiobject -computername $server win32_processor

    ##IP Address
    $ipadd = $(Test-Connection $server -count 1).IPv4address # | select Ipv4Address

    $colItems = get-wmiobject -class "Win32_ComputerSystem" -namespace "root\CIMV2" -computername "$server"
    #$memoryGB = [math]::round($colItems.TotalPhysicalMemory/1024/1024/1024, 0)
    $FQDN = "$($colItems.Name).$($colItems.Domain)"
    $server_details = New-Object PSObject -Property @{
        "Server" = $server
        "FQDN" = $FQDN
        "IP" = $ipadd
        "LogicalCores" = $colItems.NumberOfLogicalProcessors
    }
    $server_array += $server_details


}

$server_array | select Server, FQDN, IP,  LogicalCores | export-csv $csvfile -NoTypeInformation
   