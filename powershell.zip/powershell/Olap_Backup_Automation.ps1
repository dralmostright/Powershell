﻿

############################################ Script Description ############################################################
#
# Author - Pramod Maharjan
# Purpose - To take scheduled backup of Analysis service
#
# Parameters
# 1. servername [Required] - Servername whose analysis service database needs to be backed up
# 2. backuppath [Required] - backup location
# 3. changesonly [Optional] - Takes the backup of database which are modified in last 24 hrs 
#        EI analysis services are read only and the new databases are deployed every processing cycle.
#        This parameter is to take backup of newly dpeloyed databases if the weekly backup is already obsolete due to new deployment
# 4. databases [Optional]- Name of database that needs to be backed up. Multiple comma database names are supported
#        If this parameter is not provided, it will process all the databases.
# 5. retention_hour [Optional] - time period in hour for which the backup files should be retained.
#        The backup files older than rention_hour is cleaned.
#        The default value is 240 hrs i.e 10 days 
#
############################################################################################################################

############################################ Pre-Requisites ################################################################
#
# 1. table DBA.dbo.olapbackuplist in the server where script is deployed
# 2. Folder C:\Temp\OlapBackup in the server where script is deployed
#
############################################################################################################################

param( 
    $servername ,
    $backupPath ,
    $changesonly = 0,
    $databases = "None",
    $retention_hour = 240

)

Function Log-Message{
    param($msg)
    $now = get-date -format "yyyy-MM-dd HH:mm:ss"
    Write-Verbose "$now :: $msg" -Verbose
    #echo "$now :: $msg" | Out-File -Append $outfile
}

Function SendEmail{
    param($subject, $mailbody)
    Send-MailMessage -From 'NVEIDBBACKUPP1@cotiviti.com' `
    -To 'pramod.maharjan@cotiviti.com,santosh.adhikari@cotiviti.com,prabin.nyaupane@cotiviti.com' `
    -Subject $subject `
    -Body "$mailbody .Please check the logs on NVEIDBBACKUPP1 for more details." `
    -SmtpServer 'smtpnj.d2hawkeye.net'
}

function ExecBackup{
    param($olapdb, $bkpLocation)
    try{
        $cur_date = Get-Date -format "yyyy_MM_dd_HH_mm_ss"
        #Configure Backup Parameters
        [Microsoft.AnalysisServices.BackupInfo]$olapBackup = New-Object([Microsoft.AnalysisServices.BackupInfo])
        $olapBackup.AllowOverwrite = 1
        $olapBackup.ApplyCompression = 1
        $olapBackup.BackupRemotePartitions = 1
        $olapBackup.file = "$($bkpLocation)\$($olapdb.Name)_$cur_date.abf"

        # Execute Backup
        $olapdb.Backup($olapBackup)

        $response = @(0,"")
        return $response

    }catch{
        $ErrMsg = "$($_.Exception.Message.Replace("'", " "))"
        $response = @(1,$ErrMsg)
        return $response
    }
}

Function Get-DBlist{
    if($databases -ine "None"){
        $dblist = $databases.Split(',')
    }else{
        try{
            $SSASServer = New-Object Microsoft.AnalysisServices.Server
            $SSASServer.connect($servername)
            $dblist = $SSASServer.Databases.Name
        }
        catch{
            $msg = "Error - Unable to connect to server - $servername . $($_.Exception.Message)"
            Log-Message $msg
            SendEmail "OLAP Backup Failure - $servername" $msg
            Exit
        }
    }

    #Remove white characters
    $dblist = $dblist | ForEach-Object {$_.trim()}

    return $dblist
}

Function IsDBUpdated{
    param($olapdb)

    $lastupdate = $olapdb.Lastupdate
    $today = Get-Date

    $td = New-TimeSpan -Start $lastupdate -End $today
    if ($td.TotalHours -le 24){
        $response = 1
    }else{
        $response = 0
    }

    return $response

}

Function Backup-Cleanup{
    param($db_to_cleanup, $bkpLocation, $retention_hour)

    Get-ChildItem $bkpLocation | Where-Object {$_.Name -ilike $($db_to_cleanup+'_*') `
        -and $_.Name.length -eq ($db_to_cleanup.length + 24) `
        -and $(New-TimeSpan -Start $_.LastWriteTime -End $(Get-Date)).TotalHours -gt $retention_hour} `
        | Remove-Item
}

##################################### Main Body ############################################################################

#$outfile = 'C:\Temp\OLAPBackup\OlapbackupLog.txt'
$centralserver = $env:COMPUTERNAME
#$centralserver

#Load Necessary Assemblies
[System.Reflection.Assembly]::LoadwithpartialName('Microsoft.SqlServer.Smo') | Out-Null
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.AnalysisServices") | Out-Null

## Create log file if not already exists
#if (!(Test-Path $outfile)){
#   New-Item -path "C:\Temp\OLAPBackup" -name "OlapbackupLog.txt" -type "file" 
#}


# Check if the required parameters are passed or not
if($servername -eq "" -or $backupPath -eq ""){
   Log-Message 'Error : Invalid Servername of BackupPath'
   Exit 
}

$olapdblist = Get-DBlist

foreach($dbName in $olapdblist){
    try{
        $SSASServer = New-Object Microsoft.AnalysisServices.Server
        $SSASServer.connect($servername)
        $olapdb = $SSASServer.Databases.FindByName($dbName)

        if($changesonly -eq 1 -and !$(IsDBupdated $olapdb)){
            continue
        }
        Log-Message "Starting Backup for $dbName"
        #Create Folder with name servername if not already exists
        New-Item -ItemType directory -Path "$backupPath\$servername" -Force | out-null

        $backupResponse = ExecBackup $olapdb "$backupPath\$servername"
        if ($backupResponse[0]){
            throw $backupResponse[1]
        }

        #Cleanup older files as per retention hour
        Backup-Cleanup $dbName "$backupPath\$servername" $retention_hour

    }catch{
        $msg = "Error : $($_.Exception.Message)"
        Log-Message $msg
        SendEmail "OLAP Backup Failure - $servername - $dbName" $msg
    }
}



    
