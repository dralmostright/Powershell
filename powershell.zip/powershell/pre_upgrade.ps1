﻿Param(
  [string]$central_server,
  [string]$Path,
  [string]$username,
  [string]$Password,
  [string]$job,
  [string]$linkedserver,
  [string]$logins,
  [string]$roles,
  [string]$grants,
  [string]$backup,
  [string]$adhoc,
  [string]$server,
  [string]$databases
)


function get-jobscripts([string]$sqlserver,[string]$directory) {
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null
$srv = New-Object "Microsoft.SqlServer.Management.Smo.Server" $sqlserver
$srv.JobServer.Jobs | foreach {$_.Script()+ "GO"} | Out-File $($directory +  "\jobs.sql") 
}
function get-linkscripts([string]$sqlserver,[string]$directory) {
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null
$srv = New-Object "Microsoft.SqlServer.Management.Smo.Server" $sqlserver
$srv.LinkedServers | foreach {$_.Script()+ "GO"} | Out-File $($directory +  "\linkedservers.sql") 
}
function get-userlogins([string]$sqlserver,[string]$directory) {
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null
$srv = New-Object "Microsoft.SqlServer.Management.Smo.Server" $sqlserver
$srv.Logins | foreach {$_.Script()+ "GO"} | Out-File $($directory +  "\logins.sql") 
}
function get-roles([string]$sqlserver,[string]$directory) {
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null
$srv = New-Object "Microsoft.SqlServer.Management.Smo.Server" $sqlserver
$srv.Roles | foreach {$_.Script()+ "GO"} | Out-File $($directory +  "\roles.sql") 
}

function get-grants([string]$sqlserver,[string]$directory) {
[Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")
$connectionString="Server=$sqlserver;Integrated Security=True;"
$sqlServer = New-Object("Microsoft.SqlServer.Management.Smo.Server") $sqlserver
$connection=New-Object System.Data.SqlClient.SqlConnection
$connection.ConnectionString=$connectionString
$connection.Open()
$command=New-Object System.Data.SqlClient.SqlCommand
$command.Connection=$connection
$command.CommandTimeout = 0 
$string="SET NOCOUNT ON;DECLARE @GRANT TABLE (	DBNAME	VARCHAR (500),PRINCIPALNAME	VARCHAR(500),PRINCIPALTYPE	VARCHAR (500), GRANTEDBY	VARCHAR (500),
PERMISSION_NAME	VARCHAR (500), STATE_DESC	VARCHAR (500),OBJECTNAME	VARCHAR (500), OBJECTTYPE VARCHAR (500));
INSERT INTO @GRANT 
Exec master.sys.sp_MSforeachdb  'SELECT ''?'', P.[NAME], P.[TYPE_DESC], P2.[NAME], DBP.[PERMISSION_NAME], DBP.[STATE_DESC], SO.[NAME], SO.[TYPE_DESC] 
FROM [SYS].[DATABASE_PERMISSIONS] DBP LEFT JOIN [SYS].[OBJECTS] SO ON DBP.[MAJOR_ID] = SO.[OBJECT_ID] LEFT JOIN [SYS].[DATABASE_PRINCIPALS] P 
ON DBP.[GRANTEE_PRINCIPAL_ID] = P.[PRINCIPAL_ID] LEFT JOIN [SYS].[DATABASE_PRINCIPALS] P2 
ON DBP.[GRANTOR_PRINCIPAL_ID] = P2.[PRINCIPAL_ID] 
WHERE P.[NAME] NOT LIKE ''##%'' AND P.[NAME] <>''dbo'''
 SELECT distinct 'USE '+DBNAME+'; GRANT '+PERMISSION_NAME+' TO '+QUOTENAME (PRINCIPALNAME) +';' [grants] FROM @GRANT"
$command.CommandText=$string 
$result=$command.ExecuteReader()
$tab= New-Object System.Data.DataTable
$tab.load($result)
echo ''| Out-File $($directory +  "\grants.sql")
foreach($s in $tab.grants)
{
echo $s| Out-File -Append $($directory +  "\grants.sql")
}
$connection.close()
}

function get-config([string]$sqlserver,[string]$directory) {
[Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")
$connectionString="Server=$sqlserver;Integrated Security=True;"
$sqlServer = New-Object("Microsoft.SqlServer.Management.Smo.Server") $sqlserver
$connection=New-Object System.Data.SqlClient.SqlConnection
$connection.ConnectionString=$connectionString
$connection.Open()
$command=New-Object System.Data.SqlClient.SqlCommand
$command.Connection=$connection
$command.CommandTimeout = 0 
$string="
set nocount on
SELECT '---------------------------------------------------------------------------------------------------------------'   as 'data'
union all 
SELECT 'VERSION   =>   ' +@@VERSION  as 'data'
union all
SELECT '---------------------------------------------------------------------------------------------------------------'  as 'data'
union all 
SELECT '|'+left('  '+'NAME' + space(30), 30) +'|'+
	   left('  '+'STATE_DESC'  + space(20), 20) +'|'+
	   left('  '+'RECOVERY_MODEL_DESC' + space(20), 20) +'|'+
	   left('  '+'COMPATIBILITY_LEVEL' + space(10), 10) +'|'+
	   left('  '+'LOG_REUSE_WAIT_DESC' + space(25), 25) +'|' as 'data'
UNION ALL
SELECT '---------------------------------------------------------------------------------------------------------------'  as 'data'
union all 
SELECT '|'+left('  '+name collate SQL_Latin1_General_CP1_CI_AS + space(30), 30) +'|'+
	   left('  '+STATE_DESC collate SQL_Latin1_General_CP1_CI_AS + space(20), 20) +'|'+
	   left('  '+RECOVERY_MODEL_DESC collate SQL_Latin1_General_CP1_CI_AS + space(20), 20) +'|'+
	   left('  '+CONVERT(VARCHAR,COMPATIBILITY_LEVEL) collate SQL_Latin1_General_CP1_CI_AS + space(10), 10) +'|'+
	   left('  '+LOG_REUSE_WAIT_DESC collate SQL_Latin1_General_CP1_CI_AS + space(25), 25) +'|' as 'data'
 FROM SYS.DATABASES
 union all
 SELECT '---------------------------------------------------------------------------------------------------------------'  as 'data'

 
 
"
$command.CommandText=$string 
$result=$command.ExecuteReader()
$tb= New-Object System.Data.DataTable

$tb.load($result)
echo ''| Out-File $($directory +  "\config.sql")
foreach($s in $tb.data)
{

echo $s| Out-File -Append $($directory +  "\config.sql")
}
$connection.close()
}


function get-backup([string] $central_server,[string]  $path,[string]  $server,[string] $adhoc,[string] $databases) {
[Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")
$connectionString="Server=$central_server;Integrated Security=True;"
$central_server = New-Object("Microsoft.SqlServer.Management.Smo.Server") $central_server
$connection=New-Object System.Data.SqlClient.SqlConnection
$connection.ConnectionString=$connectionString
$connection.Open()
$command=New-Object System.Data.SqlClient.SqlCommand
$command.Connection=$connection
$command.CommandTimeout = 0 
$string="EXEC master.dbo.BACKUPCALL @SERVER='"+$server+"',@path='"+$path+"\',@adhoc='"+$adhoc+"',@DBLIST='"+$databases+"'"
$command.CommandText=$string 
$command.ExecuteReader()
$connection.close()
}

$directoryname=$path
$E=''
$date=get-date -Format u
$date= ($date.replace('-','')).substring(0,8)
$logfile=$directoryname+'\Pre_upgrade_'+$date+'.txt'

$start_time = get-date
$start=get-date -Format G
echo "================================================================================================" | Out-file -Encoding default -Append $logfile
echo "STARTED   : $start => PRE UPGRADE TASK " | Out-file -Encoding default -Append $logfile

$start_time = get-date
$start=get-date -Format G
echo "STARTED   : $start => CONNECTION TO CENTRAL SERVER $CENTRAL_SERVER " | Out-file -Encoding  default  -Append $logfile 

[Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")
$conn="Server=$central_server;Integrated Security=True;"
$sqlServer = New-Object("Microsoft.SqlServer.Management.Smo.Server") $central_Server
$connect=New-Object System.Data.SqlClient.SqlConnection
$connect.ConnectionString=$conn
$connect.Open()
$command=New-Object System.Data.SqlClient.SqlCommand
$command.Connection=$connect
$command.CommandTimeout = 0 

$end_time = Get-Date
$end = get-date -Format G
$tspan = New-TimeSpan -start $start_time -end $end_time
$seconds = ([TimeSpan]::Parse($tspan)).TotalSeconds
echo "COMPLETED : $start | $end | $seconds sec => CONNECTED TO CENTRAL SERVER $CENTRAL_SERVER " | Out-file -Append -Encoding default $logfile
echo "------------------------------------------------------" | Out-file -Encoding  default  -Append $logfile 

$start_time = get-date
$start=get-date -Format G
echo "STARTED   : $start => SELECTING SERVERS FOR PRE_UPGRADE TASK " | Out-file -Encoding  default  -Append $logfile 

$string="SELECT SERVER FROM REPORT.dbo.servers"
$command.CommandText=$string 
$result=$command.ExecuteReader()
$table= New-Object System.Data.DataTable
$table.load($result)

$end_time = Get-Date
$end = get-date -Format G
$tspan = New-TimeSpan -start $start_time -end $end_time
$seconds = ([TimeSpan]::Parse($tspan)).TotalSeconds
echo "COMPLETED : $start | $end | $seconds sec => SERVER SELECTED " | Out-file -Append -Encoding default $logfile

foreach($sqlserver in $table.server)
{
$start_time = get-date
$start=get-date -Format G
echo "------------------------------------------------------" | Out-file -Encoding  default  -Append $logfile 
$start_time = get-date
$start=get-date -Format G
echo "STARTED   : $start => CREATING DIRECTORY FOR $SQLSERVER " | Out-file -Encoding  default  -Append $logfile 

$directory=$directoryName+'\'+$sqlserver
$Error.Clear()
$end_time = Get-Date
$end = get-date -Format G
$tspan = New-TimeSpan -start $start_time -end $end_time
$seconds = ([TimeSpan]::Parse($tspan)).TotalSeconds

New-Item -ItemType directory -Path $directory -Force
If($Error){
echo "WARNING   : $start | $end | $seconds sec => DIRECTORY ALREADY EXISTS FOR $sqlserver " | Out-file -Append -Encoding default $logfile
}
else{
echo "COMPLETED : $start | $end | $seconds sec => DIRECTORY CREATED FOR $sqlserver " | Out-file -Append -Encoding default $logfile
}
}

echo "------------------------------------------------------" | Out-file -Encoding  default  -Append $logfile 
<#---------------CONFIG----------------#>

foreach($sqlserver in $table.server)
{
$directory=$directoryName+'\'+$sqlserver
$start_time = get-date
$start=get-date -Format G
echo "STARTED   : $start => SCRIPTING CONFIGURATION FOR $SQLSERVER " | Out-file -Encoding  default  -Append $logfile 


Try{
get-config $sqlserver  $directory
$end_time = Get-Date
$end = get-date -Format G
$tspan = New-TimeSpan -start $start_time -end $end_time
$seconds = ([TimeSpan]::Parse($tspan)).TotalSeconds
echo "COMPLETED : $start | $end | $seconds sec => CONFIGURATION SCRIPTED FOR $sqlserver " | Out-file -Append -Encoding default $logfile
}

Catch{
$end_time = Get-Date
$end = get-date -Format G
$tspan = New-TimeSpan -start $start_time -end $end_time
$seconds = ([TimeSpan]::Parse($tspan)).TotalSeconds
echo "ERROR     : $start | $end | $seconds sec => CONFIGURATION NOT SCRIPTED FOR $sqlserver " | Out-file -Append -Encoding default $logfile

$errText = $Error[0].ToString() 
$E=$E + '     '+$errText+$sqlserver +"`r`n"
}
}




echo "------------------------------------------------------" | Out-file -Encoding  default  -Append $logfile 
<#---------------JOB----------------#>
if($job -ieq 'Y'){
foreach($sqlserver in $table.server)
{
$directory=$directoryName+'\'+$sqlserver
$start_time = get-date
$start=get-date -Format G
echo "STARTED   : $start => SCRIPTING JOBS FOR $SQLSERVER " | Out-file -Encoding  default  -Append $logfile 

Try{
get-jobscripts $sqlserver  $directory
$end_time = Get-Date
$end = get-date -Format G
$tspan = New-TimeSpan -start $start_time -end $end_time
$seconds = ([TimeSpan]::Parse($tspan)).TotalSeconds
echo "COMPLETED : $start | $end | $seconds sec => JOBS SCRIPTED FOR $sqlserver " | Out-file -Append -Encoding default $logfile
}

Catch{
$end_time = Get-Date
$end = get-date -Format G
$tspan = New-TimeSpan -start $start_time -end $end_time
$seconds = ([TimeSpan]::Parse($tspan)).TotalSeconds
echo "ERROR     : $start | $end | $seconds sec => JOBS NOT SCRIPTED FOR $sqlserver " | Out-file -Append -Encoding default $logfile

$errText = $Error[0].ToString() 
$E=$E + '     '+$errText+$sqlserver +"`r`n"
}
}
}
else{ 
echo "INFO      : $start => SKIPPED JOBS  " | Out-file -Encoding  default  -Append $logfile 

}

echo "------------------------------------------------------" | Out-file -Encoding  default  -Append $logfile 
<#---------------LINKED SERVER----------------#>
if($linkedserver -ieq 'Y'){
foreach($sqlserver in $table.server)
{

$start_time = get-date
$start=get-date -Format G
echo "STARTED   : $start => SCRIPTING LINKED SERVERS FOR $SQLSERVER " | Out-file -Encoding  default  -Append $logfile 

Try{
$directory=$directoryName+'\'+$sqlserver
get-linkscripts $sqlserver  $directory
$end_time = Get-Date
$end = get-date -Format G
$tspan = New-TimeSpan -start $start_time -end $end_time
$seconds = ([TimeSpan]::Parse($tspan)).TotalSeconds
echo "COMPLETED : $start | $end | $seconds sec => LINKED SERVER SCRIPTED FOR $sqlserver " | Out-file -Append -Encoding default $logfile
}

Catch{
$end_time = Get-Date
$end = get-date -Format G
$tspan = New-TimeSpan -start $start_time -end $end_time
$seconds = ([TimeSpan]::Parse($tspan)).TotalSeconds
echo "ERROR     : $start | $end | $seconds sec => LINKED SERVER NOT SCRIPTED FOR $sqlserver " | Out-file -Append -Encoding default $logfile

$errText = $Error[0].ToString() 
$E=$E + '     '+$errText+$sqlserver +"`r`n"
}
}
}
else{
echo "INFO      : $start => SKIPPED LINKED SERVER " | Out-file -Encoding  default  -Append $logfile 

}

echo "------------------------------------------------------" | Out-file -Encoding  default  -Append $logfile 
<#--------------- LOGINS ----------------#>
if($logins -ieq 'Y'){
foreach($sqlserver in $table.server)
{
$start_time = get-date
$start=get-date -Format G
echo "STARTED   : $start => SCRIPTING LOGINS FOR $SQLSERVER " | Out-file -Encoding  default  -Append $logfile 

Try{
$directory=$directoryName+'\'+$sqlserver
get-userlogins $sqlserver  $directory
$end_time = Get-Date
$end = get-date -Format G
$tspan = New-TimeSpan -start $start_time -end $end_time
$seconds = ([TimeSpan]::Parse($tspan)).TotalSeconds
echo "COMPLETED : $start | $end | $seconds sec => LOGINS SCRIPTED FOR $sqlserver " | Out-file -Append -Encoding default $logfile
}

Catch{
$end_time = Get-Date
$end = get-date -Format G
$tspan = New-TimeSpan -start $start_time -end $end_time
$seconds = ([TimeSpan]::Parse($tspan)).TotalSeconds
echo "ERROR     : $start | $end | $seconds sec => LOGINS NOT SCRIPTED FOR $sqlserver " | Out-file -Append -Encoding default $logfile

$errText = $Error[0].ToString() 
$E=$E + '     '+$errText+$sqlserver +"`r`n"
}
}
}
else{
echo "INFO      : $start => SKIPPED LOGINS" | Out-file -Encoding  default  -Append $logfile 

}

echo "------------------------------------------------------" | Out-file -Encoding  default  -Append $logfile 
<#--------------- ROLES  ----------------#>
if($roles -ieq 'Y'){
foreach($sqlserver in $table.server)
{
$start_time = get-date
$start=get-date -Format G
echo "STARTED   : $start => SCRIPTING ROLES FOR $SQLSERVER " | Out-file -Encoding  default  -Append $logfile 

Try{
$directory=$directoryName+'\'+$sqlserver
get-roles $sqlserver  $directory
$end_time = Get-Date
$end = get-date -Format G
$tspan = New-TimeSpan -start $start_time -end $end_time
$seconds = ([TimeSpan]::Parse($tspan)).TotalSeconds
echo "COMPLETED : $start | $end | $seconds sec => ROLES SCRIPTED FOR $sqlserver " | Out-file -Append -Encoding default $logfile

}

Catch{
$end_time = Get-Date
$end = get-date -Format G
$tspan = New-TimeSpan -start $start_time -end $end_time
$seconds = ([TimeSpan]::Parse($tspan)).TotalSeconds
echo "ERROR     : $start | $end | $seconds sec => ROLES NOT SCRIPTED FOR $sqlserver " | Out-file -Append -Encoding default $logfile

$errText = $Error[0].ToString() 
$E=$E + '     '+$errText+$sqlserver +"`r`n"
}
}
}
else{
echo "INFO      : $start => SKIPPED ROLES" | Out-file -Encoding  default  -Append $logfile 

}

echo "------------------------------------------------------" | Out-file -Encoding  default  -Append $logfile 
<#--------------- GRANTS  ----------------#>
if($grants -ieq 'Y'){
foreach($sqlserver in $table.server)
{
$start_time = get-date
$start=get-date -Format G
echo "STARTED   : $start => SCRIPTING GRANTS FOR $SQLSERVER " | Out-file -Encoding  default  -Append $logfile 

Try{
$directory=$directoryName+'\'+$sqlserver
get-grants $sqlserver  $directory
$end_time = Get-Date
$end = get-date -Format G
$tspan = New-TimeSpan -start $start_time -end $end_time
$seconds = ([TimeSpan]::Parse($tspan)).TotalSeconds
echo "COMPLETED : $start | $end | $seconds sec => GRANTS SCRIPTED FOR $sqlserver " | Out-file -Append -Encoding default $logfile
}

Catch{
$end_time = Get-Date
$end = get-date -Format G
$tspan = New-TimeSpan -start $start_time -end $end_time
$seconds = ([TimeSpan]::Parse($tspan)).TotalSeconds
echo "ERROR     : $start | $end | $seconds sec => GRANTS NOT SCRIPTED FOR $sqlserver " | Out-file -Append -Encoding default $logfile

$errText = $Error[0].ToString() 
$E=$E + '     '+$errText+$sqlserver +"`r`n"
}
}
}
else{
echo "INFO      : $start => SKIPPED GRANTS " | Out-file -Encoding  default  -Append $logfile 

}

echo "------------------------------------------------------" | Out-file -Encoding  default  -Append $logfile 
<#--------------- BACKUP  ----------------#>

if($backup -ieq 'Y' -and $adhoc -ieq 'N'){
foreach($sqlserver in $table.server)
{
$start_time = get-date
$start=get-date -Format G
echo "STARTED   : $start => TAKING BACKUP FOR $SQLSERVER " | Out-file -Encoding  default  -Append $logfile 

Try{

get-backup $central_server  $Path  $sqlserver $adhoc $databases
$end_time = Get-Date
$end = get-date -Format G
$tspan = New-TimeSpan -start $start_time -end $end_time
$seconds = ([TimeSpan]::Parse($tspan)).TotalSeconds
echo "COMPLETED : $start | $end | $seconds sec => TAKING BACKUP FOR $sqlserver " | Out-file -Append -Encoding default $logfile
}

Catch{
$end_time = Get-Date
$end = get-date -Format G
$tspan = New-TimeSpan -start $start_time -end $end_time
$seconds = ([TimeSpan]::Parse($tspan)).TotalSeconds
echo "ERROR     : $start | $end | $seconds sec => TAKING BACKUP FOR $sqlserver " | Out-file -Append -Encoding default $logfile

$errText = $Error[0].ToString() 
$E=$E + '     '+$errText+$sqlserver +"`r`n"
}
}
}


if($backup -ieq 'Y' -and $adhoc -ieq 'Y'){
$start_time = get-date
$start=get-date -Format G
echo "STARTED   : $start => TAKING BACKUP FOR $server " | Out-file -Encoding  default  -Append $logfile 

Try{
get-backup $central_server  $Path  $server $adhoc $databases
$end_time = Get-Date
$end = get-date -Format G
$tspan = New-TimeSpan -start $start_time -end $end_time
$seconds = ([TimeSpan]::Parse($tspan)).TotalSeconds
echo "COMPLETED : $start | $end | $seconds sec => TAKING BACKUP FOR $server " | Out-file -Append -Encoding default $logfile
}

Catch{
$end_time = Get-Date
$end = get-date -Format G
$tspan = New-TimeSpan -start $start_time -end $end_time
$seconds = ([TimeSpan]::Parse($tspan)).TotalSeconds
echo "ERROR     : $start | $end | $seconds sec => TAKING BACKUP FOR $server " | Out-file -Append -Encoding default $logfile

$errText = $Error[0].ToString() 
$E=$E + '     '+$errText+$sqlserver +"`r`n"
}
}

if($backup -ieq 'N' -and $adhoc -ieq 'N'){
echo "INFO      : $start => SKIPPED BACKUP FOR $SQLSERVER " | Out-file -Encoding  default  -Append $logfile 
}




$start_time = get-date
$start=get-date -Format G
echo "------------------------------------------------------" | Out-file -Encoding  default  -Append $logfile 
echo "COMPLETED   : $start => PRE UPGRADE TASK " | Out-file -Encoding default -Append $logfile
echo "------------------------------------------------------" | Out-file -Encoding  default  -Append $logfile 

if ($E -ne ''){

echo "Error Summary:" | Out-file -Append -Encoding default $logfile
echo "$E" | Out-file -Append -Encoding default $logfile
}
echo "================================================================================================" | Out-file -Encoding default -Append $logfile
