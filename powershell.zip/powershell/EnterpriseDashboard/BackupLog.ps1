﻿$logpath = 'E:\Backup\Backup_Logs'
$serverlist = @(
'NVEIADBP01',
'NVEIADBP02',
'NVEIHOSTRDBP1',
'NVEIHOSTRDBP2',
'NVEIPROCRDB01',
'NVEIPROCRDB02',
'NVEIPROCRDB03',
'NVEIPROCRDB04'
)

foreach($servername in $serverlist){
    $backuplog = "$($logpath)\$($servername)_BackupLog.txt"
    $update_date = $(dir $backuplog).LastWriteTime
    $date = Get-Date
    if($($date - $update_date).Days -lt 1){
        #echo $backuplog
        $abc = Get-Content $backuplog
        $abc | out-file -filepath $backuplog -Encoding UTF8
        Invoke-WebRequest  -Uri http://10.128.158.240/ords/edb_dashboard/mssql/backup -ContentType application/data -Method POST -Infile $backuplog -Headers @{"HOSTNAME"="$servername";"SUBJECT"="Subjectname"} -UseBasicParsing    
        #Get-Content $backuplog
    }
}