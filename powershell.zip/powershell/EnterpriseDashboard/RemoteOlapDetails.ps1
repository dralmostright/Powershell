﻿
Function WriteTable{
    param($disObject)

    $disObject | Format-Table -AutoSize #| out-file -Append $logfile
}
Function WriteLog{
    param($logtext)
    $logtext #| Out-File -Append $logfile
}
function GetFolderSize{
    param($foldername)
    try{
        $foldersize = Get-ChildItem -recurse $foldername -ErrorAction Stop | Measure-Object -Property Length -Sum 
        $sizeMB = $foldersize.Sum /1MB
    }catch{
        $sizeMB = -1
    }
    return $sizeMB
}

Function OLAPsize{
    param($db, $defaultdir)
    
    #Get base location of database
    $baselocation = $defaultdir
    if($db.DbStorageLocation -ne $null){
        if($db.DbStorageLocation.StartsWith("\\?\")){
            $baselocation = $db.DbStorageLocation.replace("\\?\","")
        }
        else{
            $baselocation = $db.DbStorageLocation
        }
    }

    try{
        #Get database folder
        $namecheck = $db.ID + "."
        $folder = $($(Get-ChildItem $baselocation | Where-Object {$_.PSIsContainer -eq $True}) | Where-Object {$_.Name.StartsWith($namecheck)}).Name
        if($folder -eq $null){
            throw "Folder not Found"
        }
        $Dblocation = $baselocation + "\"+$folder
    
        #Get database size
        $dbsize = GetFolderSize $Dblocation
        if($dbsize -lt 0){
            throw "Get-ChildItem Error"
        }

        #Check if partition data exists in different location
        $partFolders = @()
        foreach($cube in $db.Cubes){
            foreach($mg in $cube.MeasureGroups){
                foreach($part in $mg.Partitions){
                    if($part.StorageLocation -ne $null){
                        if($partFolders -notcontains $part.StorageLocation){
                            $partFolders += $part.StorageLocation
                        }
                    }
                }
            }
        }
        if($partFolders.Length -gt 0){
            foreach($partFolder in $partFolders){
                $partsize = GetFolderSize $partFolder
                if($partsize -lt 0){
                    throw "Get-ChildItem Error"
                }
                $dbsize += $partsize
            }
        }

    }catch{
        $dbsize = -1
    }
    return [math]::Round($dbsize,2)
}

[System.Reflection.Assembly]::LoadWithPartialName('Microsoft.AnalysisServices') | Out-Null
### Reset Log file
#Out-File $logfile
$servername=$env:COMPUTERNAME
$olapserver=New-object('Microsoft.AnalysisServices.Server') 
$olapserver.connect($servername)
$defaultdatadir = $($olapserver.ServerProperties | Where-object {$_.Name -eq "DataDir"}).Value

$DatabaseDetails=@()
foreach($db in $olapserver.Databases){
        $dbsize = OLAPsize $db $defaultdatadir
        [array]$Dbdetail = New-Object PSObject -Property @{
            "SERVER" = $servername;
            "DATABASE" = $db.Name;
            "CREATE_DATE" = $db.CreatedTimeStamp;
            "STATE" = $db.state;
            "ESTIMATED_SIZE_MB" = [math]::round($db.EstimatedSize/1MB,2);
            "ACTUAL_SIZE_MB" = $dbsize;
        }
        $DatabaseDetails += $Dbdetail
    
}

$DatabaseDetails


