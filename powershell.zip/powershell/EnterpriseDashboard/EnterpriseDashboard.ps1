﻿Import-Module SqlPs | out-null
<#
 $serverlist = @(
"NPEIBACKUPP1",
"NVEIHOSTRDBP1",
"NVEIHOSTRDBP2",
#"NVEIHOSTRDBP3",
#"NVEIHOSTRDBP4",
"NVEIRDBP1",
"NVEIRDBP2",
#"NVEIRDBP8",
#"NPEIODBP2",
"NVEIADBP02",
"NVEIPROCRDB01",
"NVEIPROCRDB02",
"NVEIPROCRDB03",
"NVEIPROCRDB04",
"NVEISVCQCP2",
"NVSOAMDBP2.d2hawkeye.net",
"NVEI2HOSTRDBU01",
"NVEI2ADBU01",
"NVEI2ADBU02",
"NVEI1RDBU1",
"NVEI1RDBU3",
"NVEI1ADBU10",
"NVEI1ADBU11"
)
#>

$serverdata=Invoke-WebRequest "http://10.128.158.240/ords/edb_dashboard/common/dbinfo/?DBTYPE=MSSQL&SITE=EAD" -UseBasicParsing  | convertFrom-Json | Select  -expand items
$serverdata = $serverdata | where-object{ ($_.environment -ieq 'UAT' -or $_.environment -ieq 'PROD') -and ($_.dbname -imatch 'MSSQLSERVER')}
$serverlist = $serverdata.hostname

$centralServer = 'NVEIDBBACKUPP1'
$errfile = "C:\Temp\DashBoardlog.txt"

$data=Invoke-WebRequest "http://10.128.158.240:80/ords/edb_dashboard/mssql/list" -UseBasicParsing  | convertFrom-Json | Select  -expand items


foreach ($servername in $serverlist) {
    foreach ($i in $data){
        try{
        $params=Invoke-Sqlcmd -ServerInstance $servername -query $i.sqlquery -ErrorAction Stop | Select-Object * -ExcludeProperty ItemArray, Table, RowError, RowState, HasErrors | ConvertTo-Json
        #$params
        Invoke-WebRequest -UseBasicParsing -Uri $i.url -ContentType application/json -Method POST -Body $params 
        }
        catch{
            echo "$(Get-Date) Error in $servername :: $($_.Exception.Message)" | out-file -Append $errfile
        }
    }
}
#>

$params1=Invoke-Sqlcmd -ServerInstance $centralServer -query "SELECT SERVERNAME,databaseName,actual_size_mb,logdate FROM server_report.dbo.Olap_database_Details WHERE getdate() - logdate < 0.5;" | Select-Object * -ExcludeProperty ItemArray, Table, RowError, RowState, HasErrors | ConvertTo-Json
Invoke-WebRequest -UseBasicParsing -Uri http://10.128.158.240/ords/edb_dashboard/mssql/olap -ContentType application/json -Method POST -Body $params1  
#>