﻿### Parameters to be set ####
$centralServer = 'NVEIDBBACKUPP1'
$centralDB = 'SERVER_REPORT'

[System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.Smo') | Out-Null
$sqlserver = New-Object 'Microsoft.SqlServer.Management.Smo.Server' $centralServer
$db = $sqlserver.Databases.Item($centralDB)

$serverlist = @(
'NVEIHOSTODBP1.prod.ops.global.ad',
'NVEIHOSTODBP3.prod.ops.global.ad',
'NVEIHOSTODBP4.prod.ops.global.ad',
'NVEIHOSTODBP5.prod.ops.global.ad',
'NPEIODBP2.prod.ops.global.ad',
'NVEIODBP1.prod.ops.global.ad',
'NVEIODBP2.prod.ops.global.ad',
'NVEIODBP8.prod.ops.global.ad',
'NVEIPROCODB01.prod.ops.global.ad',
'NVEIPROCODB02.prod.ops.global.ad',
'NVEIPROCODB03.prod.ops.global.ad',
'NVEIPROCODB04.prod.ops.global.ad',
'NVDWODBP01.prod.ops.global.ad',
'NVEI2HOSTODBU01.uat2.ops.global.ad',
'NVEI2HOSTODBU02.uat2.ops.global.ad',
'NVEI1ODBU1.uat1.ops.global.ad',
'NVEI1ODBU2.uat1.ops.global.ad',
'NVEI1ODBU3.uat1.ops.global.ad'
)

foreach($servername in $serverlist){
    $serverFQDN=$servername
    $scriptpath = 'C:\MSSQL\scripts\powershell\EnterpriseDashboard\RemoteOlapDetails.ps1'


    $serverDetails = @()
    $serverDetails = Invoke-Command -Computername $serverFQDN -Filepath $scriptpath 

   
    foreach($detail in $serverDetails){
        $db.ExecuteNonQuery("Insert into OLAP_DATABASE_DETAILS values('$($detail.Server)', '$($detail.database)', '$($detail.Create_date)',
         '$($detail.state.value)', $($detail.Estimated_size_mb), $($detail.Actual_size_mb), getdate());")
    }
}
    
