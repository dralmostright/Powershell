﻿$servername = "nveiprocodb04"
$output = "E:\Adhoc_Backup\Reports\nveiprocodb04size.txt"
$loadinfo = [Reflection.Assembly]::LoadWithPartialName("Microsoft.AnalysisServices")
$sqlserver = New-Object Microsoft.AnalysisServices.Server 
$sqlserver.connect($servername)
out-file $output
#$sqlserver.Databases | get-Member
foreach($d in $sqlserver.databases){
    
    echo "$($d.name.PadRight(50)) $($([math]::Round($($d.EstimatedSize/1024/1024/1024),2)).ToString().PadRight(15)) $($([math]::Round($($d.EstimatedSize/1024/1024),2)).ToString().PadRight(15))" | out-file -Append $output
}