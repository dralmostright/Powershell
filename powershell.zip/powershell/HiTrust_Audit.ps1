﻿
#Report path
$path = 'C:\temp'

# List of servers
$serverlist= @(
'HOSTNAME1',
'HOSTNAME2'
)



## Funciton Definitions
function accountActive($usr){
    $acc = switch ($usr.IsDisabled){
        "True" {"0"}
        "False" {"1"}
    }
    $acc
}

## Main Program
$AuditArray = @()
$csvfile = "$path\HiTrust_AuditReport.csv"

foreach($servername in $serverlist){
    $servername
    ## Connect to server
    [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null
    $server = New-Object Microsoft.SqlServer.Management.Smo.Server $servername
    
    $serverlogins = $server.logins
    $sysadm_role  = $server.Roles | where-object {$_.Name -ieq 'sysadmin'}
    $sysadmin_logins = $sysadm_role.EnumServerRoleMembers()

    ## Get the details for each login
    foreach($login in $serverlogins){
        $sysadm_check = 0
        if($sysadmin_logins -icontains $login.Name){
            $sysadm_check = 1
        }
        $audit = New-Object PSObject -property @{
            "UserName" = $login.Name;
            "LoginType" = $login.LoginType
            "Is_SysAdmin" = $sysadm_check
            "Account_active" =  accountActive($login);
            "Database_Server" = $servername;
        }
        $AuditArray += $audit
    }

}

# Export the audit data to csv
$AuditArray | select UserName, LoginType, Is_sysadmin, Account_Active, Database_Server | Export-Csv -Path $csvfile -NoTypeInformation 