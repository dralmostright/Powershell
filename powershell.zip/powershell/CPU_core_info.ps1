﻿$servers=@("NPEIBACKUPP1",
"NPEIRDBP1",
"NPEIRDBP2",
"NPEIRDBP3",
"NPEIRDBP8",
"NVEIRDBP1",
"NVEIRDBP2",
"NVEIRDBP8",
"NPEIODBP2",
"NPEIODBP3",
"NPEIODBP5",
"NPEIODBP6",
"NPEIODBP8",
"NVEIODBP1",
"NVEIODBP2",
"NVEIODBP8",
"NVEIHOSTRDBP99",
"NVEIHOSTODBP99",
"NVEIHOSTRPSP01",
"NVEIHOSTRPSP02"
"NVEIADBP01",
"NVEIADBP02",
"NPEIRDBPC4",
"NPEIRDBPC5",
"NPEIRDBPC7",
"NVEIRDBPC2",
"NVEIRDBPC3",
"NVEIRDBPC6",
"NPEIODBPC1",
"NPEIODBPC2",
"NPEIODBPC3",
"NVEIPROCRDB01",
"NVEIPROCRDB02",
"NVEIPROCRDB03",
"NVEIPROCRDB04",
"NVEIPROCRDB05",
"NVEIPROCRDB06",
"NVEIPROCODB01",
"NVEIPROCODB02",
"NVEIPROCODB03",
"NVEIPROCODB04",
"NVEIPROCODB05",
"NVDW0DBP01",
"NVEISVCQCP1",
"NVEISVCQCP2",
"NVVHMDBDV1")
function Get-CPUs {
    param ($server)
     $processors = get-wmiobject -computername $server win32_processor
    if (@($processors)[0].NumberOfCores)
    {
        $nproc = @($processors).count
        $npcore = @($processors)[0].NumberOfCores
        $cores = @($processors).count * @($processors)[0].NumberOfCores
        $server+","+$nproc+" , " + $npcore +" , " + $cores 
    }
    else
    {
        $nproc = @($processors).count
        $cores = @($processors).count
        $server+","+$nproc+" , 1 , " + $cores
    }
    $sockets = @(@($processors) |  % {$_.SocketDesignation} |     select-object -unique).count;
    #$server+","+$cores
}
$suffix = get-date -format "dd_MM_yyyy"
$suffix += ".txt"
#echo --------------------------------------- > C:\temp\osinfo_$suffix
echo --------------------------------------- > c:\temp\cpu_$suffix
#echo --------------------------------------- > c:\temp\mem_$suffix
#echo "ServerName `tDrive `tTotalSpace `tUsedSpace `tFreeSpace" > c:\temp\disk_$suffix
#echo --------------------------------------- > c:\temp\dotnet_$suffix
foreach ($server in $servers){
    
     Get-CPUs($server)>>c:\temp\cpu_$suffix
     
}
