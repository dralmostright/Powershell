﻿Function LogMessage{
    param($msg, $outfile)
    $now = get-date -format "yyyy-MM-dd HH:mm:ss"
    Write-Verbose "$now :: $msg" -Verbose
    echo "$now :: $msg" | Out-File -Append $outfile
}

Function SendEmail{
    param($subject, $mailbody)
    Send-MailMessage -From 'NVEIDBBACKUPP1@cotiviti.com' `
    -To 'prabin.nyaupane@cotiviti.com, santosh.adhikari@cotiviti.com'`
    -Subject $subject `
    -Body "$mailbody .Please check the logs on W1D1-SQLPOC03 for more details." `
    -SmtpServer 'smtpnj.d2hawkeye.net'
}

Function DisplayMessage{
    param($msg)
    $now = get-date -format "yyyy-MM-dd HH:mm:ss"
    Write-Verbose "$now :: $msg" -Verbose
}

function AuditMain{
    param([Hashtable]$auditserver, $serverlog)

    [System.Reflection.Assembly]::LoadwithpartialName('Microsoft.SqlServer.Smo') #| Out-Null
    [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoExtended") #| Out-Null

    $centralserver = New-Object 'Microsoft.SqlServer.Management.Smo.Server' $auditserver.ServerName
    $centralserver.ConnectionContext.StatementTimeout = 0
    $centralDB = $centralserver.Databases.Item('DBA')
    
    
    while(1){
        $jobQuery = "Select Top 1 * from DBA.dbo.BackupAuditList where AuditStatus = 0"
        $QueryResult = $centralDB.ExecuteWithResults($jobQuery)
        if($QueryResult.Tables[0].Rows.Count -eq 0){
            LogMessage "No Jobs in Queue" $serverlog
            #sleep 30
            break
        }

        $outputDetails = $QueryResult.Tables[0].Rows[0]

          
        [Hashtable]$restoreDetails = @{
            ID = $outputDetails.ID;
            SourceServername = $outputDetails.Servername
            DatabaseName = $outputDetails.DatabaseName;
        }

        $restoreDetails.DatabaseName        
        
        #Update Table on initiation of restore
        $centralDB.ExecuteNonQuery("Update DBA.dbo.BackupAuditList set AuditStatus = 1 where ID = $($restoreDetails.ID)")
        LogMessage "Restore Started for Source $($restoreDetails.SourceServername) :: db $($restoreDetails.DatabaseName)" $serverlog


        
        ##Call Restore function
        $returncode = ExecRestore $auditserver $restoreDetails $serverlog
        
        DisplayMessage "$returncode"
        
        if($returncode -ne 1){
            
            #Update Table on completion of restore
            $centralDB.ExecuteNonQuery("Update DBA.dbo.BackupAuditList set AuditStatus = 2 where ID = $($restoreDetails.ID)")
            $centralDB.ExecuteNonQuery("Update DBA.dbo.BackupAuditList set Latest_Recovery_Point = '$($returncode)' where ID = $($restoreDetails.ID)")
            LogMessage "Restore Completed for Source $($restoreDetails.SourceServername) :: db $($restoreDetails.DatabaseName)" $serverlog
        }else{
            #Update Table on failure of restore
            $centralDB.ExecuteNonQuery("Update DBA.dbo.BackupAuditList set AuditStatus = 100 where ID = $($restoreDetails.ID)")
            LogMessage "Restore Failed for Source $($restoreDetails.SourceServername) :: db $($restoreDetails.DatabaseName)" $serverlog
            SendEmail "Backup Audit : Restore Failure" "Restore Failed for Source $($restoreDetails.SourceServername) :: db $($restoreDetails.DatabaseName)"
            return 1
        }

        
        #Update Table on initiation of CHECKDB
        $centralDB.ExecuteNonQuery("Update DBA.dbo.BackupAuditList set AuditStatus = 3 where ID = $($restoreDetails.ID)")
        LogMessage "CHECKDB Started for Source $($restoreDetails.SourceServername) :: db $($restoreDetails.DatabaseName)" $serverlog

        ##Call CHECKDB function
        $returncode = ExecCheckDB $auditserver $restoreDetails $serverlog
        LogMessage "$returncode" $serverlog
        
        if($returncode -ne 1){
            #update the returncode to replace ' with '' to make it sql compatible
            $returncode = $returncode.replace('''','''''')
            #Update Table on completion of CHECKDB
            if($returncode -ilike 'CHECKDB found 0 allocation errors and 0 consistency errors*'){
                $centralDB.ExecuteNonQuery("Update DBA.dbo.BackupAuditList set AuditStatus = 4, checkDB_status = 0, checkDB_output ='$($returncode)' where ID = $($restoreDetails.ID)")
                LogMessage "CHECKDB completed for Source $($restoreDetails.SourceServername) :: db $($restoreDetails.DatabaseName)" $serverlog
            }else{
                $centralDB.ExecuteNonQuery("Update DBA.dbo.BackupAuditList set AuditStatus = 4, checkDB_status = 1, checkDB_output ='$($returncode)' where ID = $($restoreDetails.ID)")
                LogMessage "CHECKDB completed with Error for Source $($restoreDetails.SourceServername) :: db $($restoreDetails.DatabaseName)" $serverlog
                SendEmail "Backup Audit : CHECKDB Failure" "CHECKDB Completed with Errors for Source $($restoreDetails.SourceServername) :: db $($restoreDetails.DatabaseName)"

                return 1
            }
        }else{
            #Update Table on failure of CHECKDB
            $centralDB.ExecuteNonQuery("Update DBA.dbo.BackupAuditList set AuditStatus = 200 where ID = $($restoreDetails.ID)")
            LogMessage "CHECKDB Failed for Source $($restoreDetails.SourceServername) :: db $($restoreDetails.DatabaseName)" $serverlog
            SendEmail "Backup Audit : CHECKDB Failure" "CHECKDB Failed for Source $($restoreDetails.SourceServername) :: db $($restoreDetails.DatabaseName)"
            return 1
        }

        
        #Update Table on initiation of Drop DB
        $centralDB.ExecuteNonQuery("Update DBA.dbo.BackupAuditList set AuditStatus = 5 where ID = $($restoreDetails.ID)")
        LogMessage "Drop Started for Source $($restoreDetails.SourceServername) :: db $($restoreDetails.DatabaseName)" $serverlog

        ##Call DropDB function
        $returncode = DropDB $auditserver $restoreDetails $serverlog
        
        if($returncode -eq 0){
            #Update Table on completion of CHECKDB
            $centralDB.ExecuteNonQuery("Update DBA.dbo.BackupAuditList set AuditStatus = 6, AuditDate = getdate() where ID = $($restoreDetails.ID)")
            LogMessage "Drop completed for Source $($restoreDetails.SourceServername) :: db $($restoreDetails.DatabaseName)" $serverlog
        }else{
            #Update Table on failure of CHECKDB
            $centralDB.ExecuteNonQuery("Update DBA.dbo.BackupAuditList set AuditStatus = 300 where ID = $($restoreDetails.ID)")
            LogMessage "Drop Failed for Source $($restoreDetails.SourceServername) :: db $($restoreDetails.DatabaseName)" $serverlog

            return 1
        }
        
        

    } 
    
    #Close connection
    $centralserver.ConnectionContext.Disconnect()

    return 0
}

Function SelectoldestBackup{
    param([Hashtable]$restoreDetails)
   
    $oldestBackup = $(dir $($restoreDetails.backupPath) | where-object {$_.Name -ilike "$($restoreDetails.SourceServername)_$($restoreDetails.DatabaseName)_FULL*" } | Sort-object -Property Name | select-object -First 1 ).Name
    return $oldestBackup
}

Function ExecRestore{
    param([Hashtable]$auditServer, [Hashtable]$restoreDetails, $serverlog)
      
   try{
        #Rubrik Server Connection
        $token = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI3N2RlMzkzMS1mNzExLTRkNWMtYWI2ZC1jY2U2Y2JmNDRmZmMiLCJpc01mYVJlbWVtYmVyVG9rZW4iOmZhbHNlLCJpc3MiOiJmODM4NGZmOS1jMmU5LTRhZDItYTQ5OC01MjBlMzk3ZmY3OTEiLCJpYXQiOjE3MTg2NDIwMjcsImp0aSI6Ijg4NTg0NDFjLTlhYjgtNGM3My1hNjc1LWFkNTgzYmRhYmM2OCJ9.b9TvCcQPuGZKt_dUPPUg3XTo0Lg8q9eKKPbSDsInOWI'
        #$token = 'ebd93297-24d2-45f4-87ee-3586dc90789e'

        
        $rubrikServer = '10.142.162.150'

        Connect-Rubrik -Server $rubrikServer -Token $token | Out-Null

        LogMessage "Rubrik Connected" $serverlog

        #Configure Restore Parameters
        $sourcedbname = $restoreDetails.DatabaseName
        $sourceserver = $restoreDetails.SourceServerName
        $targetserver = $auditServer.ServerName
        $TargetDataFilePath = $AuditServer.DataDir
        $TargetLogFilePath = $AuditServer.LogDir
        $targetdbname = "$($restoreDetails.DatabaseName)_RestoreTest"
        
        $targetInstance = Get-RubrikSQLInstance -ServerInstance $targetserver

        LogMessage "Target Instance Details Gathered $($targetInstance.id)" $serverlog

        $sourceInstance  = Get-RubrikSQLInstance -ServerInstance $sourceserver
        LogMessage "Source Instance Details Gathered $($sourceInstance.id)" $serverlog

        $sourcedb = Get-RubrikDatabase -Name $sourcedbname -InstanceID $sourceInstance.id | where {$_.isRelic -eq $false}

        $recovery_date = Get-Date (Get-RubrikDatabase -id $sourcedb.id).latestRecoveryPoint -Format "yyyy-MM-dd"
        
        #$sourcedb = Get-RubrikDatabase -Name $sourcedbname -Host $sourceserver -Instance 'MSSQLSERVER' | where {$_.isRelic -eq $false}
        #Get-RubrikDatabase -Name 'ARMS' -HOST 'DBQCSQL-002.ccaintranet.com' -Instance 'MSSQLSERVER'

        LogMessage "Database Details Gathered $($sourcedb.id)" $serverlog
                
        $restoreDBFiles = Get-RubrikDatabaseFiles -id $sourcedb.id -RecoveryDateTime (Get-Date (Get-RubrikDatabase -id $sourcedb.id).latestRecoveryPoint)
        
        #$restoreDBFiles
        
        
        $TargetFiles = @()
        foreach($dbfile in $restoreDBFiles){
            if($dbfile.fileType -eq "Log"){
                $TargetFiles += [pscustomobject]@{
                    logicalName = $dbFile.logicalName
                    exportPath = $TargetLogFilePath
                    newFilename = $dbFile.originalName
                    }
            }
            else{
                $TargetFiles += [pscustomobject]@{
                    logicalName = $dbFile.logicalName
                    exportPath = $TargetDataFilePath
                    newFilename = $dbFile.originalName
                    }
            }
        }
        


        LogMessage "Target DB $targetdbname" $serverlog
        
        $RubrikRequest = Export-RubrikDatabase `
                -id $sourcedb.id `
                -recoveryDateTime (Get-date (Get-RubrikDatabase -id $sourcedb.id).latestRecoveryPoint) `
                -targetInstanceId $targetInstance.Id `
                -targetDatabaseName $targetdbname `
                -TargetFilePaths $TargetFiles `
                -FinishRecovery

        LogMessage "Restore job queued. Waiting for completion of job" $serverlog

        # Wait till the restore completes
        $RubrikJobStatus = Get-RubrikRequest -id $RubrikRequest.id -Type mssql -WaitForCompletion
        
        #Disconnect Rubrik
        Disconnect-Rubrik -Confirm:$false | Out-Null
        LogMessage "Rubrik DisConnected" $serverlog
        
        return $recovery_date

    }catch{
        $ErrMsg = "$($_.Exception.Message.Replace("'", " "))"
        #Update Table on Failure of restore
        
        LogMessage "$ErrMsg" $serverlog
        LogMessage "Restore Failed for db $($restoreDetails.DatabaseName)" $serverlog

        #Disconnect Rubrik Connection
        #Disconnect-Rubrik -Confirm:$false

        return 1
    }
}

function ExecCheckDB{
    param([HashTable]$auditServer, [HashTable]$RestoreJob, $serverlog)
    try{
        $outfilename = "$($auditServer.outPath)\$($REstoreJob.SourceServername)_$($RestoreJob.DatabaseName)_CHECKDB.txt"
        
        $sqlserver = New-Object 'Microsoft.SqlServer.Management.Smo.Server' $auditServer.ServerName
        $sqlserver.ConnectionContext.StatementTimeout = 0
        $auditDB = $sqlserver.Databases.Item('DBA')
    
        $jobQuery = "dbcc checkdb('$($RestoreJob.Databasename)_RestoreTest') WITH TABLERESULTS"
        $QueryResult = $auditDB.ExecuteWithResults($jobQuery)
        $outputDetails = $QueryResult.Tables[0]
        $outputDetails.MessageText | Out-File $outfileName
        $checkdbstat = $($outputDetails | where {$_.MessageText -ilike 'CHECKDB Found*'}).MessageText
        $sqlserver.ConnectionContext.Disconnect()
        
        return $checkdbstat
    }catch{
        $ErrMsg = "$($_.Exception.Message.Replace("'", " "))"
        LogMessage "$ErrMsg" $serverlog
        
        return 1
    }

}

function DropDB{
    param([HashTable]$auditServer, [HashTable]$RestoreJob, $serverlog)
    try{
        $sqlserver = New-Object 'Microsoft.SqlServer.Management.Smo.Server' $auditServer.ServerName
        $sqlserver.ConnectionContext.StatementTimeout = 0
        $curDB = "$($RestoreJob.DatabaseName)_RestoreTEST"
        $dropDB = $sqlserver.Databases.Item($curDB)
        $dropDB.Drop()
    
        $centralserver.ConnectionContext.Disconnect()

        return 0
    }catch{
        $ErrMsg = "$($_.Exception.Message.Replace("'", " "))"
        LogMessage "$ErrMsg" $serverlog
        
        return 1
    }
}


$centralServerName = 'NVEIDBBACKUPP1.prod.ops.global.ad'
$DataDir = 'E:\MSSQL\Data\Audit'
$LogDir = 'E:\MSSQL\Data\Audit'
$serverlog = 'E:\Audit\Backup_Audit\AuditLog_06272923.txt'
$outPath = 'E:\Audit\Backup_Audit\CHECKDB_OUT'
$auditserver = @{ServerName = $centralServerName; DataDir = $DataDir; LogDir = $LogDir; outPath = $outPath}

#Out-File $serverLog

AuditMain $auditserver $serverlog
#ExecRestore $centralServerName "DEMO_EAST" "\\nveiadbd1\Central\BackupTest" $DataDir $LogDir $serverlog