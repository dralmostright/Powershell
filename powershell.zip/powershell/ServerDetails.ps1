﻿$servers = @(
'NVEIHOSTODBP1-n',
'NVEIHOSTODBP5-n',
'NVEIODBP1-n',
'NVEIPROCODB01-n',
'NVEIPROCODB02-n',
'NVEIPROCODB03-n',
'NVEIPROCRDB01-n',
'NVEIPROCRDB02-n',
'NVEIPROCRDB04-n'



)

$server_array = @()
$csvfile = "C:\Temp\Server_details.csv"

foreach($server in $servers){
$server
$processors = get-wmiobject -computername $server win32_processor

#$processors
    $cores = 0
    $FQDN=""
    $memoryGB = 0
    if (@($processors)[0].NumberOfCores)
    {
        $nproc = @($processors).count
        $npcore = @($processors)[0].NumberOfCores
        $cores = @($processors).count * @($processors)[0].NumberOfCores
        #$server+", `t" + $cores 
    }
    else
    {
        $nproc = @($processors).count
        $npcore = 1
        $cores = @($processors).count
        #$server+", `t" + $cores
    }

    ##IP Address
    $ipadd = $(Test-Connection $server -count 1).IPv4address # | select Ipv4Address

    ## OS version
    $osver = $(Get-WmiObject Win32_OperatingSystem -ComputerName $server).Caption

    ##memory
    $colItems = get-wmiobject -class "Win32_ComputerSystem" -namespace "root\CIMV2" -computername "$server"
    $memoryGB = [math]::round($colItems.TotalPhysicalMemory/1024/1024/1024, 0)
    $FQDN = "$($colItems.Name).$($colItems.Domain)"
    $server_details = New-Object PSObject -Property @{
        "IP" = $ipadd
        "Server" = $FQDN
        "ProcCount" = $nproc
        "Cores_Per_proc" = $npcore
        "Tot_cores" = $cores
        "Memory" = $memoryGB
        "OSversion" = $osver
    }
    $server_array += $server_details


}

$server_array | select Server, IP, ProcCount, Cores_Per_proc, Tot_cores, Memory, OSversion | export-csv $csvfile -NoTypeInformation
   