﻿Function LogMessage{
    param($msg, $outfile)
    $now = get-date -format "yyyy-MM-dd HH:mm:ss"
    Write-Verbose "$now :: $msg" -Verbose
    echo "$now :: $msg" | Out-File -Append $outfile
}

Function DisplayMessage{
    param($msg)
    $now = get-date -format "yyyy-MM-dd HH:mm:ss"
    Write-Verbose "$now :: $msg" -Verbose
}

function AuditMain{
    param([Hashtable]$auditserver, $serverlog)

    [System.Reflection.Assembly]::LoadwithpartialName('Microsoft.SqlServer.Smo') #| Out-Null
    [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoExtended") #| Out-Null

    $centralserver = New-Object 'Microsoft.SqlServer.Management.Smo.Server' $auditserver.ServerName
    $centralserver.ConnectionContext.StatementTimeout = 0
    $centralDB = $centralserver.Databases.Item('DBA')
    
    
    while(1){
        $jobQuery = "Select Top 1 * from DBA.dbo.BackupAuditList where AuditStatus = 0"
        $QueryResult = $centralDB.ExecuteWithResults($jobQuery)
        if($QueryResult.Tables[0].Rows.Count -eq 0){
            DisplayMessage "No Jobs in Queue" $serverlog
            #sleep 30
            break
        }

        $outputDetails = $QueryResult.Tables[0].Rows[0]

          
        [Hashtable]$restoreDetails = @{
            ID = $outputDetails.ID;
            SourceServername = $outputDetails.Servername
            DatabaseName = $outputDetails.DatabaseName;
            BackupPath = $outputDetails.BackupPath
        }

        $restoreDetails.DatabaseName
        $restoreDetails.BackupPath
        
        
        #Update Table on initiation of restore
        $centralDB.ExecuteNonQuery("Update DBA.dbo.BackupAuditList set AuditStatus = 1 where ID = $($restoreDetails.ID)")
        LogMessage "Restore Started for Source $($restoreDetails.SourceServername) :: db $($restoreDetails.DatabaseName)" $serverlog


        
        ##Call Restore function
        $returncode = ExecRestore $auditserver $restoreDetails $serverlog

        DisplayMessage "$returncode"
        
        if($returncode -eq 0){
            
            #Update Table on completion of restore
            $centralDB.ExecuteNonQuery("Update DBA.dbo.BackupAuditList set AuditStatus = 2 where ID = $($restoreDetails.ID)")
            LogMessage "Restore Completed for Source $($restoreDetails.SourceServername) :: db $($restoreDetails.DatabaseName)" $serverlog
        }else{
            #Update Table on failure of restore
            $centralDB.ExecuteNonQuery("Update DBA.dbo.BackupAuditList set AuditStatus = 100 where ID = $($restoreDetails.ID)")
            LogMessage "Restore Failed for Source $($restoreDetails.SourceServername) :: db $($restoreDetails.DatabaseName)" $serverlog

            return 1
        }

        #Update Table on initiation of CHECKDB
        $centralDB.ExecuteNonQuery("Update DBA.dbo.BackupAuditList set AuditStatus = 3 where ID = $($restoreDetails.ID)")
        LogMessage "CHECKDB Started for Source $($restoreDetails.SourceServername) :: db $($restoreDetails.DatabaseName)" $serverlog

        ##Call CHECKDB function
        $returncode = ExecCheckDB $auditserver $restoreDetails $serverlog
        
        if($returncode -eq 0){
            #Update Table on completion of CHECKDB
            $centralDB.ExecuteNonQuery("Update DBA.dbo.BackupAuditList set AuditStatus = 4 where ID = $($restoreDetails.ID)")
            LogMessage "CHECKDB completed for Source $($restoreDetails.SourceServername) :: db $($restoreDetails.DatabaseName)" $serverlog
        }else{
            #Update Table on failure of CHECKDB
            $centralDB.ExecuteNonQuery("Update DBA.dbo.BackupAuditList set AuditStatus = 200 where ID = $($restoreDetails.ID)")
            LogMessage "CHECKDB Failed for Source $($restoreDetails.SourceServername) :: db $($restoreDetails.DatabaseName)" $serverlog

            return 1
        }

        #Update Table on initiation of Drop DB
        $centralDB.ExecuteNonQuery("Update DBA.dbo.BackupAuditList set AuditStatus = 5 where ID = $($restoreDetails.ID)")
        LogMessage "Drop Started for Source $($restoreDetails.SourceServername) :: db $($restoreDetails.DatabaseName)" $serverlog

        ##Call DropDB function
        $returncode = DropDB $auditserver $restoreDetails $serverlog
        
        if($returncode -eq 0){
            #Update Table on completion of CHECKDB
            $centralDB.ExecuteNonQuery("Update DBA.dbo.BackupAuditList set AuditStatus = 6 where ID = $($restoreDetails.ID)")
            LogMessage "Drop completed for Source $($restoreDetails.SourceServername) :: db $($restoreDetails.DatabaseName)" $serverlog
        }else{
            #Update Table on failure of CHECKDB
            $centralDB.ExecuteNonQuery("Update DBA.dbo.BackupAuditList set AuditStatus = 300 where ID = $($restoreDetails.ID)")
            LogMessage "Drop Failed for Source $($restoreDetails.SourceServername) :: db $($restoreDetails.DatabaseName)" $serverlog

            return 1
        }

    } 
    
    #Close connection
    $centralserver.ConnectionContext.Disconnect()

    return 0
}

Function ExecRestore{
    param([Hashtable]$auditServer, [Hashtable]$restoreDetails, $serverlog)
      
    try{
        #Server Connection
        $sqlserver = New-Object 'Microsoft.SqlServer.Management.Smo.Server' $auditServer.ServerName
        $sqlserver.ConnectionContext.StatementTimeout = 0
          
        #Configure Restore Parameters
        $restore = New-Object Microsoft.SqlServer.Management.Smo.Restore
        $restore.Database = $($restoreDetails.DatabaseName) +'_Test'

        #Adding the backup files
        $backupDir = $($restoreDetails.backupPath)+'\'+$($restoreDetails.DatabaseName)+'\Full'
        $namelist = $(Get-ChildItem $backupDir).Name

        foreach($bkpfile in $namelist){
            $bkpFileName = "$backupDir\$($bkpfile)"
            $backupDeviceItem = new-object Microsoft.SqlServer.Management.Smo.BackupDeviceItem($bkpFileName, [Microsoft.SqlServer.Management.Smo.DeviceType]::File)
            $restore.Devices.Add($backupDeviceItem) | Out-Null
        }

        #Relocating the data and log files
        foreach($file in $restore.ReadFileList($sqlserver)){
            $relocateFile = New-object Microsoft.SqlServer.Management.Smo.RelocateFile
            $relocateFile.LogicalFileName = $file.LogicalName
            $Datafile = $($file.PhysicalName).Substring($($file.PhysicalName).LastIndexOf('\')+1)
            
            if($file.Type -ieq 'D'){
                $relocateFile.PhysicalFileName = "$($auditServer.DataDir)\$($Datafile)"
            }
            else{
                $relocateFile.PhysicalFileName = "$($auditServer.LogDir)\$($Datafile)"
            }
            $restore.RelocateFiles.Add($relocateFile) | Out-Null
        }

        # Execute restore
        $restore.SqlRestore($sqlserver) | Out-Null

        #Close connection
        $sqlserver.ConnectionContext.Disconnect() | Out-Null
        #DisplayMessage "Pramod"
        return 0

       
        

    }catch{
        $ErrMsg = "$($_.Exception.Message.Replace("'", " "))"
        #Update Table on Failure of restore
        
        LogMessage "$ErrMsg" $serverlog
        LogMessage "Restore Failed for db $($restoreDetails.DatabaseName)" $serverlog

        #Close connection
        $sqlserver.ConnectionContext.Disconnect()

        return 1
    }
}

function ExecCheckDB{
    param([HashTable]$auditServer, [HashTable]$RestoreJob, $serverlog)
    try{
        $outfilename = "$($auditServer.outPath)\$($RestoreJob.DatabaseName)_CHECKDB.txt"
        
        $sqlserver = New-Object 'Microsoft.SqlServer.Management.Smo.Server' $auditServer.ServerName
        $sqlserver.ConnectionContext.StatementTimeout = 0
        $auditDB = $sqlserver.Databases.Item('DBA')
    
        $jobQuery = "dbcc checkdb('$($RestoreJob.Databasename)_TEST') WITH TABLERESULTS"
        $QueryResult = $auditDB.ExecuteWithResults($jobQuery)
        $outputDetails = $QueryResult.Tables[0]
        $outputDetails.MessageText | Out-File $outfileName

        $centralserver.ConnectionContext.Disconnect()
        
        return 0
    }catch{
        $ErrMsg = "$($_.Exception.Message.Replace("'", " "))"
        LogMessage "$ErrMsg" $serverlog
        
        return 1
    }

}

function DropDB{
    param([HashTable]$auditServer, [HashTable]$RestoreJob, $serverlog)
    try{
        $sqlserver = New-Object 'Microsoft.SqlServer.Management.Smo.Server' $auditServer.ServerName
        $sqlserver.ConnectionContext.StatementTimeout = 0
        $curDB = "$($RestoreJob.DatabaseName)_TEST"
        $dropDB = $sqlserver.Databases.Item($curDB)
        $dropDB.Drop()
    
        $centralserver.ConnectionContext.Disconnect()

        return 0
    }catch{
        $ErrMsg = "$($_.Exception.Message.Replace("'", " "))"
        LogMessage "$ErrMsg" $serverlog
        
        return 1
    }
}


$centralServerName = 'NVEIDBBACKUPP1'
$DataDir = 'E:\MSSQL\Data\Audit'
$LogDir = 'E:\MSSQL\Log\Audit'
$serverlog = '\\nveidbbackupp1\Adhoc_Backup\Projects\BackupAudit\AuditLogQ12022.txt'
$outPath = '\\nveidbbackupp1\Adhoc_Backup\Projects\BackupAudit'
$auditserver = @{ServerName = $centralServerName; DataDir = $DataDir; LogDir = $LogDir; outPath = $outPath}

Out-File $serverLog

AuditMain $auditserver $serverlog
#ExecRestore $centralServerName "DEMO_EAST" "\\nveiadbd1\Central\BackupTest" $DataDir $LogDir $serverlog