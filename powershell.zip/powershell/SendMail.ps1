﻿$bodymsg = "upgrade_log"
$reportfile = "C:\temp\DATADESTRUCTION_HAP_NVEIRDBPC2_AFTER.txt"

Function SendReportMail{
    $From = "pramod.maharjan@versend.com"
    $To = "pramod.maharjan@verscend.com"
    $Attachment = $reportfile
    $Subject = "From NPEIBACKUPP1"
    $Body = $bodymsg
    $SMTPServer = "smtpnj.d2hawkeye.net"
    $SMTPPort = "25"
    Send-MailMessage -From $From -to $To -Subject $Subject -Body $Body -SmtpServer $SMTPServer -port $SMTPPort -Attachments $Attachment
}

SendReportMail