﻿[System.Reflection.Assembly]::LoadWithPartialName('Microsoft.AnalysisServices') | Out-Null

$servername = 'NVEIHOSTODBP5'

$olapserver = New-Object 'Microsoft.AnalysisServices.Server'
$olapserver.Connect($servername)

$serverDetails = @()
$userlist = @()
$administrators = $olapserver.Roles["Administrators"]

foreach($member in $administrators.Members){
    $userlist += $member.name
    $SAM = $member.Name.Split('\')[1]
    try{
        $ObjectClass = (Get-ADObject -filter {SamAccountName -eq $SAM}).ObjectClass
        if($ObjectClass -eq "group"){
            [array]$userDetail = New-object PSObject -Property @{
                "USER_ID" = $member.Name
                "USERNAME" = "NULL"
                "LoginType" = "WINDOWS_GROUP"
                "Is_SysAdmin" = 1
                "AccountStatus" = 1
                "DatabaseServer" = $servername
            }
            $serverDetails += $userDetail
        }
        elseif($ObjectClass -eq "user"){
            $user = @()
            
            $user = Get-ADUser -Identity $SAM -Properties *
            [array]$userDetail = New-object PSObject -Property @{
                "USER_ID" = $member.Name
                "USERNAME" = $user.DisplayName
                "LoginType" = "WINDOWS_USER"
                "Is_SysAdmin" = 1
                "AccountStatus" = if ($user.Enabled -eq $true) {1} else {0}
                "DatabaseServer" = $servername
            }
            $serverDetails += $userDetail
        }
    }
    catch{
        echo "Failed for $($member.name)"
    }
}

foreach($db in $olapserver.Databases){
    foreach($role in $db.roles){
        foreach($member in $role.Members){
            if($userlist -icontains $member.Name){ continue }
            $userlist += $member.name
            $SAM = $member.Name.Split('\')[1]
            try{
                $ObjectClass = (Get-ADObject -filter {SamAccountName -eq $SAM}).ObjectClass
                if($ObjectClass -eq "group"){
                    [array]$userDetail = New-object PSObject -Property @{
                        "USER_ID" = $member.Name
                        "USERNAME" = "NULL"
                        "LoginType" = "WINDOWS_GROUP"
                        "Is_SysAdmin" = 0
                        "AccountStatus" = 1
                        "DatabaseServer" = $servername
                    }
                    $serverDetails += $userDetail
                }
                elseif($ObjectClass -eq "user"){
                    $user = @()
            
                    $user = Get-ADUser -Identity $SAM -Properties *
                    [array]$userDetail = New-object PSObject -Property @{
                        "USER_ID" = $member.Name
                        "USERNAME" = $user.DisplayName
                        "LoginType" = "WINDOWS_USER"
                        "Is_SysAdmin" = 0
                        "AccountStatus" = if ($user.Enabled -eq $true) {1} else {0}
                        "DatabaseServer" = $servername
                    }
                    $serverDetails += $userDetail
                }
            }catch{
                echo "Failed for $($member.name)"
            }
        }
    }
}

$serverDetails | select USER_ID, USERNAME, LOGINTYPE, IS_SYSADMIN, ACCOUNTSTATUS, DATABASESERVER| Export-Csv -Path "C:\temp\$($servername)_Users.csv" -NoTypeInformation



