﻿[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null

$serverlist = @(
"NVEIDBBACKUPP1"
)

#$servername = 'nveidbbackupp1'

foreach($servername in $serverlist){
    $sqlserver = new-object "Microsoft.SqlServer.Management.Smo.Server" $servername
     foreach($ijob in $sqlserver.JobServer.Jobs){
        if($ijob.OperatorToEmail -ieq 'SYSDBA'){
            $ijob.name
            $ijob.OperatorToEmail
            echo "Changing operator for job $($ijob.name)"
            $ijob.OperatorToEmail = 'NepalDBA'
            $ijob.Alter()
        }       

    }
    
    
}





