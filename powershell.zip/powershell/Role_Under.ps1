﻿
#Load Assembly
[Reflection.Assembly]::LoadWithPartialName("Microsoft.AnalysisServices") | Out-Null

#constants
$server_invertory = 'NPEIBACKUPP1'
$csvfile = 'E:\test\OLAProles.csv'
$logfile = 'E:\test\OLAProlesLog.txt'

function logMessage{
    if($debug -eq 1){
        write-host $args
    }
    $args | Out-File -Append $logfile
}

Function GetOlapServers{
    $database="master"
    $connectionString="Server=$server_inventory;Database=$database;Integrated Security=True;"
    $connection=New-Object System.Data.SqlClient.SqlConnection
    $connection.ConnectionString=$connectionString
    $connection.Open()
    $query="select servers from master.dbo.server where type='OLAP'"
    $command=$connection.CreateCommand()
    $command.CommandText=$query
    $result=$command.ExecuteReader()
    $table=new-object "System.Data.DataTable"
    $table.Load($result)
    $result.close()
    $serverlist = @()
    foreach($row in $table) 
    {
        $serverlist += $row[0]
    }
    $connection.close()
    
    return $serverlist
}

Function GetServerRoles($SSASServer){
    $server = New-Object Microsoft.AnalysisServices.Server ;
    LogMessage "Connecting Server $($SSASServer)"
    $resultArray = @()
    try
    {
        $server.connect($SSASServer) ;  
    }catch{
        LogMessage "*********Connection Failed for Server $($SSASServer)**************"
        return $resultArray           
    }
    
    
    foreach ($DB in $server.Databases)
    {
        try{
            foreach ($Role in $DB.Roles)
            {        
               foreach ($UserName in $Role.Members)
                {
                    $DatabasePermission  = $DB.DatabasePermissions.GetByRole($Role.ID)
                    [array]$result = New-Object psobject -Property @{
                        "Server" = $SSASServer
                        "Database" = $DB.Name
                        "Role" = $Role.Name
                        "User" = $UserName.Name
                        "Admin" = $DatabasePermission.Administer
                        "Process" = $DatabasePermission.Process
                        "ReadDef" = $DatabasePermission.ReadDefinition
                    }
                    $resultArray += $result    
                }
            }
        }catch{
         LogMessage "*****Error in $($DB.Name) : $($_.Exception.Message)"
        }
    }
    $server.Disconnect()
    return $resultArray
}

Out-File $csvfile
Out-File $logfile
$serverlist = GetOlapServers
$roleArray = @()
foreach($myserver in $serverlist){
    $myserverRole = GetServerRoles $myserver
    $roleArray += $myserverRole
}
$roleArray | Select Server, Database, Role, User, Admin, Process, ReadDef | Export-Csv -path $csvfile -NoTypeInformation