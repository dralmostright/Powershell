﻿$centralServername = 'NPEIBACKUPp1'
$serverlist = @('NVEIADBP02', 'NVEI2ADBU02', 'NVEI1ADBU10')
$dblist = @('MREF', 'MREFLEGACY','VHIP','CATALOGBUILDER', 'PYRAMID', 'PYRAMIDGIS')
[System.Reflection.Assembly]::LoadwithPartialName('Microsoft.SqlServer.Smo') | Out-Null 

$centralserver = New-object Microsoft.Sqlserver.Management.Smo.Server $centralServername
$centralDB = $centralserver.Databases.Item('REPORT')
foreach($servername in $serverlist){
    $sqlserver = New-object Microsoft.Sqlserver.Management.Smo.Server $servername
    $sqlserver.Name
    foreach($db in $sqlserver.Databases){
        if($dblist -icontains $db.Name){
            $centralDB.ExecuteNonQuery("Insert into AppDBStat values('$($sqlserver.Name)', '$($db.Name)',$($db.Size), getdate());")
            
        }
    }
}