﻿$servers = @(
'NVEIDBBACKUPP1.prod.ops.global.ad'



)

$server_array = @()
$csvfile = "C:\Temp\Server_details.csv"

foreach($server in $servers){
$server
$processors = get-wmiobject -computername $server win32_processor

#$processors
    $cores = 0
    $FQDN=""
    $memoryGB = 0
    if (@($processors)[0].NumberOfCores)
    {
        $nproc = @($processors).count
        $npcore = @($processors)[0].NumberOfCores
        $cores = @($processors).count * @($processors)[0].NumberOfCores
        #$server+", `t" + $cores 
    }
    else
    {
        $nproc = @($processors).count
        $npcore = 1
        $cores = @($processors).count
        #$server+", `t" + $cores
    }

    $colItems = get-wmiobject -class "Win32_ComputerSystem" -namespace "root\CIMV2" -computername "$server"
    #$memoryGB = [math]::round($colItems.TotalPhysicalMemory/1024/1024/1024, 0)
    $FQDN = "$($colItems.Name).$($colItems.Domain)"
    $server_details = New-Object PSObject -Property @{
        "IP" = $colItems.Name
        "Server" = $FQDN
        "ProcCount" = $nproc
        "Cores_Per_proc" = $npcore
        "Tot_cores" = $cores
    }
    $server_array += $server_details


}

$server_array | select Server, IP, ProcCount, Cores_Per_proc, Tot_cores #| export-csv $csvfile -NoTypeInformation
   